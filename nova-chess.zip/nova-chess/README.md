# NOVA CHESS

Browser chess platform: chess.js rules, real Stockfish 19 (WASM, Web Worker), local persistence, no framework, no build step.

## Run
ES modules, Workers and WASM need HTTP (not `file://`):

    python3 -m http.server 8765      # or any static server
    # open http://localhost:8765/

Google Fonts (Inter, Sora) load from the internet; system fonts are the fallback offline.

## Notes
- **Accounts are a local demo**: stored in this browser's IndexedDB, passwords salted + PBKDF2-hashed (WebCrypto, 210k iterations), single-use recovery code. There is no server; this is not real authentication.
- **Rating** is a local estimate (Elo-style, rated vs-engine games without takebacks only).
- Engine is the single-threaded Stockfish 19 "lite" build (the Threads setting is stored but unused). An asm.js fallback loads if WASM is unavailable.
- Puzzles (83) are mined from engine self-play and re-verified with Stockfish (legal line, unique best move, mates end in mate).

## Tests
    node tests/rules.test.mjs                 # chess rules, perft, SEE (63 checks)
    node tests/strength.mjs                   # engine-vs-engine: stronger presets must beat weaker ones
    python3 tests/e2e.py <outdir>             # Playwright browser suite (57 checks, desktop + mobile)
Tooling needs `npm install` (Stockfish npm package, used only by tests/ and tools/).

## Licence
Stockfish is GPLv3 (vendor/STOCKFISH-LICENSE-GPL3.txt); chess.js is BSD-2.
