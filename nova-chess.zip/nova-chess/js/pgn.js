// PGN import/export helpers built on chess.js' PGN parser.
import { Chess } from '../vendor/chess.js';
import { START_FEN } from './game.js';

/** Splits a text file that may contain several games into individual PGN strings. */
export function splitPgn(text) {
  const t = String(text ?? '').replace(/\r\n?/g, '\n').replace(/^﻿/, '').trim();
  if (!t) return [];
  const parts = t.split(/\n\s*\n(?=\[Event\s)|^(?=\[Event\s)/m).map((s) => s.trim()).filter(Boolean);
  // A header-less movetext paste (no [Event]) is a single game.
  return parts.length ? parts : [t];
}

/**
 * Parses a single PGN game. Throws Error with a readable message on failure.
 * Returns { headers, moves (verbose), startFen, result, pgn }
 */
export function parseGame(pgnText) {
  const chess = new Chess();
  try {
    chess.loadPgn(pgnText, { strict: false });
  } catch (e) {
    throw new Error(`Could not read that PGN: ${String(e.message ?? e).split('\n')[0].slice(0, 140)}`);
  }
  const headers = chess.getHeaders?.() ?? chess.header();
  const moves = chess.history({ verbose: true });
  if (!moves.length && !headers.FEN) throw new Error('That PGN has no moves.');
  const startFen = headers.FEN && headers.SetUp !== '0' ? headers.FEN : START_FEN;
  let result = headers.Result && ['1-0', '0-1', '1/2-1/2'].includes(headers.Result) ? headers.Result : '*';
  if (result === '*') {
    if (chess.isCheckmate()) result = chess.turn() === 'w' ? '0-1' : '1-0';
    else if (chess.isDraw() || chess.isStalemate()) result = '1/2-1/2';
  }
  return { headers, moves, startFen, result, pgn: chess.pgn({ maxWidth: 90, newline: '\n' }) };
}

function reasonOf(chess, result, headers) {
  if (chess.isCheckmate()) return 'checkmate';
  if (chess.isStalemate()) return 'stalemate';
  if (chess.isInsufficientMaterial()) return 'insufficient';
  if (chess.isThreefoldRepetition()) return 'repetition';
  if (chess.isDrawByFiftyMoves()) return 'fifty';
  if (/time/i.test(headers.Termination ?? '')) return 'timeout';
  if (result === '1/2-1/2') return 'agreement';
  if (result === '*') return 'unfinished';
  return 'resignation';
}

/** Build a history record from an imported game. */
export function importedRecord(parsed, user) {
  const c = new Chess(parsed.startFen);
  for (const m of parsed.moves) c.move({ from: m.from, to: m.to, promotion: m.promotion });
  const h = parsed.headers;
  const white = h.White ?? 'White', black = h.Black ?? 'Black';
  const me = user?.name?.toLowerCase();
  const playerColor = me && white.toLowerCase() === me ? 'w' : me && black.toLowerCase() === me ? 'b' : null;
  let date = new Date();
  const dm = /^(\d{4})\.(\d{2})\.(\d{2})$/.exec(h.Date ?? '');
  if (dm) date = new Date(Number(dm[1]), Number(dm[2]) - 1, Number(dm[3]), 12);
  return {
    userId: user?.id ?? 'guest',
    date: date.toISOString(),
    importedAt: new Date().toISOString(),
    mode: 'import',
    white, black,
    whiteElo: h.WhiteElo ?? null, blackElo: h.BlackElo ?? null,
    playerColor,
    result: parsed.result,
    reason: reasonOf(c, parsed.result, h),
    pgn: parsed.pgn,
    plies: parsed.moves.length,
    durationMs: 0,
    event: h.Event ?? 'Imported game',
    rated: false,
    startFen: parsed.startFen,
  };
}

export function safeFileName(s) {
  return String(s).replace(/[^\w.-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60) || 'game';
}

export function recordFileName(rec) {
  const d = String(rec.date).slice(0, 10);
  return `${safeFileName(`${rec.white}_vs_${rec.black}`)}_${d}.pgn`;
}
