// Shared helpers: DOM, icons, toasts, modals, formatting.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Hyperscript-style element builder. */
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

export function debounce(fn, ms) {
  let t;
  const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  d.cancel = () => clearTimeout(t);
  return d;
}

export class Emitter {
  #h = new Map();
  on(ev, fn) { (this.#h.get(ev) ?? this.#h.set(ev, new Set()).get(ev)).add(fn); return () => this.off(ev, fn); }
  off(ev, fn) { this.#h.get(ev)?.delete(fn); }
  emit(ev, ...a) { for (const fn of [...(this.#h.get(ev) ?? [])]) { try { fn(...a); } catch (e) { console.error(`[emit:${ev}]`, e); } } }
}

export function fmtClock(ms, showTenths = true) {
  if (ms == null) return '';
  ms = Math.max(0, ms);
  const total = ms / 1000;
  if (total < 10 && showTenths) return `0:0${total.toFixed(1)}`;
  const m = Math.floor(total / 60);
  const s = Math.floor(total % 60);
  if (m >= 60) return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function fmtDuration(ms) {
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${String(s % 60).padStart(2, '0')}s`;
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
}

export function fmtDate(iso, withTime = false) {
  const d = new Date(iso);
  if (isNaN(d)) return '—';
  const opts = withTime ? { dateStyle: 'medium', timeStyle: 'short' } : { dateStyle: 'medium' };
  return d.toLocaleString(undefined, opts);
}

export function download(filename, text, type = 'text/plain') {
  const url = URL.createObjectURL(new Blob([text], { type: `${type};charset=utf-8` }));
  const a = h('a', { href: url, download: filename });
  document.body.append(a);
  a.click();
  setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 500);
}

export function pickFile(accept) {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept, style: { display: 'none' } });
    input.addEventListener('change', () => { resolve(input.files[0] ?? null); input.remove(); });
    input.addEventListener('cancel', () => { resolve(null); input.remove(); });
    document.body.append(input);
    input.click();
  });
}

// ---------------------------------------------------------------- icons ---
const P = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
  play: '<path d="M7 4.5v15l12-7.5z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9.5 9.5h5v5h-5z"/><path d="M9 2.5v3M15 2.5v3M9 18.5v3M15 18.5v3M2.5 9h3M2.5 15h3M18.5 9h3M18.5 15h3"/>',
  review: '<path d="M4 19.5V5"/><path d="M4 19.5h16"/><path d="M7.5 15l3.5-4.5 3 2.5 4.5-6"/>',
  puzzle: '<path d="M9.5 4.5a2 2 0 1 1 4 0V6h3.5a1 1 0 0 1 1 1v3.5h-1.5a2 2 0 1 0 0 4H18V18a1 1 0 0 1-1 1h-3.5v-1.5a2 2 0 1 0-4 0V19H6a1 1 0 0 1-1-1v-3.5h1.5a2 2 0 1 0 0-4H5V7a1 1 0 0 1 1-1h3.5z"/>',
  history: '<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 4v4.5H8"/><path d="M12 7.5V12l3 2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 14.5a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3h0a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5h0a1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8v0a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
  user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20c.8-3.8 3.8-5.8 7.5-5.8s6.7 2 7.5 5.8"/>',
  users: '<circle cx="9" cy="8.5" r="3.3"/><path d="M2.8 19.5c.7-3.4 3.2-5 6.2-5s5.5 1.6 6.2 5"/><path d="M16 5.5a3.3 3.3 0 0 1 0 6"/><path d="M18 14.7c1.8.6 3 2.2 3.4 4.8"/>',
  logout: '<path d="M10 4.5H5.5a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1H10"/><path d="M15 8l4 4-4 4"/><path d="M19 12H9.5"/>',
  eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18"/><path d="M10.6 5.6A10 10 0 0 1 12 5.5c6.4 0 10 6.5 10 6.5a17 17 0 0 1-3.2 4"/><path d="M6.3 7.3A16 16 0 0 0 2 12s3.6 6.5 10 6.5a9.6 9.6 0 0 0 4-.9"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  flip: '<path d="M7 4v14"/><path d="M3.5 7.5 7 4l3.5 3.5"/><path d="M17 20V6"/><path d="M13.5 16.5 17 20l3.5-3.5"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
  flag: '<path d="M5 21V4"/><path d="M5 4.5h11l-2 4 2 4H5"/>',
  draw: '<path d="M4 12h16"/><path d="M8 7.5l-4 4.5 4 4.5"/><path d="M16 7.5l4 4.5-4 4.5"/>',
  restart: '<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  download: '<path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>',
  upload: '<path d="M12 16V5"/><path d="m7 9 5-5 5 5"/><path d="M5 20h14"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.5h5V7"/><path d="M6.5 7l1 13h9l1-13"/><path d="M10 11v6M14 11v6"/>',
  check: '<path d="m4.5 12.5 5 5 10-11"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  first: '<path d="M6 5v14"/><path d="M18 5 9 12l9 7z"/>',
  prev: '<path d="M16 5 7 12l9 7z"/>',
  next: '<path d="m8 5 9 7-9 7z"/>',
  last: '<path d="M18 5v14"/><path d="m6 5 9 7-9 7z"/>',
  copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5v-2a2 2 0 0 0-2-2h-7a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2"/>',
  sound: '<path d="M4 9.5v5h3.5l5 4v-13l-5 4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8v.1"/>',
  star: '<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.3 2.8 1-5.9L3.5 9.7l5.9-.8z"/>',
  trophy: '<path d="M7.5 4.5h9v5a4.5 4.5 0 0 1-9 0z"/><path d="M7.5 6.5h-3v1.5a3 3 0 0 0 3 3M16.5 6.5h3v1.5a3 3 0 0 1-3 3"/><path d="M12 14v3.5M8.5 20h7M9.5 17.5h5"/>',
  bolt: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  board: '<rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M3.5 12h17M12 3.5v17"/><path d="M12 3.5h4.25v8.5H12zM7.75 12H12v8.5H7.75z" fill="currentColor" stroke="none"/>',
  bulb: '<path d="M9 18.5h6M10 21h4"/><path d="M12 3.5a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V17h5v-.6c0-.8.4-1.5 1-2A6 6 0 0 0 12 3.5z"/>',
  chevron: '<path d="m9 6 6 6-6 6"/>',
  chevdown: '<path d="m6 9 6 6 6-6"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  swap: '<path d="M4 8h14"/><path d="m14.5 4.5 3.5 3.5-3.5 3.5"/><path d="M20 16H6"/><path d="M9.5 12.5 6 16l3.5 3.5"/>',
  mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="m4 7 8 6 8-6"/>',
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  hint: '<path d="M12 3.5a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V17h5v-.6c0-.8.4-1.5 1-2A6 6 0 0 0 12 3.5z"/><path d="M10 20.5h4"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  knight: '<path d="M7 20.5h11M8 20.5c0-3.5 1.5-6 4-8.2-2.2-.4-3.8-1.7-4.2-3.8L11 4.5l1.7 1.2C15.2 5.5 18 7.5 18 12c0 3-.8 5.5-.8 8.5"/>',
};

export function icon(name, cls = 'ico') {
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] ?? ''}</svg>`;
}

// --------------------------------------------------------------- toasts ---
export function toast(msg, type = '', ms = 3200) {
  const root = $('#toasts');
  if (!root) return;
  const t = h('div', { class: `toast ${type}`, role: 'status' }, msg);
  root.append(t);
  while (root.children.length > 4) root.firstChild.remove();
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 240); }, ms);
}

// --------------------------------------------------------------- modals ---
/**
 * Opens a modal. `body` may be a node/string. `actions` = [{label, value, kind}].
 * Resolves with the chosen action value (or null if dismissed). Returns promise with `.close` and `.el`.
 */
export function modal({ title, body, actions = [{ label: 'OK', value: true, kind: 'primary' }], dismissible = true, wide = false, onOpen }) {
  const root = $('#modal-root');
  let resolveFn;
  const promise = new Promise((r) => { resolveFn = r; });
  const back = h('div', { class: 'modal-back' });
  const box = h('div', { class: `modal${wide ? ' wide' : ''}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title || 'Dialog' });
  const bodyEl = h('div', { class: 'body' });
  if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.append(body);
  const act = h('div', { class: 'actions' });
  let closed = false;
  const close = (val = null) => {
    if (closed) return;
    closed = true;
    document.removeEventListener('keydown', onKey, true);
    back.classList.add('closing'); box.classList.add('closing');
    setTimeout(() => back.remove(), 170);
    resolveFn(val);
  };
  for (const a of actions) {
    const b = h('button', { class: `btn ${a.kind ?? ''}`, type: 'button' }, a.label);
    b.addEventListener('click', async () => {
      if (a.onClick) { const keep = await a.onClick(); if (keep === false) return; }
      close(a.value);
    });
    act.append(b);
  }
  box.append(...(title ? [h('h2', null, title)] : []), bodyEl, ...(actions.length ? [act] : []));
  back.append(box);
  if (dismissible) back.addEventListener('pointerdown', (e) => { if (e.target === back) close(null); });
  const onKey = (e) => { if (e.key === 'Escape' && dismissible) { e.stopPropagation(); close(null); } };
  document.addEventListener('keydown', onKey, true);
  root.append(back);
  setTimeout(() => (box.querySelector('[autofocus]') || act.querySelector('.primary') || act.firstChild)?.focus?.(), 30);
  onOpen?.(box, close);
  promise.close = close;
  promise.el = box;
  return promise;
}

export const confirmDialog = (title, text, okLabel = 'Confirm', kind = 'primary') =>
  modal({ title, body: text, actions: [{ label: 'Cancel', value: false }, { label: okLabel, value: true, kind }] });

export const alertDialog = (title, text) => modal({ title, body: text });

// ------------------------------------------------------------- avatars ----
export const AVATARS = [
  ['#7c6cff', '#27d3e6', 'K'], ['#ff6b8b', '#ffb454', 'Q'], ['#3ecf8e', '#2aa5d6', 'R'], ['#f5a524', '#ef5b5b', 'B'],
  ['#4f8cff', '#a56bff', 'N'], ['#14b8a6', '#84cc16', 'P'], ['#e879f9', '#6366f1', 'K'], ['#fb7185', '#f97316', 'N'],
  ['#22d3ee', '#3b82f6', 'Q'], ['#a3e635', '#16a34a', 'B'], ['#fbbf24', '#d97706', 'R'], ['#94a3b8', '#475569', 'P'],
];

export function avatarEl(idx = 0, cls = '') {
  const [c1, c2, g] = AVATARS[idx % AVATARS.length];
  const el = h('div', { class: `avatar ${cls}`, style: { background: `linear-gradient(135deg, ${c1}, ${c2})` } });
  el.innerHTML = `<svg viewBox="0 0 100 100" fill="#fff" fill-opacity=".92">${GLYPH[g]}</svg>`;
  return el;
}

const GLYPH = {
  P: '<circle cx="50" cy="30" r="13"/><path d="M40 46h20l-3 8c6 6 12 16 14 28H29c2-12 8-22 14-28z"/>',
  R: '<path d="M26 16h12v9h8v-9h8v9h8v-9h12v26H26z"/><path d="M32 46h36l4 32H28z"/><rect x="22" y="78" width="56" height="9" rx="3"/>',
  N: '<path d="M24 86c0-18 7-30 20-40-8-2-14-8-14-17l22-17 4 6c12 1 26 14 26 40 0 10-2 20-2 28z"/>',
  B: '<circle cx="50" cy="14" r="6"/><path d="M50 22c14 10 22 22 14 36-3 4-6 7-8 9H44c-2-2-5-5-8-9-8-14 0-26 14-36z"/><rect x="38" y="66" width="24" height="8" rx="3"/><path d="M30 86c2-9 8-12 20-12s18 3 20 12z"/>',
  Q: '<circle cx="22" cy="24" r="6"/><circle cx="39" cy="15" r="6"/><circle cx="61" cy="15" r="6"/><circle cx="78" cy="24" r="6"/><path d="M20 32l14 26 8-30 8 30 8-30 14 26 4 36H18z"/><rect x="18" y="76" width="64" height="10" rx="3"/>',
  K: '<path d="M46 8h8v9h9v8h-9v9h-8v-9h-9v-8h9z"/><path d="M26 40c10-8 38-8 48 0 6 12-2 26-8 34H34c-6-8-14-22-8-34z"/><rect x="26" y="76" width="48" height="10" rx="3"/>',
};
