// Interactive chessboard view. It owns rendering + input only; rules live in chess.js / the game session.
import { h } from './util.js';
import { settings } from './store.js';
import { pieceClass } from './pieces.js';

const FILES = 'abcdefgh';

export const sqName = (file, rank) => FILES[file] + (rank + 1);
export const sqFile = (sq) => sq.charCodeAt(0) - 97;
export const sqRank = (sq) => Number(sq[1]) - 1;

/** Parses the placement field of a FEN into { e4: 'wP', ... }. */
export function fenToMap(fen) {
  const map = {};
  const rows = fen.split(' ')[0].split('/');
  for (let r = 0; r < 8; r++) {
    let f = 0;
    for (const ch of rows[r]) {
      if (ch >= '1' && ch <= '8') { f += Number(ch); continue; }
      const color = ch === ch.toUpperCase() ? 'w' : 'b';
      map[FILES[f] + (8 - r)] = color + ch.toUpperCase();
      f++;
    }
  }
  return map;
}

export class Board {
  /**
   * @param {HTMLElement} host  element that will receive the board (.board is created inside)
   * @param {object} cb  callbacks:
   *   interactive(): boolean            – may the user move right now?
   *   targets(from): [{to, capture}]    – legal destinations for the piece on `from` ([] if not selectable)
   *   onMove(from, to, {drag}): void    – user chose a legal destination
   *   onIllegal(): void                 – user tried something that is not legal
   */
  constructor(host, cb = {}) {
    this.cb = cb;
    this.orientation = 'w';
    this.pieceEls = new Map();
    this.squareEls = new Map();
    this.marks = { last: [], sel: null, check: null, hints: [], premark: [] };
    this.selected = null;
    this.targets = new Map();
    this.drag = null;
    this.badges = new Map();
    this.destroyed = false;

    this.el = h('div', { class: 'board anim', role: 'application', 'aria-label': 'Chess board' });
    for (let f = 0; f < 8; f++) for (let r = 0; r < 8; r++) {
      const name = sqName(f, r);
      const light = (f + r) % 2 === 1;
      const s = h('div', { class: `sq ${light ? 'l' : 'd'}`, 'data-sq': name });
      this.squareEls.set(name, s);
      this.el.append(s);
    }
    this.filesEl = h('div', { class: 'coords files' }); this.ranksEl = h('div', { class: 'coords ranks' });
    for (let i = 0; i < 8; i++) {
      this.filesEl.append(h('span', { style: { left: `${i * 12.5}%` } }));
      this.ranksEl.append(h('span', { style: { top: `${i * 12.5}%` } }));
    }
    this.el.append(this.filesEl, this.ranksEl);
    this.arrowSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.arrowSvg.setAttribute('class', 'arrows');
    this.arrowSvg.setAttribute('viewBox', '0 0 800 800');
    this.el.append(this.arrowSvg);
    host.append(this.el);

    this.layoutSquares();
    this.updateCoords();
    this.applySettings();

    this._down = (e) => this.onDown(e);
    this._move = (e) => this.onMovePtr(e);
    this._up = (e) => this.onUp(e);
    this.el.addEventListener('pointerdown', this._down);
    this.el.addEventListener('pointermove', this._move);
    this.el.addEventListener('pointerup', this._up);
    this.el.addEventListener('pointercancel', this._up);
    this.el.addEventListener('contextmenu', (e) => e.preventDefault());
    this._unsub = settings.on('change', () => this.applySettings());
  }

  destroy() {
    this.destroyed = true;
    this._unsub?.();
    this.el.remove();
  }

  applySettings() {
    this.el.classList.toggle('anim', settings.get('animations'));
    this.el.classList.toggle('no-coords', !settings.get('showCoords'));
  }

  // ---------------------------------------------------------- geometry ---
  xy(sq) {
    const f = sqFile(sq), r = sqRank(sq);
    return this.orientation === 'w' ? [f, 7 - r] : [7 - f, r];
  }
  squareAt(px, py) {
    const rect = this.el.getBoundingClientRect();
    const x = Math.floor(((px - rect.left) / rect.width) * 8);
    const y = Math.floor(((py - rect.top) / rect.height) * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return null;
    return this.orientation === 'w' ? sqName(x, 7 - y) : sqName(7 - x, y);
  }
  place(el, sq) {
    const [x, y] = this.xy(sq);
    el.style.setProperty('--x', x);
    el.style.setProperty('--y', y);
  }
  layoutSquares() {
    for (const [sq, el] of this.squareEls) this.place(el, sq);
    for (const [sq, el] of this.pieceEls) this.place(el, sq);
    for (const [sq, el] of this.badges) this.placeBadge(el, sq);
  }
  updateCoords() {
    const w = this.orientation === 'w';
    [...this.filesEl.children].forEach((s, i) => {
      s.textContent = FILES[w ? i : 7 - i];
      s.className = i % 2 === 0 ? 'on-dark' : 'on-light';
    });
    [...this.ranksEl.children].forEach((s, i) => {
      s.textContent = w ? 8 - i : i + 1;
      s.className = i % 2 === 0 ? 'on-light' : 'on-dark';
    });
  }

  setOrientation(o) {
    if (o === this.orientation) return;
    this.orientation = o;
    this.layoutSquares();
    this.updateCoords();
    this.redrawArrows();
  }
  flip() { this.setOrientation(this.orientation === 'w' ? 'b' : 'w'); return this.orientation; }

  // --------------------------------------------------------- rendering ---
  makePiece(code, sq) {
    const el = h('div', { class: `piece ${code}`, 'data-p': code });
    this.place(el, sq);
    this.el.append(el);
    return el;
  }

  /**
   * Show a position. `map` is { e4: 'wP' }.
   * `move` (optional) = chess.js verbose move; when `animate` is true the pieces slide.
   */
  render(map, { move = null, animate = true, lastMove = undefined, check = null } = {}) {
    const doAnim = animate && move && settings.get('animations');
    if (doAnim) {
      const el = this.pieceEls.get(move.from);
      if (el) {
        // captured piece
        let capSq = move.to;
        if (move.flags?.includes('e')) capSq = move.to[0] + move.from[1];
        const cap = this.pieceEls.get(capSq);
        if (cap && cap !== el) { this.pieceEls.delete(capSq); this.fadeOut(cap); }
        this.pieceEls.delete(move.from);
        this.pieceEls.set(move.to, el);
        this.place(el, move.to);
        // castling rook
        if (move.flags?.includes('k') || move.flags?.includes('q')) {
          const rank = move.from[1];
          const [rf, rt] = move.flags.includes('k') ? ['h', 'f'] : ['a', 'd'];
          const rook = this.pieceEls.get(rf + rank);
          if (rook) { this.pieceEls.delete(rf + rank); this.pieceEls.set(rt + rank, rook); this.place(rook, rt + rank); }
        }
      }
    }
    // Reconcile DOM with the target map (also handles non-animated updates, promotions, undo...).
    for (const [sq, el] of [...this.pieceEls]) {
      const want = map[sq];
      if (want !== el.dataset.p) {
        if (want && doAnim && move && sq === move.to && el.dataset.p?.[1] === 'P') {
          // promotion: swap sprite once the slide ends
          const swap = () => { el.className = `piece ${want}`; el.dataset.p = want; };
          if (settings.get('animations')) setTimeout(swap, parseInt(getComputedStyle(document.documentElement).getPropertyValue('--move-ms')) || 160);
          else swap();
          continue;
        }
        el.remove();
        this.pieceEls.delete(sq);
      }
    }
    for (const [sq, code] of Object.entries(map)) {
      if (!this.pieceEls.has(sq)) this.pieceEls.set(sq, this.makePiece(code, sq));
    }
    this.updateMarks({ lastMove, check });
    this.refreshGrabCursor();
  }

  fadeOut(el) {
    el.classList.add('fade');
    el.style.zIndex = '3';
    setTimeout(() => el.remove(), 260);
  }

  refreshGrabCursor() {
    const inter = this.cb.interactive?.();
    this.el.classList.toggle('turn-ok', !!inter);
  }

  // ------------------------------------------------------------- marks ---
  mark(sq, cls, on) { this.squareEls.get(sq)?.classList.toggle(cls, on); }
  updateMarks({ lastMove, check } = {}) {
    if (lastMove !== undefined) {
      this.marks.last.forEach((s) => this.mark(s, 'last', false));
      this.marks.last = (lastMove && settings.get('highlightLast')) ? [lastMove.from, lastMove.to] : [];
      this.marks.last.forEach((s) => this.mark(s, 'last', true));
    }
    if (check !== undefined) {
      if (this.marks.check) this.mark(this.marks.check, 'check', false);
      this.marks.check = check;
      if (check) this.mark(check, 'check', true);
    }
  }
  showSelection(sq, targets) {
    this.clearSelection();
    this.selected = sq;
    this.targets = new Map(targets.map((t) => [t.to, t]));
    this.mark(sq, 'sel', true);
    this.marks.sel = sq;
    if (settings.get('highlightLegal')) {
      for (const t of targets) { this.mark(t.to, 'hint', true); if (t.capture) this.mark(t.to, 'cap', true); this.marks.hints.push(t.to); }
    }
  }
  clearSelection() {
    if (this.marks.sel) this.mark(this.marks.sel, 'sel', false);
    this.marks.hints.forEach((s) => { this.mark(s, 'hint', false); this.mark(s, 'cap', false); });
    this.marks.sel = null; this.marks.hints = [];
    this.selected = null; this.targets = new Map();
  }
  setBoardOver(on) { this.el.classList.toggle('over', on); }

  // ------------------------------------------------------------ badges ---
  placeBadge(el, sq) {
    const [x, y] = this.xy(sq);
    el.style.left = `${(x + 1) * 12.5}%`;
    el.style.top = `${y * 12.5}%`;
  }
  setBadge(sq, { text, cls } = {}) {
    for (const [, el] of this.badges) el.remove();
    this.badges.clear();
    if (!sq || !text) return;
    const el = h('div', { class: `badge ${cls ?? ''}`, style: { transform: 'translate(-92%, -8%)' } }, text);
    this.placeBadge(el, sq);
    this.el.append(el);
    this.badges.set(sq, el);
  }

  // ------------------------------------------------------------ arrows ---
  setArrows(arrows) { this.arrows = arrows ?? []; this.redrawArrows(); }
  redrawArrows() {
    const svg = this.arrowSvg;
    svg.innerHTML = '';
    for (const a of this.arrows ?? []) {
      const [x1, y1] = this.xy(a.from).map((v) => v * 100 + 50);
      const [x2, y2] = this.xy(a.to).map((v) => v * 100 + 50);
      const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1;
      const ux = dx / len, uy = dy / len;
      const head = 34, w = 15;
      const ex = x2 - ux * head * 0.85, ey = y2 - uy * head * 0.85;
      const sx = x1 + ux * 18, sy = y1 + uy * 18;
      const col = a.color ?? '#6fbf4a';
      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      g.setAttribute('opacity', a.opacity ?? 0.85);
      g.innerHTML =
        `<line x1="${sx}" y1="${sy}" x2="${ex}" y2="${ey}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>` +
        `<polygon fill="${col}" points="${x2 - ux * 6},${y2 - uy * 6} ${x2 - ux * head - uy * 22},${y2 - uy * head + ux * 22} ${x2 - ux * head + uy * 22},${y2 - uy * head - ux * 22}"/>`;
      svg.append(g);
    }
  }

  // --------------------------------------------------------- promotion ---
  askPromotion(to, color) {
    return new Promise((resolve) => {
      const [x, y] = this.xy(to);
      const fromTop = y === 0;
      const order = ['q', 'n', 'r', 'b'];
      const box = h('div', { class: 'promo', role: 'dialog', 'aria-label': 'Choose promotion piece' });
      box.style.left = `${x * 12.5}%`;
      box.style[fromTop ? 'top' : 'bottom'] = '0';
      const list = fromTop ? order : [...order].reverse();
      const scrim = h('div', { class: 'promo-scrim' });
      const done = (v) => { box.remove(); scrim.remove(); resolve(v); };
      scrim.addEventListener('pointerdown', (e) => { e.stopPropagation(); done(null); });
      for (const t of list) {
        const b = h('button', { class: pieceClass(color, t), type: 'button', 'aria-label': { q: 'Queen', n: 'Knight', r: 'Rook', b: 'Bishop' }[t] });
        b.addEventListener('pointerdown', (e) => e.stopPropagation());
        b.addEventListener('click', (e) => { e.stopPropagation(); done(t); });
        box.append(b);
      }
      this.el.append(scrim, box);
    });
  }

  // ------------------------------------------------------------- input ---
  onDown(e) {
    if (e.button != null && e.button !== 0) return;
    if (this.el.querySelector('.promo')) return;
    if (!this.cb.interactive?.()) return;
    const sq = this.squareAt(e.clientX, e.clientY);
    if (!sq) return;
    // Click-to-move completion
    if (this.selected && this.targets.has(sq)) {
      const from = this.selected;
      this.clearSelection();
      this.cb.onMove?.(from, sq, { drag: false });
      return;
    }
    const targets = this.cb.targets?.(sq) ?? [];
    const el = this.pieceEls.get(sq);
    if (el && targets.length) {
      this.showSelection(sq, targets);
      this.drag = { sq, el, x0: e.clientX, y0: e.clientY, started: false, id: e.pointerId };
      try { this.el.setPointerCapture(e.pointerId); } catch { /* ignore */ }
      el.classList.add('grabbable');
    } else if (el && this.selected !== sq && this.selected) {
      // clicked an own piece without legal moves, or enemy piece that is not a target
      this.clearSelection();
      this.cb.onIllegal?.(sq);
    } else if (el && !targets.length && !this.selected) {
      // piece that can't move (wrong colour or no legal moves)
      this.cb.onIllegal?.(sq);
    } else {
      this.clearSelection();
    }
  }

  onMovePtr(e) {
    const d = this.drag;
    if (!d || e.pointerId !== d.id) return;
    if (!d.started) {
      if (Math.hypot(e.clientX - d.x0, e.clientY - d.y0) < 6) return;
      d.started = true;
      d.el.classList.add('drag');
    }
    const rect = this.el.getBoundingClientRect();
    const size = rect.width / 8;
    const px = e.clientX - rect.left - size / 2;
    const py = e.clientY - rect.top - size / 2;
    d.el.style.transform = `translate(${px}px, ${py}px)`;
    const over = this.squareAt(e.clientX, e.clientY);
    if (over !== d.over) {
      if (d.over) this.mark(d.over, 'hover-target', false);
      d.over = over;
      if (over && this.targets.has(over)) this.mark(over, 'hover-target', true);
    }
  }

  onUp(e) {
    const d = this.drag;
    if (!d || e.pointerId !== d.id) return;
    this.drag = null;
    try { this.el.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
    d.el.classList.remove('grabbable');
    if (d.over) this.mark(d.over, 'hover-target', false);
    if (!d.started) return; // plain click: selection stays, waiting for a destination
    const to = this.squareAt(e.clientX, e.clientY);
    d.el.classList.remove('drag');
    d.el.style.transform = '';
    if (to && to !== d.sq && this.targets.has(to)) {
      const from = d.sq;
      this.clearSelection();
      this.cb.onMove?.(from, to, { drag: true });
    } else if (to && to !== d.sq) {
      this.clearSelection();
      this.cb.onIllegal?.(to);
    }
    // dropped on its own square: keep selection (click-to-move continues)
  }

  /** Cancel any pending drag/selection (e.g. when the position changes under the user). */
  cancelInteraction() {
    if (this.drag) { this.drag.el.classList.remove('drag', 'grabbable'); this.drag.el.style.transform = ''; this.drag = null; }
    this.clearSelection();
    this.el.querySelector('.promo')?.remove();
    this.el.querySelector('.promo-scrim')?.remove();
  }
}
