// App shell, router and bootstrap.
import { $, h, icon, toast, modal, confirmDialog, avatarEl } from './util.js';
import { db, settings, activeGameStore, isMemoryMode, ls } from './store.js';
import * as auth from './auth.js';
import { installPieceSet } from './pieces.js';
import { loadStats } from './stats.js';
import { GameSession, TIME_CONTROLS, START_FEN } from './game.js';
import { parseGame } from './pgn.js';
import { engines } from './engine.js';
import { mountWelcome } from './views/welcome.js';
import { mountDashboard } from './views/dashboard.js';
import { mountPlayHub, mountEngineSetup, mountLocalSetup } from './views/play.js';
import { GameView } from './views/game.js';
import { mountReview, mountReviewPicker } from './views/review.js';
import { mountPuzzles } from './views/puzzles.js';
import { mountHistory } from './views/history.js';
import { mountSettings } from './views/settings.js';
import { mountProfile } from './views/profile.js';

const NAV = [
  { id: 'home', label: 'Home', icon: 'home', path: '/' },
  { id: 'play', label: 'Play Chess', icon: 'play', path: '/play' },
  { id: 'engine', label: 'Play Stockfish', icon: 'cpu', path: '/play/engine' },
  { id: 'review', label: 'Game Review', icon: 'review', path: '/review' },
  { id: 'puzzles', label: 'Puzzles', icon: 'puzzle', path: '/puzzles' },
  { id: 'history', label: 'Game History', icon: 'history', path: '/history' },
  { id: 'settings', label: 'Settings', icon: 'settings', path: '/settings' },
  { id: 'profile', label: 'Profile', icon: 'user', path: '/profile' },
];
const TAB_IDS = ['home', 'play', 'puzzles', 'history'];

export const app = {
  user: null,
  stats: null,
  session: null,
  tempRecord: null,
  view: null,
  routeToken: 0,

  go(path) {
    const target = `#${path}`;
    if (location.hash === target) this.route(); else location.hash = target;
  },

  refreshStats() { if (this.user) this.stats = loadStats(this.user.id); return this.stats; },

  // ------------------------------------------------------------- game setup
  newGame(cfg) {
    cfg = { ...cfg };
    if (cfg.mode === 'engine' && cfg.colorChoice === 'random') {
      const pc = Math.random() < 0.5 ? 'w' : 'b';
      const me = { name: this.user.name, rating: this.refreshStats().rating, avatar: this.user.avatar };
      const eng = { name: 'Stockfish 19', rating: null };
      cfg.playerColor = pc; cfg.white = pc === 'w' ? me : eng; cfg.black = pc === 'w' ? eng : me;
    }
    if (cfg.mode === 'engine' || cfg.mode === 'local') cfg.autoClaimDraws = settings.get('autoClaimDraws');
    let moves = [];
    if (cfg.pgn) {
      try { const parsed = parseGame(cfg.pgn); cfg.startFen = parsed.startFen; moves = parsed.moves; }
      catch (e) { toast(e.message, 'bad'); return; }
      delete cfg.pgn;
    }
    const session = new GameSession(cfg);
    for (const m of moves) session.move({ from: m.from, to: m.to, promotion: m.promotion }, { silent: true });
    this.openGame(session);
  },
  openGame(session) {
    this.session = session;
    activeGameStore.save(this.user.id, { kind: 'game', data: session.serialize() });
    if (location.hash === '#/game') this.route(); else location.hash = '#/game';
  },

  // ---------------------------------------------------------------- session
  async setUser(user) {
    this.user = user;
    settings.load(user.id);
    installPieceSet();
    this.refreshStats();
    this.shell = null;
    this.session = null;
    if (!location.hash || location.hash === '#/' || location.hash.startsWith('#/welcome')) location.hash = '#/';
    this.route();
  },

  async logout() {
    this.view?.destroy?.(); this.view = null;
    auth.clearSession();
    this.user = null; this.shell = null; this.session = null;
    settings.load('guest');
    installPieceSet();
    this.route();
  },

  // ----------------------------------------------------------------- shell
  ensureShell() {
    if (this.shell) return;
    const root = $('#app');
    root.replaceChildren();
    const u = this.user;
    const links = NAV.map((n) => {
      const a = h('a', { href: `#${n.path}`, 'data-nav': n.id, html: `${icon(n.icon)}<span>${n.label}</span>` });
      return a;
    });
    const logoutBtn = h('button', { class: 'btn ghost icon-btn', type: 'button', title: 'Log out', 'aria-label': 'Log out', html: icon('logout') });
    logoutBtn.addEventListener('click', () => this.confirmLogout());
    this.userCard = h('div', { class: 'usercard' });
    const sidebar = h('aside', { class: 'sidebar' },
      h('div', { class: 'brand' }, h('img', { src: 'assets/logo.svg', alt: '' }), h('div', null, h('b', null, 'NOVA'), h('small', null, 'CHESS'))),
      h('nav', { class: 'nav', 'aria-label': 'Main' }, ...links),
      h('div', { class: 'spacer' }), this.userCard);
    this.userCard.append(logoutBtn);
    const tabLinks = [
      ...TAB_IDS.map((id) => { const n = NAV.find((x) => x.id === id); return h('a', { href: `#${n.path}`, 'data-nav': n.id, html: `${icon(n.icon)}<span>${n.label.replace('Play Chess', 'Play').replace('Game ', '')}</span>` }); }),
    ];
    const more = h('a', { href: '#', 'data-nav': 'more', html: `${icon('menu')}<span>More</span>` });
    more.addEventListener('click', (e) => { e.preventDefault(); this.openMore(); });
    const tabbar = h('nav', { class: 'tabbar', 'aria-label': 'Primary' }, ...tabLinks, more);
    this.mobileTop = h('div', { class: 'mobile-top' }, h('div', { class: 'brand' }, h('img', { src: 'assets/logo.svg', alt: '' }), h('div', null, h('b', null, 'NOVA CHESS'))));
    this.viewHost = h('div', { class: 'view-host' });
    const main = h('main', { class: 'main', id: 'main' }, this.mobileTop, this.viewHost);
    this.mainEl = main;
    root.append(h('div', { class: 'shell' }, sidebar, main, tabbar));
    this.shell = { sidebar, tabbar, links, tabLinks };
    this.updateUserCard();
  },

  updateUserCard() {
    if (!this.userCard) return;
    const s = this.refreshStats();
    const u = this.user;
    const av = u.isGuest ? h('div', { class: 'avatar', style: { background: 'linear-gradient(135deg,#94a3b8,#475569)' }, html: icon('user') }) : avatarEl(u.avatar);
    if (u.isGuest) av.firstChild.style.cssText = 'width:55%;height:55%';
    const logout = this.userCard.querySelector('button');
    this.userCard.replaceChildren(av, h('div', { class: 'meta' }, h('div', { class: 'name' }, u.name), h('div', { class: 'sub' }, `Est. rating ${s.rating}`)), logout);
    this.mobileTop.querySelector('.avatar')?.remove();
    const mav = u.isGuest ? h('div', { class: 'avatar sm', style: { background: 'linear-gradient(135deg,#94a3b8,#475569)' } }) : avatarEl(u.avatar, 'sm');
    this.mobileTop.append(mav);
    mav.addEventListener('click', () => this.go('/profile'));
  },

  async confirmLogout() {
    const hasGame = !!activeGameStore.load(this.user.id);
    const ok = await confirmDialog('Log out?', this.user.isGuest ? 'Guest data stays in this browser. You can continue as a guest again later.' : `You will be signed out of ${this.user.name}.${hasGame ? ' Your game in progress is saved.' : ''}`, 'Log out');
    if (ok) this.logout();
  },

  openMore() {
    const items = NAV.filter((n) => !TAB_IDS.includes(n.id));
    const list = h('div', { class: 'list' });
    let m;
    for (const n of items) {
      const b = h('button', { class: 'btn ghost block', type: 'button', style: { justifyContent: 'flex-start' }, html: `${icon(n.icon)}<span>${n.label}</span>` });
      b.addEventListener('click', () => { m.close(); this.go(n.path); });
      list.append(b);
    }
    const lo = h('button', { class: 'btn ghost block', type: 'button', style: { justifyContent: 'flex-start' }, html: `${icon('logout')}<span>Log out</span>` });
    lo.addEventListener('click', () => { m.close(); this.confirmLogout(); });
    list.append(lo);
    m = modal({ title: 'Menu', body: list, actions: [] });
  },

  setActive(id) {
    if (!this.shell) return;
    for (const a of [...this.shell.links, ...this.shell.tabLinks]) a.classList.toggle('active', a.dataset.nav === id);
  },

  // ---------------------------------------------------------------- routing
  async route() {
    const token = ++this.routeToken;
    const path = location.hash.replace(/^#/, '') || '/';
    if (!this.user) { this.showWelcome(); return; }
    this.ensureShell();
    this.view?.destroy?.();
    this.view = null;
    const host = this.viewHost;
    host.replaceChildren();
    this.mainEl.style.animation = 'none'; void this.mainEl.offsetWidth; this.mainEl.style.animation = '';
    const seg = path.split('/').filter(Boolean);
    const [a, b] = seg;
    const mount = async (fn, navId, ...args) => {
      this.setActive(navId);
      const v = await fn(host, this, ...args);
      if (token !== this.routeToken) { v?.destroy?.(); return; }
      this.view = v;
    };
    try {
      if (!a || a === 'home') await mount(mountDashboard, 'home');
      else if (a === 'play' && !b) await mount(mountPlayHub, 'play');
      else if (a === 'play' && b === 'engine') await mount(mountEngineSetup, 'engine');
      else if (a === 'play' && b === 'local') await mount(mountLocalSetup, 'play');
      else if (a === 'play' && (b === 'practice' || b === 'analysis')) {
        this.setActive('play');
        const cfg = { mode: b, playerColor: null, timeControl: null, white: { name: 'White' }, black: { name: 'Black' }, orientation: 'w' };
        this.session = new GameSession(cfg);
        activeGameStore.save(this.user.id, { kind: 'game', data: this.session.serialize() });
        location.replace('#/game');
        return;
      } else if (a === 'game') {
        this.setActive('play');
        if (!this.session) {
          const saved = activeGameStore.load(this.user.id);
          try { if (saved?.data) this.session = GameSession.restore(saved.data); } catch (e) { console.warn('restore failed', e); activeGameStore.clear(this.user.id); }
        }
        if (!this.session) { toast('No game in progress'); location.replace('#/play'); return; }
        const gv = new GameView(this, this.session);
        gv.mount(host);
        this.view = gv;
        this.setActive(this.session.cfg.mode === 'engine' ? 'engine' : 'play');
      } else if (a === 'review' && !b) await mount(mountReviewPicker, 'review');
      else if (a === 'review') await mount(mountReview, 'review', b);
      else if (a === 'puzzles') await mount(mountPuzzles, 'puzzles');
      else if (a === 'history') await mount(mountHistory, 'history');
      else if (a === 'settings') await mount(mountSettings, 'settings', b);
      else if (a === 'profile') await mount(mountProfile, 'profile');
      else { location.replace('#/'); return; }
    } catch (e) {
      console.error('[route]', e);
      host.replaceChildren(h('div', { class: 'card' }, h('h3', null, 'Something went wrong'), h('p', { class: 'muted' }, String(e.message ?? e)), h('p', null, h('a', { href: '#/' }, 'Back to home'))));
    }
    window.scrollTo(0, 0);
    this.updateUserCard?.();
  },

  showWelcome() {
    this.view?.destroy?.(); this.view = null; this.shell = null;
    const root = $('#app');
    root.replaceChildren();
    mountWelcome(root, this);
  },
};

// ---------------------------------------------------------------------- boot
async function boot() {
  const sub = $('#boot-sub');
  window.addEventListener('error', (e) => console.error('[window.error]', e.message));
  window.addEventListener('unhandledrejection', (e) => console.error('[unhandled]', e.reason));
  try {
    await db.init();
    if (isMemoryMode()) toast('Browser storage is unavailable — data will not persist after closing this tab.', 'bad', 7000);
    settings.load('guest');
    installPieceSet();
    settings.on('change', () => installPieceSet());
    const user = await auth.restoreSession();
    $('#app').hidden = false;
    if (user) {
      app.user = user;
      settings.load(user.id);
      installPieceSet();
      if (location.hash.startsWith('#/welcome')) location.hash = '#/';
    }
    window.addEventListener('hashchange', () => app.route());
    window.addEventListener('pagehide', () => { try { app.view?.persist?.(); } catch { /* ignore */ } });
    await app.route();
  } catch (e) {
    console.error('boot failed', e);
    if (sub) sub.textContent = `Failed to start: ${e.message ?? e}`;
    return;
  }
  const bootEl = $('#boot');
  bootEl.classList.add('done');
  setTimeout(() => bootEl.remove(), 500);
  // Warm the engine in the background so the first game starts instantly.
  setTimeout(() => { if (app.user) engines.play.init().catch(() => {}); }, 800);
}
boot();
window.novaApp = app; // handy for debugging in the console
