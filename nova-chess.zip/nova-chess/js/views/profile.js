// Profile: avatar, statistics (with the local rating clearly labelled as an estimate), best performances.
import { h, icon, toast, modal, fmtDate, AVATARS, avatarEl } from '../util.js';
import { db } from '../store.js';
import * as auth from '../auth.js';
import { winRate, favoriteMode } from '../stats.js';
import { gameTitle, resultChip } from './dashboard.js';
import { PUZZLES } from '../puzzle-data.js';

export async function mountProfile(root, app) {
  const user = app.user;
  const stats = app.refreshStats();
  const games = await db.listGames(user.id);
  const progress = await db.getProgress(user.id);
  const el = h('div');

  const avatar = user.isGuest ? h('div', { class: 'avatar lg', style: { background: 'linear-gradient(135deg,#94a3b8,#475569)' }, html: icon('user') }) : avatarEl(user.avatar, 'lg');
  const editBtn = h('button', { class: 'btn sm', type: 'button' }, 'Change avatar');
  editBtn.addEventListener('click', async () => {
    let sel = user.avatar;
    const grid = h('div', { class: 'avatar-grid' });
    AVATARS.forEach((_, i) => {
      const b = h('button', { type: 'button', class: i === sel ? 'on' : '', 'aria-label': `Avatar ${i + 1}` }, avatarEl(i));
      b.addEventListener('click', () => { sel = i; for (const x of grid.children) x.classList.toggle('on', x === b); });
      grid.append(b);
    });
    const ok = await modal({ title: 'Choose an avatar', body: grid, actions: [{ label: 'Cancel', value: false }, { label: 'Save', value: true, kind: 'primary' }] });
    if (ok) { await auth.updateUser(user.id, { avatar: sel }); user.avatar = sel; app.updateUserCard(); app.route(); toast('Avatar updated', 'good'); }
  });
  const pwBtn = h('button', { class: 'btn sm', type: 'button' }, 'Change password');
  pwBtn.addEventListener('click', async () => {
    const mk = (label, ac) => { const i = h('input', { class: 'input', type: 'password', autocomplete: ac }); return [h('div', { class: 'field' }, h('label', null, label), i), i]; };
    const [f1, cur] = mk('Current password', 'current-password'), [f2, nw] = mk('New password', 'new-password'), [f3, cf] = mk('Confirm new password', 'new-password');
    const err = h('div', { class: 'error-text' });
    const ok = await modal({ title: 'Change password', body: h('div', { style: { display: 'grid', gap: '.7rem' } }, f1, f2, f3, err), actions: [{ label: 'Cancel', value: false }, { label: 'Update', value: true, kind: 'primary', onClick: async () => { try { await auth.changePassword(user.id, cur.value, nw.value, cf.value); } catch (e) { err.textContent = e.message; return false; } } }] });
    if (ok) toast('Password changed', 'good');
  });

  const head = h('div', { class: 'card', style: { marginBottom: '1rem' } },
    h('div', { class: 'profile-head' }, avatar,
      h('div', { style: { flex: 1, minWidth: '200px' } }, h('h1', { style: { fontSize: '1.6rem' } }, user.name),
        h('div', { class: 'muted', style: { fontSize: '.88rem' } }, user.isGuest ? 'Guest profile — stored on this device only' : `Local account · created ${fmtDate(user.createdAt)}`),
        h('div', { style: { display: 'flex', gap: '.5rem', marginTop: '.7rem', flexWrap: 'wrap' } }, ...(user.isGuest ? [] : [editBtn, pwBtn]))),
      h('div', { style: { textAlign: 'right' } }, h('div', { class: 'k label' }, 'Estimated local rating'), h('div', { style: { fontFamily: 'var(--font-display)', fontSize: '2.4rem', fontWeight: 700, lineHeight: 1 } }, String(stats.rating)), h('div', { class: 'hint' }, 'Not a FIDE, Chess.com or Lichess rating'))));
  if (user.isGuest) head.append(h('div', { class: 'notice info', style: { marginTop: '1rem' } }, 'You are using guest mode. Log out and register to keep a named profile (still stored only in this browser).'));
  el.append(head);

  const wr = winRate(stats);
  const stat = (k, v, s) => h('div', { class: 'stat' }, h('div', { class: 'k' }, k), h('div', { class: 'v' }, v), h('div', { class: 's' }, s ?? ''));
  el.append(h('div', { class: 'grid stats-grid', style: { marginBottom: '1rem' } },
    stat('Games played', String(stats.played), `vs Stockfish ${stats.byMode.engine} · local ${stats.byMode.local}`),
    stat('Wins', String(stats.wins), ''), stat('Losses', String(stats.losses), ''), stat('Draws', String(stats.draws), ''),
    stat('Win rate', wr == null ? '—' : `${wr}%`, 'wins ÷ finished games'),
    stat('Favorite mode', favoriteMode(stats) ?? '—', 'most played')));

  const solved = Object.keys(progress.solved ?? {}).length;
  const firstTry = Object.values(progress.solved ?? {}).filter((s) => s.firstTry).length;
  const best = (label, v) => h('div', { class: 'row', style: { gridTemplateColumns: '1fr auto' } }, h('div', { class: 't' }, label), h('b', null, v));
  el.append(h('div', { class: 'grid dash-cols' },
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Best performances')), h('div', { class: 'list' },
      best('Strongest engine level beaten', stats.bestWin ? `${stats.bestWin.level} (~${stats.bestWin.elo})` : '—'),
      best('Fastest win', stats.fastestWin ? `${Math.ceil(stats.fastestWin.plies / 2)} moves` : '—'),
      best('Longest game', stats.longestGame ? `${Math.ceil(stats.longestGame.plies / 2)} moves` : '—'),
      best('Best review accuracy', stats.bestAccuracy ? `${stats.bestAccuracy.value.toFixed(1)}%` : '—'),
      best('Peak estimated rating', String(stats.peak)),
      best('Best win streak', String(stats.bestStreak)),
      best('Puzzles solved', `${solved} / ${PUZZLES.length}${solved ? ` (${firstTry} first try)` : ''}`),
      best('Best puzzle streak', String(progress.bestStreak ?? 0)))),
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Game history')),
      games.length ? h('div', { class: 'list' }, ...games.slice(0, 8).map((g) => { const b = h('button', { class: 'btn sm', type: 'button' }, 'Review'); b.addEventListener('click', () => app.go(`/review/${g.id}`)); return h('div', { class: 'row' }, resultChip(g), h('div', { style: { minWidth: 0 } }, h('div', { class: 't' }, gameTitle(g)), h('div', { class: 'd' }, fmtDate(g.date))), b); })) : h('div', { class: 'empty' }, 'No games yet.'))));
  root.append(el);
  return { destroy: () => el.remove() };
}
