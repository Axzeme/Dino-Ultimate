// Welcome screen: login, register, guest mode, password recovery.
import { h, icon, toast, modal } from '../util.js';
import * as auth from '../auth.js';

function passwordField(label, { autocomplete = 'current-password', id } = {}) {
  const input = h('input', { class: 'input', type: 'password', autocomplete, id, required: true, spellcheck: 'false' });
  const eye = h('button', { class: 'btn ghost icon-btn eye', type: 'button', 'aria-label': 'Show password', title: 'Show / hide password', html: icon('eye') });
  eye.addEventListener('click', () => {
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    eye.innerHTML = icon(show ? 'eyeoff' : 'eye');
    eye.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });
  const el = h('div', { class: 'field' }, h('label', { for: id }, label), h('div', { class: 'input-wrap' }, input, eye));
  return { el, input };
}

function textField(label, { id, type = 'text', autocomplete, placeholder, maxlength } = {}) {
  const input = h('input', { class: 'input', type, id, autocomplete, placeholder, maxlength, required: true, spellcheck: 'false', autocapitalize: 'off' });
  return { el: h('div', { class: 'field' }, h('label', { for: id }, label), input), input };
}

async function showRecoveryCode(code, title = 'Save your recovery code') {
  const box = h('div', { class: 'code-box' }, code);
  await modal({
    title,
    body: h('div', { style: { display: 'grid', gap: '.8rem' } },
      h('p', null, 'This code is the only way to reset your password on this device. Nova Chess stores only a hash of it, so it cannot be shown again.'),
      box,
      h('p', { class: 'hint' }, 'Write it down or store it in a password manager.')),
    actions: [
      { label: 'Copy code', value: false, onClick: async () => { try { await navigator.clipboard.writeText(code); toast('Copied', 'good'); } catch { toast('Select the code and copy it manually'); } return false; } },
      { label: 'I saved it', value: true, kind: 'primary' },
    ],
    dismissible: false,
  });
}

export function mountWelcome(root, app) {
  let tab = 'login';
  const authHost = h('div', { class: 'auth-pane' });

  const board = h('div', { class: 'hero-board', 'aria-hidden': 'true' });
  for (let i = 0; i < 64; i++) board.append(h('i', { class: ((i % 8) + Math.floor(i / 8)) % 2 ? 'd' : 'l' }));

  const feat = (ic, t) => h('div', { html: `${icon(ic)}<span>${t}</span>` });
  const hero = h('section', { class: 'hero' },
    h('div', { class: 'logo-row' }, h('img', { src: 'assets/logo.svg', alt: '' }), h('div', null, h('h1', null, 'NOVA ', h('span', null, 'CHESS')))),
    h('p', { class: 'tagline' }, 'A full chess platform in your browser. Play a real Stockfish engine, watch a live evaluation bar, review every move and sharpen your tactics — no install, no server.'),
    h('div', { class: 'feature-list' },
      feat('cpu', 'Stockfish 19 in a Web Worker'), feat('review', 'Move-by-move game review'),
      feat('puzzle', 'Verified tactics puzzles'), feat('users', 'Local two-player & analysis'),
      feat('download', 'PGN import & export'), feat('settings', 'Themes, pieces & sounds')),
    board);

  function render() {
    authHost.replaceChildren(card());
  }

  function card() {
    const seg = h('div', { class: 'seg accent', role: 'tablist' });
    for (const [id, label] of [['login', 'Log in'], ['register', 'Register']]) {
      const b = h('button', { type: 'button', class: tab === id ? 'on' : '', role: 'tab', 'aria-selected': String(tab === id) }, label);
      b.addEventListener('click', () => { tab = id; render(); });
      seg.append(b);
    }
    const form = tab === 'login' ? loginForm() : tab === 'register' ? registerForm() : forgotForm();
    const guest = h('button', { class: 'btn block', type: 'button', html: `${icon('user')}<span>Continue as guest</span>` });
    guest.addEventListener('click', () => app.setUser(auth.startGuestSession()));
    return h('div', { class: 'auth-card' },
      tab === 'forgot' ? h('h2', { style: { fontSize: '1.2rem' } }, 'Reset password') : seg,
      form,
      tab === 'forgot' ? '' : h('div', { style: { display: 'grid', gap: '.8rem', marginTop: '1rem' } }, h('div', { class: 'or' }, 'or'), guest),
      h('p', { class: 'demo-note', style: { marginTop: '1rem' } }, 'Local demo accounts: stored only in this browser (no server). Passwords are salted and hashed with PBKDF2 and never saved in plain text, but this is not a substitute for real server-backed authentication.'));
  }

  function loginForm() {
    const u = textField('Username', { id: 'li-user', autocomplete: 'username' });
    const p = passwordField('Password', { id: 'li-pass' });
    const remember = h('input', { type: 'checkbox', class: 'check', id: 'li-rem' });
    const err = h('div', { class: 'error-text', role: 'alert' });
    const submit = h('button', { class: 'btn primary lg block', type: 'submit' }, 'Log in');
    const forgot = h('button', { class: 'link', type: 'button' }, 'Forgot password?');
    forgot.addEventListener('click', () => { tab = 'forgot'; render(); });
    const form = h('form', { class: 'auth-form', novalidate: true }, u.el, p.el,
      h('div', { class: 'auth-foot' }, h('label', { class: 'checkrow', for: 'li-rem' }, remember, 'Remember me'), forgot), err, submit);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.textContent = '';
      if (!u.input.value.trim() || !p.input.value) { err.textContent = 'Enter your username and password.'; return; }
      submit.disabled = true; submit.textContent = 'Checking…';
      try {
        const user = await auth.login(u.input.value, p.input.value, remember.checked);
        app.setUser(user);
      } catch (ex) { err.textContent = ex.message; submit.disabled = false; submit.textContent = 'Log in'; p.input.select(); }
    });
    setTimeout(() => u.input.focus(), 50);
    return form;
  }

  function registerForm() {
    const u = textField('Username', { id: 'rg-user', autocomplete: 'username', maxlength: 20 });
    const p = passwordField('Password', { id: 'rg-pass', autocomplete: 'new-password' });
    const c = passwordField('Confirm password', { id: 'rg-conf', autocomplete: 'new-password' });
    const meter = h('div', { class: 'strength' }, h('i'));
    const hint = h('div', { class: 'hint' }, 'At least 8 characters. Longer and mixed is stronger.');
    p.input.addEventListener('input', () => {
      const s = auth.passwordStrength(p.input.value);
      const bar = meter.firstChild;
      bar.style.width = `${(s / 4) * 100}%`;
      bar.style.background = ['var(--bad)', 'var(--bad)', 'var(--warn)', 'var(--good)', 'var(--good)'][s];
    });
    const remember = h('input', { type: 'checkbox', class: 'check', id: 'rg-rem' });
    const err = h('div', { class: 'error-text', role: 'alert' });
    const submit = h('button', { class: 'btn primary lg block', type: 'submit' }, 'Create account');
    const form = h('form', { class: 'auth-form', novalidate: true }, u.el, h('div', { class: 'field' }, p.el, meter, hint), c.el,
      h('label', { class: 'checkrow', for: 'rg-rem' }, remember, 'Remember me on this device'), err, submit);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.textContent = '';
      submit.disabled = true; submit.textContent = 'Creating account…';
      try {
        const { recoveryCode } = await auth.register(u.input.value.trim(), p.input.value, c.input.value);
        await showRecoveryCode(recoveryCode);
        const user = await auth.login(u.input.value.trim(), p.input.value, remember.checked);
        toast(`Welcome to Nova Chess, ${user.name}!`, 'good');
        app.setUser(user);
      } catch (ex) { err.textContent = ex.message; submit.disabled = false; submit.textContent = 'Create account'; }
    });
    setTimeout(() => u.input.focus(), 50);
    return form;
  }

  function forgotForm() {
    const u = textField('Username', { id: 'fg-user', autocomplete: 'username' });
    const code = textField('Recovery code', { id: 'fg-code', placeholder: 'XXXX-XXXX-XXXX-XXXX', autocomplete: 'off' });
    const p = passwordField('New password', { id: 'fg-pass', autocomplete: 'new-password' });
    const c = passwordField('Confirm new password', { id: 'fg-conf', autocomplete: 'new-password' });
    const err = h('div', { class: 'error-text', role: 'alert' });
    const submit = h('button', { class: 'btn primary lg block', type: 'submit' }, 'Reset password');
    const back = h('button', { class: 'link', type: 'button' }, '← Back to log in');
    back.addEventListener('click', () => { tab = 'login'; render(); });
    const form = h('form', { class: 'auth-form', novalidate: true },
      h('div', { class: 'notice info' }, 'Without a server there is no email to send a link to. Use the recovery code shown when you registered.'),
      u.el, code.el, p.el, c.el, err, submit, back);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.textContent = '';
      submit.disabled = true; submit.textContent = 'Resetting…';
      try {
        const newCode = await auth.recoverPassword(u.input.value, code.input.value, p.input.value, c.input.value);
        await showRecoveryCode(newCode, 'Password reset — new recovery code');
        toast('Password changed. Log in with your new password.', 'good');
        tab = 'login'; render();
      } catch (ex) { err.textContent = ex.message; submit.disabled = false; submit.textContent = 'Reset password'; }
    });
    return form;
  }

  root.append(h('div', { class: 'welcome' }, hero, authHost));
  render();
}
