// Home dashboard: stats, resume card, quick play, recent games, puzzle progress.
import { h, icon, toast, fmtDate, confirmDialog } from '../util.js';
import { db, settings, activeGameStore } from '../store.js';
import { LEVELS } from '../engine.js';
import { winRate } from '../stats.js';
import { buildEngineCfg } from './play.js';
import { GameSession } from '../game.js';
import { PUZZLES } from '../puzzle-data.js';

export function gameTitle(g) {
  if (g.mode === 'engine') return `vs Stockfish${g.levelName ? ` (${g.levelName})` : ''}`;
  return `${g.white} vs ${g.black}`;
}
export function gameOutcome(g) {
  // 'w' win, 'l' loss, 'd' draw, null = not attributable (two-player / import)
  if (g.result === '1/2-1/2') return 'd';
  if (g.result === '*' || !g.playerColor) return null;
  return (g.result === '1-0') === (g.playerColor === 'w') ? 'w' : 'l';
}
export function resultChip(g) {
  const o = gameOutcome(g);
  if (o) return h('span', { class: `res ${o}` }, { w: 'W', l: 'L', d: '½' }[o]);
  return h('span', { class: 'res d', title: g.result }, g.result === '1/2-1/2' ? '½' : g.result === '*' ? '•' : '⚑');
}

function sparkline(history) {
  if (!history || history.length < 2) return null;
  const vals = history.map((p) => p.r);
  const min = Math.min(...vals), max = Math.max(...vals);
  const w = 240, hgt = 54, pad = 4;
  const pts = vals.map((v, i) => `${(pad + (i / (vals.length - 1)) * (w - pad * 2)).toFixed(1)},${(hgt - pad - ((v - min) / Math.max(1, max - min)) * (hgt - pad * 2)).toFixed(1)}`).join(' ');
  const el = h('div', { html: `<svg viewBox="0 0 ${w} ${hgt}" width="100%" height="${hgt}" role="img" aria-label="Estimated rating trend"><polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/></svg>` });
  return el;
}

export async function mountDashboard(root, app) {
  const user = app.user;
  const stats = app.refreshStats();
  const el = h('div');
  const games = await db.listGames(user.id);
  const progress = await db.getProgress(user.id);
  const saved = activeGameStore.load(user.id);

  const hour = new Date().getHours();
  const greet = hour < 5 ? 'Good night' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const head = h('div', { class: 'page-head' }, h('div', null, h('h1', null, `${greet}, ${user.name}`), h('p', null, user.isGuest ? 'You are playing as a guest. Register to keep a named profile on this device.' : 'Ready for your next game?')));
  const playBtn = h('button', { class: 'btn primary lg', type: 'button', html: `${icon('cpu')}<span>Play Stockfish</span>` });
  playBtn.addEventListener('click', () => app.go('/play/engine'));
  head.append(playBtn);
  el.append(head);

  // Resume
  if (saved?.data && !saved.data.result && saved.data.uci?.length >= 0 && saved.data.cfg?.mode) {
    const d = saved.data, m = d.cfg.mode;
    const label = { engine: `vs Stockfish${d.cfg.engineLevel?.name ? ` (${d.cfg.engineLevel.name})` : ''}`, local: 'Local two-player', practice: 'Practice board', analysis: 'Analysis board' }[m] ?? 'Game';
    if (d.uci.length > 0 || m === 'practice' || m === 'analysis') {
      const resume = h('button', { class: 'btn primary', type: 'button' }, 'Resume');
      const discard = h('button', { class: 'btn', type: 'button' }, 'Discard');
      resume.addEventListener('click', () => { try { app.session = GameSession.restore(d); app.go('/game'); } catch { toast('That saved game could not be restored', 'bad'); activeGameStore.clear(user.id); app.go('/'); } });
      discard.addEventListener('click', async () => { if (await confirmDialog('Discard saved game?', 'The game in progress will be lost.', 'Discard', 'danger')) { activeGameStore.clear(user.id); app.route(); } });
      el.append(h('div', { class: 'card resume', style: { marginBottom: '1rem' } },
        h('div', null, h('b', null, 'Game in progress'), h('div', { class: 'muted', style: { fontSize: '.86rem' } }, `${label} · ${Math.ceil(d.uci.length / 2)} moves · saved ${fmtDate(new Date(d.savedAt).toISOString(), true)}`)),
        h('div', { style: { display: 'flex', gap: '.5rem' } }, discard, resume)));
    }
  }

  // Stats
  const wr = winRate(stats);
  const stat = (k, v, s) => h('div', { class: 'stat' }, h('div', { class: 'k' }, k), h('div', { class: 'v' }, v), h('div', { class: 's' }, s));
  el.append(h('div', { class: 'grid stats-grid', style: { marginBottom: '1rem' } },
    stat('Est. local rating', String(stats.rating), stats.ratedGames ? `Peak ${stats.peak} · ${stats.ratedGames} rated` : 'Play rated games vs Stockfish'),
    stat('Games played', String(stats.played), `${stats.wins}W · ${stats.draws}D · ${stats.losses}L`),
    stat('Win rate', wr == null ? '—' : `${wr}%`, 'wins ÷ finished games'),
    stat('Win streak', String(stats.streak), `Best ${stats.bestStreak}`)));

  // Quick play
  const quick = (ic, title, text, fn) => { const b = h('button', { class: 'quick', type: 'button' }, h('div', { class: 'qi', html: icon(ic) }), h('b', null, title), h('span', null, text)); b.addEventListener('click', fn); return b; };
  const lvl = (id) => LEVELS.find((l) => l.id === id);
  const qp = (id, tc) => () => app.newGame(buildEngineCfg(app, { colorChoice: 'random', tcId: tc, levelOverride: { ...lvl(id), custom: false } }));
  el.append(h('div', { class: 'card', style: { marginBottom: '1rem' } },
    h('div', { class: 'card-head' }, h('h3', null, 'Quick play')),
    h('div', { class: 'grid quick-grid' },
      quick('bolt', 'Blitz 3+2', 'vs Stockfish · Intermediate', qp('intermediate', '3+2')),
      quick('cpu', 'Rapid 10+5', 'vs Stockfish · Advanced', qp('advanced', '10+5')),
      quick('trophy', 'Challenge', 'vs Stockfish · Master, no clock', qp('master', 'none')),
      quick('users', 'Local game', 'Two players, one device', () => app.go('/play/local')),
      quick('bulb', 'Analysis board', 'Explore with engine lines', () => app.go('/play/analysis')),
      quick('puzzle', 'Puzzles', 'Train tactics', () => app.go('/puzzles')))));

  // Recent + side
  const recent = games.slice(0, 5);
  const list = h('div', { class: 'list' });
  if (!recent.length) list.append(h('div', { class: 'empty' }, 'No games yet — your finished games will appear here.'));
  for (const g of recent) {
    const open = h('button', { class: 'btn sm', type: 'button' }, 'Review');
    open.addEventListener('click', () => app.go(`/review/${g.id}`));
    list.append(h('div', { class: 'row' }, resultChip(g), h('div', { style: { minWidth: 0 } }, h('div', { class: 't' }, gameTitle(g)), h('div', { class: 'd' }, `${fmtDate(g.date)} · ${Math.ceil(g.plies / 2)} moves`)), open));
  }
  const all = h('button', { class: 'btn ghost sm', type: 'button' }, 'View all');
  all.addEventListener('click', () => app.go('/history'));

  const solved = Object.keys(progress.solved ?? {}).length;
  const spark = sparkline(stats.ratingHistory);
  const side = h('div', { style: { display: 'grid', gap: '1rem' } },
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Puzzle progress')),
      h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '.5rem' } }, h('span', { style: { fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 700 } }, String(solved)), h('span', { class: 'muted' }, `of ${PUZZLES.length} solved`)),
      h('div', { class: 'progress', style: { margin: '.6rem 0' } }, (() => { const i = h('i'); i.style.width = `${PUZZLES.length ? (solved / PUZZLES.length) * 100 : 0}%`; return i; })()),
      (() => { const b = h('button', { class: 'btn sm', type: 'button' }, 'Continue puzzles'); b.addEventListener('click', () => app.go('/puzzles')); return b; })()),
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Rating trend'), h('span', { class: 'pill' }, 'estimated, local')),
      spark ?? h('div', { class: 'muted', style: { fontSize: '.86rem' } }, 'Finish rated games against Stockfish to see your trend. This rating is a local estimate, not an official one.')));

  el.append(h('div', { class: 'grid dash-cols' },
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h3', null, 'Recent games'), all), list), side));
  root.append(el);
  return { destroy: () => el.remove() };
}
