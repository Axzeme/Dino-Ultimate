// Game review: Stockfish analyses every position; moves are classified from the measured evaluation change.
import { Chess } from '../../vendor/chess.js';
import { h, icon, toast, fmtDate, download, esc } from '../util.js';
import { db, settings } from '../store.js';
import { Board, fenToMap } from '../board.js';
import { START_FEN, capturedUpTo, materialOf, REASON_TEXT } from '../game.js';
import { engines, fmtScore, barPercent, cpToWin, scoreToCp } from '../engine.js';
import { CLASSES, CLASS_BY_ID, analyzePositions, summarize, replay, graphSeries } from '../analysis.js';
import { parseGame, recordFileName } from '../pgn.js';
import { play, playForMove } from '../audio.js';
import { pieceEl } from '../pieces.js';
import { recordAccuracy } from '../stats.js';
import { gameTitle, resultChip } from './dashboard.js';
import { importPgnFlow } from './history.js';

const DEPTHS = [['Fast', 12], ['Standard', 16], ['Deep', 20], ['Very deep', 24]];

function sanLine(fen, pv, n = 7) {
  const c = new Chess(fen); const out = [];
  for (const u of pv.slice(0, n)) { try { out.push(c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }).san); } catch { break; } }
  return out;
}
function sanOfUci(fen, u) {
  if (!u) return null;
  try { return new Chess(fen).move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }).san; } catch { return u; }
}

export async function mountReview(root, app, id) {
  let rec = null;
  if (id === 'tmp') rec = app.tempRecord;
  else rec = await db.getGame(id);
  if (!rec || rec.userId !== app.user.id && id !== 'tmp') {
    const el = h('div', { class: 'card' }, h('h3', null, 'Game not found'), h('p', { class: 'muted' }, 'That game is no longer in your history.'), (() => { const b = h('button', { class: 'btn', type: 'button' }, 'Open game history'); b.addEventListener('click', () => app.go('/history')); return b; })());
    root.append(el);
    return { destroy: () => el.remove() };
  }
  const view = new ReviewView(app, rec);
  try { view.mount(root); } catch (e) {
    console.error(e);
    root.append(h('div', { class: 'card' }, h('h3', null, 'This game could not be opened'), h('p', { class: 'muted' }, String(e.message ?? e))));
  }
  return view;
}

class ReviewView {
  constructor(app, rec) {
    this.app = app; this.rec = rec;
    this.destroyed = false;
    this.cancelled = false;
    this.running = false;
    this.ply = 0;
    this.showBest = true;
    this.token = 0;
  }

  mount(root) {
    const rec = this.rec;
    const parsed = parseGame(rec.pgn);
    this.startFen = parsed.startFen || rec.startFen || START_FEN;
    const rp = replay(this.startFen, parsed.moves);
    this.fens = rp.fens; this.verbose = rp.verbose;
    this.headers = parsed.headers;
    this.evals = this.fens.map(() => null);
    this.sum = null;
    this.depth = settings.get('analysisDepth') >= 16 ? settings.get('analysisDepth') : 16;
    this.movetime = Math.max(200, settings.get('analysisTime'));
    if (rec.analysis?.evals?.length === this.fens.length) {
      this.evals = rec.analysis.evals; this.depth = rec.analysis.depth ?? this.depth; this.movetime = rec.analysis.movetime ?? this.movetime;
    }
    this.el = h('div', { class: 'game' });
    root.append(this.el);

    this.evalEl = h('div', { class: 'evalbar' }, h('div', { class: 'fill' }), h('div', { class: 'mid' }), (this.evalVal = h('div', { class: 'val bottom on-white mono' }, '0.0')));
    this.topSlot = h('div'); this.bottomSlot = h('div');
    this.boardHost = h('div', { class: 'board-wrap' });
    this.strips = { w: this.makeStrip('w'), b: this.makeStrip('b') };
    const ctl = h('div', { class: 'controls' });
    const mk = (ic, label, fn) => { const b = h('button', { class: 'btn', type: 'button', title: label, 'aria-label': label }, h('span', { html: icon(ic) }), h('span', { class: 'lbl' }, label)); b.addEventListener('click', fn); return b; };
    this.bestBtn = mk('bulb', 'Best move', () => { this.showBest = !this.showBest; this.bestBtn.classList.toggle('primary', this.showBest); this.renderPosition(false); });
    this.bestBtn.classList.add('primary');
    ctl.append(mk('first', 'Start', () => this.goTo(0)), mk('prev', 'Back', () => this.goTo(this.ply - 1)), mk('next', 'Next', () => this.goTo(this.ply + 1)), mk('last', 'End', () => this.goTo(this.verbose.length)), mk('flip', 'Flip', () => { this.board.flip(); this.placeStrips(); this.updateEvalBar(); this.renderPosition(false); }), this.bestBtn);
    this.el.append(h('div', { class: 'game-main' }, this.evalEl, h('div', { class: 'board-col' }, this.topSlot, this.boardHost, this.bottomSlot, ctl)));

    // side
    this.headCard = h('div', { class: 'panel' });
    this.coachEl = h('div', { class: 'coach' });
    this.graphEl = h('div');
    this.movesEl = h('div', { class: 'moves' });
    this.movesEl.addEventListener('click', (e) => { const c = e.target.closest('[data-ply]'); if (c) this.goTo(Number(c.dataset.ply)); });
    this.altEl = h('div', { class: 'lines' });
    this.ctrlEl = h('div');
    this.sideEl = h('div', { class: 'side' });
    this.panelToggle = h('button', { class: 'btn panel-toggle', type: 'button' }, h('span', null, 'Summary, moves & engine'), h('span', { html: icon('chevdown') }));
    this.panelToggle.addEventListener('click', () => this.sideEl.classList.toggle('collapsed'));
    const body = h('div', { class: 'panel' }, h('div', { class: 'tabpane', style: { display: 'grid', gap: '.8rem' } }, this.graphEl, this.coachEl, this.altEl, this.movesEl, this.ctrlEl));
    this.sideEl.append(this.headCard, this.panelToggle, body);
    if (matchMedia('(max-width: 860px)').matches) this.sideEl.classList.add('collapsed');
    this.el.append(this.sideEl);

    this.board = new Board(this.boardHost, { interactive: () => false });
    this.placeStrips();
    this._key = (e) => {
      if (e.target.closest?.('input, textarea, select')) return;
      if (document.querySelector('.modal-back')) return;
      if (e.key === 'ArrowLeft') { e.preventDefault(); this.goTo(this.ply - 1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); this.goTo(this.ply + 1); }
      else if (e.key === 'Home' || e.key === 'ArrowUp') { e.preventDefault(); this.goTo(0); }
      else if (e.key === 'End' || e.key === 'ArrowDown') { e.preventDefault(); this.goTo(this.verbose.length); }
      else if (e.key === 'f' || e.key === 'F') { this.board.flip(); this.placeStrips(); this.updateEvalBar(); this.renderPosition(false); }
    };
    document.addEventListener('keydown', this._key);

    // orient to the player's side
    if (rec.playerColor === 'b') this.board.setOrientation('b');
    this.placeStrips();

    this.recompute();
    this.buildControls();
    this.renderAll(false);
    if (!rec.analysis && !this.evals.every(Boolean)) this.startAnalysis();
  }

  makeStrip(color) {
    const nm = h('div', { class: 'nm' }); const cap = h('div', { class: 'captured' }); const acc = h('span', { class: 'pill' });
    const root = h('div', { class: 'strip' }, h('div', { class: 'avatar sm', style: { background: color === 'w' ? '#e9e6dc' : '#2a2d35' } }, (() => { const p = pieceEl(color, 'K', ''); p.style.cssText = 'width:80%;height:80%'; return p; })()), h('div', { class: 'who' }, nm, cap), acc);
    return { root, nm, cap, acc, color };
  }
  placeStrips() {
    const bottom = this.board.orientation, top = bottom === 'w' ? 'b' : 'w';
    this.topSlot.replaceChildren(this.strips[top].root);
    this.bottomSlot.replaceChildren(this.strips[bottom].root);
    this.evalEl.classList.toggle('flipped', bottom === 'b');
  }

  // ------------------------------------------------------------ analysis
  recompute() {
    this.sum = summarize(this.fens, this.verbose, this.evals);
  }

  async startAnalysis(force = false) {
    if (this.running) return;
    if (force) this.evals = this.fens.map(() => null);
    this.running = true; this.cancelled = false;
    const token = ++this.token;
    this.buildControls();
    try {
      const ea = engines.analysis;
      await ea.setOptions({ 'Skill Level': 20, UCI_LimitStrength: false, Hash: settings.get('hash'), Threads: settings.get('threads') });
      const multipv = Math.max(2, settings.get('multiPV'));
      const total = this.fens.length;
      let lastPaint = 0;
      this.evals = await analyzePositions({
        fens: this.fens, engine: ea, depth: this.depth, movetime: this.movetime, multipv, cache: this.evals,
        isCancelled: () => this.cancelled || this.destroyed || token !== this.token,
        onProgress: (done, tot, evals) => {
          if (this.destroyed) return;
          this.evals = evals;
          this.progress = done / tot;
          const now = performance.now();
          if (now - lastPaint > 250 || done === tot) { lastPaint = now; this.recompute(); this.renderAll(false); this.updateProgress(done, tot); }
        },
      });
      if (this.destroyed) return;
      this.recompute();
      const complete = this.evals.every(Boolean);
      if (complete) {
        this.rec.analysis = { depth: this.depth, movetime: this.movetime, multipv, evals: this.evals, at: Date.now() };
        if (this.rec.id != null) { try { await db.putGame(this.rec); } catch (e) { console.warn('could not cache analysis', e); } }
        const pc = this.rec.playerColor;
        if (pc && this.sum.accuracy[pc] != null) recordAccuracy(this.app.user.id, this.sum.accuracy[pc], this.rec.date);
        toast('Analysis complete', 'good');
      }
    } catch (e) {
      console.error('[review]', e);
      if (!this.destroyed) toast(`Analysis stopped: ${e.message ?? e}`, 'bad', 5000);
    } finally {
      if (token === this.token) { this.running = false; this.progress = null; }
      if (!this.destroyed) { this.buildControls(); this.renderAll(false); }
    }
  }

  cancelAnalysis() { this.cancelled = true; engines.analysis.stop(); }

  buildControls() {
    if (!this.ctrlEl) return;
    const depthSel = h('select', { class: 'select', 'aria-label': 'Analysis depth' });
    for (const [n, d] of DEPTHS) depthSel.append(h('option', { value: d, selected: d === this.depth }, `${n} (depth ${d})`));
    if (!DEPTHS.some(([, d]) => d === this.depth)) depthSel.append(h('option', { value: this.depth, selected: true }, `Custom (depth ${this.depth})`));
    depthSel.addEventListener('change', () => { this.depth = Number(depthSel.value); });
    const timeSel = h('select', { class: 'select', 'aria-label': 'Time per move' });
    for (const t of [150, 300, 500, 1000, 2000, 4000]) timeSel.append(h('option', { value: t, selected: t === this.movetime }, `${t < 1000 ? `${t} ms` : `${t / 1000} s`} / position`));
    if (![150, 300, 500, 1000, 2000, 4000].includes(this.movetime)) timeSel.append(h('option', { value: this.movetime, selected: true }, `${this.movetime} ms / position`));
    timeSel.addEventListener('change', () => { this.movetime = Number(timeSel.value); });
    const done = this.evals.filter(Boolean).length;
    this.progressBar = h('div', { class: 'progress' }, h('i')); this.progressText = h('div', { class: 'hint' });
    const go = h('button', { class: 'btn primary sm', type: 'button' }, this.running ? 'Cancel' : done === this.fens.length ? 'Re-analyze' : done ? 'Continue analysis' : 'Analyze');
    go.addEventListener('click', () => { if (this.running) this.cancelAnalysis(); else this.startAnalysis(done === this.fens.length || (this.rec.analysis && (this.rec.analysis.depth !== this.depth || this.rec.analysis.movetime !== this.movetime))); });
    const acts = h('div', { style: { display: 'flex', gap: '.4rem', flexWrap: 'wrap' } }, go);
    const dl = h('button', { class: 'btn sm', type: 'button', html: `${icon('download')}<span>PGN</span>` });
    dl.addEventListener('click', () => download(recordFileName(this.rec), this.rec.pgn, 'application/x-chess-pgn'));
    acts.append(dl);
    if (this.rec.id == null) {
      const sv = h('button', { class: 'btn sm', type: 'button', html: `${icon('check')}<span>Save to history</span>` });
      sv.addEventListener('click', async () => { this.rec.id = await db.addGame(this.rec); sv.remove(); toast('Saved to Game History', 'good'); });
      acts.append(sv);
    }
    const cont = h('button', { class: 'btn sm', type: 'button' }, 'Play from here');
    cont.addEventListener('click', () => this.playFromHere());
    acts.append(cont);
    this.ctrlEl.replaceChildren(h('div', { class: 'label', style: { marginBottom: '.3rem' } }, 'Analysis settings'), h('div', { class: 'two' }, depthSel, timeSel), this.progressBar, this.progressText, acts);
    this.updateProgress(done, this.fens.length);
    this.progressBar.style.display = this.running ? '' : 'none';
  }

  updateProgress(done, total) {
    if (!this.progressBar) return;
    this.progressBar.firstChild.style.width = `${(done / total) * 100}%`;
    this.progressText.textContent = this.running ? `Analysing position ${done} of ${total} · Stockfish depth ${this.depth}` : done === total ? `All ${total} positions analysed at depth ≥ ${this.depth}.` : done ? `${done} of ${total} positions analysed.` : 'Not analysed yet.';
  }

  playFromHere() {
    const fen = this.fens[this.ply];
    this.app.newGame({ mode: 'analysis', playerColor: null, timeControl: null, startFen: fen, white: { name: 'White' }, black: { name: 'Black' }, orientation: this.board.orientation });
  }

  // ------------------------------------------------------------- render
  goTo(p) {
    const n = Math.max(0, Math.min(this.verbose.length, p));
    if (n === this.ply) return;
    const fwd = n === this.ply + 1;
    this.ply = n;
    if (fwd) playForMove(this.verbose[n - 1], { check: this.verbose[n - 1].san.includes('+') });
    this.renderPosition(fwd);
    this.renderSide();
  }

  renderAll(animate) {
    this.renderPosition(animate);
    this.renderSide();
    this.renderHead();
    this.updateStrips();
  }

  renderPosition(animate) {
    const fen = this.fens[this.ply];
    const last = this.ply > 0 ? this.verbose[this.ply - 1] : null;
    const c = new Chess(fen);
    let check = null;
    if (c.isCheck()) for (const row of c.board()) for (const p of row) if (p && p.type === 'k' && p.color === c.turn()) check = p.square;
    this.board.render(fenToMap(fen), { move: animate ? last : null, animate, lastMove: last, check });
    const m = this.sum?.moves[this.ply - 1];
    if (last && m && ['brilliant', 'inaccuracy', 'mistake', 'blunder'].includes(m.cls)) this.board.setBadge(last.to, { text: CLASS_BY_ID[m.cls].sym, cls: `cls-${m.cls}` });
    else this.board.setBadge(null);
    // arrows: best alternative (green) and the move played when it was not best (red/orange)
    const arrows = [];
    if (this.showBest && m?.best && m.best !== m.played) {
      arrows.push({ from: m.best.slice(0, 2), to: m.best.slice(2, 4), color: '#6fbf4a', opacity: 0.85 });
      arrows.push({ from: m.played.slice(0, 2), to: m.played.slice(2, 4), color: CLASS_BY_ID[m.cls].color, opacity: 0.6 });
    } else if (this.showBest && this.evals[this.ply]?.best && !this.evals[this.ply].terminal) {
      const b = this.evals[this.ply].best;
      arrows.push({ from: b.slice(0, 2), to: b.slice(2, 4), color: '#4f9cf0', opacity: 0.55 });
    }
    this.board.setArrows(arrows);
    this.updateEvalBar();
    this.updateStrips();
  }

  updateEvalBar() {
    const e = this.evals[this.ply];
    const sc = e?.score ?? null;
    const pct = sc ? barPercent(sc) : 50;
    this.evalEl.querySelector('.fill').style.setProperty('--p', `${pct}%`);
    const whiteAhead = pct >= 50, flipped = this.board?.orientation === 'b';
    this.evalVal.textContent = sc ? fmtScore(sc, { signed: false }) : '–';
    this.evalVal.className = `val ${whiteAhead !== flipped ? 'bottom' : 'top'} ${whiteAhead ? 'on-white' : 'on-black'} mono`;
    this.evalEl.classList.toggle('flipped', flipped);
  }

  updateStrips() {
    const cap = capturedUpTo(this.verbose, this.ply);
    const mat = materialOf(fenToMap(this.fens[this.ply]));
    for (const color of ['w', 'b']) {
      const st = this.strips[color];
      const name = color === 'w' ? this.rec.white : this.rec.black;
      const elo = color === 'w' ? this.rec.whiteElo : this.rec.blackElo;
      st.nm.replaceChildren(name ?? '?', elo ? h('small', null, String(elo)) : '');
      const frag = [];
      const groups = {}; for (const t of cap[color]) (groups[t] ??= []).push(t);
      for (const t of ['q', 'r', 'b', 'n', 'p']) { if (!groups[t]) continue; const g = h('span', { class: 'grp' }); for (const _ of groups[t]) g.append(pieceEl(color === 'w' ? 'b' : 'w', t)); frag.push(g); }
      const d = mat[color] - mat[color === 'w' ? 'b' : 'w']; if (d > 0) frag.push(h('span', { class: 'adv' }, `+${d}`));
      st.cap.replaceChildren(...frag);
      const a = this.sum?.accuracy[color];
      st.acc.textContent = a != null && this.evals.every(Boolean) ? `${a.toFixed(1)}%` : '';
      st.acc.style.display = st.acc.textContent ? '' : 'none';
    }
  }

  renderHead() {
    const rec = this.rec, sum = this.sum;
    const complete = this.evals.every(Boolean);
    const acc = (c) => { const a = sum?.accuracy[c]; return a == null ? '–' : a.toFixed(1); };
    const cards = h('div', { class: 'review-summary' },
      h('div', { class: 'acc-card' }, h('small', null, `${rec.white} (White)`), h('div', { class: 'big' }, acc('w')), h('small', null, complete ? 'accuracy %' : 'so far')),
      h('div', { class: 'acc-card' }, h('small', null, `${rec.black} (Black)`), h('div', { class: 'big' }, acc('b')), h('small', null, complete ? 'accuracy %' : 'so far')));
    const rows = CLASSES.map((c) => h('tr', null, h('td', null, h('span', { class: `clsdot cls-${c.id}` }), c.name), h('td', null, String(sum?.counts.w[c.id] ?? 0)), h('td', null, String(sum?.counts.b[c.id] ?? 0))));
    const table = h('table', { class: 'cls-table' }, ...rows);
    const acpl = sum?.acpl;
    const result = rec.result === '*' ? 'Unfinished' : `${rec.result} · ${REASON_TEXT[rec.reason] ?? ''}`.trim();
    this.headCard.replaceChildren(h('div', { class: 'tabpane' },
      h('div', { class: 'card-head', style: { marginBottom: '.6rem' } }, h('div', null, h('h3', null, gameTitle(rec)), h('div', { class: 'hint' }, `${fmtDate(rec.date)} · ${result}`)), resultChip(rec)),
      cards, table,
      acpl && complete ? h('div', { class: 'hint', style: { marginTop: '.5rem' } }, `Average centipawn loss — White ${acpl.w?.toFixed(0) ?? '–'}, Black ${acpl.b?.toFixed(0) ?? '–'}`) : ''));
  }

  renderSide() {
    this.renderGraph();
    this.renderCoach();
    this.renderMoves();
  }

  renderGraph() {
    const series = graphSeries(this.evals);
    const n = series.length, W = 300, H = 110;
    const x = (i) => (n <= 1 ? 0 : (i / (n - 1)) * W);
    const y = (cp) => H - cpToWin(cp) / 100 * H;
    const pts = []; series.forEach((v, i) => { if (v != null) pts.push([x(i), y(v), i]); });
    let area = '';
    if (pts.length > 1) area = `<path d="M${pts[0][0]},${H} ${pts.map((p) => `L${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')} L${pts[pts.length - 1][0]},${H} Z" fill="rgba(240,242,247,.92)"/>`;
    else area = '';
    const marks = (this.sum?.moves ?? []).map((m, i) => (m && (m.cls === 'blunder' || m.cls === 'mistake' || m.cls === 'brilliant') && series[i + 1] != null) ? `<circle cx="${x(i + 1).toFixed(1)}" cy="${y(series[i + 1]).toFixed(1)}" r="3.2" fill="${CLASS_BY_ID[m.cls].color}" stroke="#0d0f13" stroke-width="1"/>` : '').join('');
    const cur = series[this.ply] != null ? `<line x1="${x(this.ply)}" x2="${x(this.ply)}" y1="0" y2="${H}" stroke="var(--accent)" stroke-width="1.6"/>` : `<line x1="${x(this.ply)}" x2="${x(this.ply)}" y1="0" y2="${H}" stroke="var(--accent)" stroke-width="1.6" opacity=".5"/>`;
    const svg = h('div', { html: `<svg class="graph" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Evaluation graph. Click to jump to a move."><rect width="${W}" height="${H}" fill="#20242c"/>${area}<line x1="0" x2="${W}" y1="${H / 2}" y2="${H / 2}" stroke="rgba(130,138,156,.7)" stroke-width=".8" stroke-dasharray="3 3"/>${cur}${marks}</svg>` });
    const s = svg.firstChild;
    const pick = (e) => { const r = s.getBoundingClientRect(); const f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); this.goTo(Math.round(f * (n - 1))); };
    let down = false;
    s.addEventListener('pointerdown', (e) => { down = true; s.setPointerCapture(e.pointerId); pick(e); });
    s.addEventListener('pointermove', (e) => { if (down) pick(e); });
    s.addEventListener('pointerup', () => { down = false; });
    this.graphEl.replaceChildren(h('div', { class: 'label', style: { marginBottom: '.3rem' } }, 'Evaluation graph'), svg);
  }

  renderCoach() {
    const m = this.sum?.moves[this.ply - 1];
    const e = this.evals[this.ply];
    if (this.ply === 0) {
      this.coachEl.replaceChildren(h('div', { class: 'hd' }, 'Starting position'), h('div', { class: 'muted' }, e ? `Engine evaluation ${fmtScore(e.score)}. Use the arrow keys or the graph to step through the game.` : 'Waiting for analysis…'));
      this.altEl.replaceChildren();
      return;
    }
    const mv = this.verbose[this.ply - 1];
    if (!m) { this.coachEl.replaceChildren(h('div', { class: 'hd' }, `${mv.san}`), h('div', { class: 'muted' }, this.running ? 'Analysing this move…' : 'Not analysed yet — press Analyze.')); this.altEl.replaceChildren(); return; }
    const c = CLASS_BY_ID[m.cls];
    const beforeFen = this.fens[this.ply - 1];
    const sentence = {
      brilliant: `${mv.san} is brilliant — a sacrifice the engine confirms.`,
      best: `${mv.san} is the best move.`, excellent: `${mv.san} is an excellent move.`, good: `${mv.san} is a good move.`,
      inaccuracy: `${mv.san} is an inaccuracy.`, mistake: `${mv.san} is a mistake.`, blunder: `${mv.san} is a blunder.`,
    }[m.cls];
    const bestSan = m.best && m.best !== m.played ? sanOfUci(beforeFen, m.best) : null;
    const delta = `${fmtScore(m.bestScore)} → ${fmtScore(m.afterScore)}`;
    this.coachEl.replaceChildren(
      h('div', { class: 'hd' }, h('span', { class: `clsdot cls-${m.cls}` }), c.name),
      h('div', null, sentence),
      bestSan && !['best', 'brilliant'].includes(m.cls) ? h('div', { class: 'muted' }, `Best was ${bestSan}.`) : '',
      h('div', { class: 'hint' }, `Evaluation (White's view): ${delta} · win-chance change ${m.loss > 0.05 ? `−${m.loss.toFixed(1)}` : '0.0'}%`));
    // alternatives at the position before the move
    const before = this.evals[this.ply - 1];
    const rows = [];
    if (before?.lines?.length) {
      rows.push(h('div', { class: 'label' }, `Engine suggestions before ${mv.san}`));
      for (const l of before.lines.slice(0, 3)) {
        const san = sanLine(beforeFen, l.pv, 6);
        const played = l.pv[0] === m.played;
        rows.push(h('div', { class: 'line', style: played ? { borderColor: 'var(--accent-line)' } : {} },
          h('span', { class: `sc ${scoreToCp(l.score) >= 0 ? 'pos' : 'neg'}` }, fmtScore(l.score)),
          h('span', { class: 'pv' }, san.join(' '), played ? '  ← played' : '')));
      }
    }
    this.altEl.replaceChildren(...rows);
  }

  renderMoves() {
    const el = this.movesEl; el.replaceChildren();
    const frag = document.createDocumentFragment();
    let num = Number(this.startFen.split(' ')[5] ?? 1) || 1;
    for (let p = 0; p < this.verbose.length; p++) {
      const m = this.verbose[p];
      if (m.color === 'w' || p === 0) { frag.append(h('div', { class: 'n' }, `${num}.`)); if (m.color === 'b') frag.append(h('div', { class: 'm' }, '…')); }
      const info = this.sum?.moves[p];
      frag.append(h('div', { class: `m${p + 1 === this.ply ? ' cur' : ''}`, 'data-ply': p + 1, role: 'button', tabindex: '-1' }, m.san, info ? h('span', { class: `clsdot cls-${info.cls}`, title: CLASS_BY_ID[info.cls].name }) : ''));
      if (m.color === 'b') num++;
    }
    el.append(frag);
    const cur = el.querySelector('.cur');
    if (cur) el.scrollTop = Math.max(0, cur.offsetTop - el.clientHeight / 2);
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true; this.cancelled = true; this.token++;
    engines.analysis.stop();
    document.removeEventListener('keydown', this._key);
    this.board?.destroy();
    this.el?.remove();
  }
}

// ---------------------------------------------------------------- picker ---
export async function mountReviewPicker(root, app) {
  const el = h('div');
  const games = await db.listGames(app.user.id);
  const imp = h('button', { class: 'btn primary', type: 'button', html: `${icon('upload')}<span>Import PGN</span>` });
  imp.addEventListener('click', async () => { const id = await importPgnFlow(app, { openFirst: true }); if (id != null) app.go(`/review/${id}`); });
  el.append(h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Game Review'), h('p', null, 'Pick a game and Stockfish will grade every move. Classifications come from the measured evaluation change.')), imp));
  const list = h('div', { class: 'list' });
  if (app.tempRecord && !games.some((g) => g.pgn === app.tempRecord.pgn)) {
    const b = h('button', { class: 'btn primary sm', type: 'button' }, 'Analyze');
    b.addEventListener('click', () => app.go('/review/tmp'));
    list.append(h('div', { class: 'row' }, resultChip(app.tempRecord), h('div', { style: { minWidth: 0 } }, h('div', { class: 't' }, `${gameTitle(app.tempRecord)} — just finished`), h('div', { class: 'd' }, 'Not saved to history (auto-save is off)')), b));
  }
  if (!games.length && !list.children.length) list.append(h('div', { class: 'empty' }, 'No saved games yet. Finish a game, or import a PGN to analyze it.'));
  for (const g of games.slice(0, 30)) {
    const b = h('button', { class: 'btn sm', type: 'button' }, g.analysis ? 'Open review' : 'Analyze');
    b.addEventListener('click', () => app.go(`/review/${g.id}`));
    list.append(h('div', { class: 'row' }, resultChip(g), h('div', { style: { minWidth: 0 } }, h('div', { class: 't' }, gameTitle(g)), h('div', { class: 'd' }, `${fmtDate(g.date)} · ${Math.ceil(g.plies / 2)} moves${g.analysis ? ' · analysed' : ''}`)), b));
  }
  el.append(h('div', { class: 'card' }, list));
  root.append(el);
  return { destroy: () => el.remove() };
}
