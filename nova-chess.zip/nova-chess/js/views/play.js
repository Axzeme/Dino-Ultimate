// Play hub + game setup screens (vs Stockfish and local two-player).
import { h, icon, toast, avatarEl } from '../util.js';
import { settings } from '../store.js';
import { LEVELS, resolveLevel } from '../engine.js';
import { TIME_CONTROLS } from '../game.js';
import { pieceEl } from '../pieces.js';

export function timeControlById(id) {
  const t = TIME_CONTROLS.find((x) => x.id === id) ?? TIME_CONTROLS[0];
  return t.base == null ? null : { id: t.id, base: t.base, inc: t.inc };
}

/** Builds a session config for a game against Stockfish from the saved settings. */
export function buildEngineCfg(app, { colorChoice = settings.get('defaultColor'), tcId = settings.get('defaultTC'), levelOverride = null } = {}) {
  const level = levelOverride ? { ...levelOverride } : resolveLevel(settings.values);
  const pc = colorChoice === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : colorChoice;
  const me = { name: app.user.name, rating: app.refreshStats().rating, avatar: app.user.avatar };
  const eng = { name: 'Stockfish 19', rating: null };
  return {
    mode: 'engine', playerColor: pc, colorChoice,
    white: pc === 'w' ? me : eng, black: pc === 'w' ? eng : me,
    engineLevel: level, timeControl: timeControlById(tcId),
    autoClaimDraws: settings.get('autoClaimDraws'),
  };
}

function modeCard({ ic, title, text, onClick, badge }) {
  const b = h('button', { class: 'quick', type: 'button' },
    h('div', { class: 'qi', html: icon(ic) }), h('b', null, title, badge ? h('span', { class: 'pill accent', style: { marginLeft: '.5rem' } }, badge) : ''), h('span', null, text));
  b.addEventListener('click', onClick);
  return b;
}

export function mountPlayHub(root, app) {
  const el = h('div', null,
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Play Chess'), h('p', null, 'Pick a mode. Every mode runs on your device.'))),
    h('div', { class: 'grid mode-grid' },
      modeCard({ ic: 'cpu', title: 'Player vs Stockfish', badge: 'Engine', text: 'Seven strength levels plus fully custom engine settings, optional clocks and a live evaluation bar.', onClick: () => app.go('/play/engine') }),
      modeCard({ ic: 'users', title: 'Local two-player', text: 'Share one device. Optional clock and auto-flipping board.', onClick: () => app.go('/play/local') }),
      modeCard({ ic: 'board', title: 'Practice board', text: 'An unrestricted board: explore positions, take moves back, set up any FEN or load a PGN.', onClick: () => app.go('/play/practice') }),
      modeCard({ ic: 'bulb', title: 'Analysis board', text: 'Practice board with Stockfish lines, multi-PV and best-move arrows switched on.', onClick: () => app.go('/play/analysis') }),
      modeCard({ ic: 'puzzle', title: 'Puzzles', text: 'Verified tactics: mates, forks, pins, skewers and discovered attacks.', onClick: () => app.go('/puzzles') })));
  root.append(el);
  return { destroy: () => el.remove() };
}

// ---------------------------------------------------------------------------
function tcSelect(value, onChange) {
  const sel = h('select', { class: 'select', 'aria-label': 'Time control' });
  for (const t of TIME_CONTROLS) sel.append(h('option', { value: t.id, selected: t.id === value }, t.base == null ? 'Unlimited (no clock)' : `${t.name}${t.tag ? ` · ${t.tag}` : ''}`));
  sel.addEventListener('change', () => onChange(sel.value));
  return sel;
}

function slider({ min, max, step = 1, value, fmt = (v) => v, onInput, label, hint }) {
  const out = h('output', null, fmt(value));
  const inp = h('input', { type: 'range', min, max, step, value, 'aria-label': label });
  inp.addEventListener('input', () => { out.textContent = fmt(Number(inp.value)); onInput(Number(inp.value)); });
  return h('div', { class: 'field' }, h('label', null, label), h('div', { class: 'range-row' }, inp, out), hint ? h('div', { class: 'hint' }, hint) : '');
}

export function mountEngineSetup(root, app) {
  let colorChoice = settings.get('defaultColor');
  let tcId = settings.get('defaultTC');
  const el = h('div');
  const levelHost = h('div', { class: 'level-grid' });
  const detail = h('div');
  const colorHost = h('div', { class: 'color-pick' });

  const renderColor = () => {
    colorHost.replaceChildren();
    for (const [id, label] of [['w', 'White'], ['random', 'Random'], ['b', 'Black']]) {
      const b = h('button', { type: 'button', class: colorChoice === id ? 'on' : '', 'aria-pressed': String(colorChoice === id) });
      if (id === 'random') { const wrap = h('span', { class: 'pc', style: { display: 'inline-flex', width: '2.6rem', height: '2.6rem' } }); wrap.append(h('span', { class: 'pc wK', style: { width: '60%', height: '100%' } }), h('span', { class: 'pc bK', style: { width: '60%', height: '100%', marginLeft: '-20%' } })); b.append(wrap); }
      else b.append(pieceEl(id, 'K', 'pc'));
      b.append(label);
      b.addEventListener('click', () => { colorChoice = id; settings.set({ defaultColor: id }); renderColor(); });
      colorHost.append(b);
    }
  };

  const renderLevels = () => {
    levelHost.replaceChildren();
    const cur = settings.get('engineLevel');
    for (const l of [...LEVELS, { id: 'custom', name: 'Custom', elo: null, desc: 'Set every engine parameter yourself' }]) {
      const b = h('button', { type: 'button', class: `level${cur === l.id ? ' on' : ''}`, 'aria-pressed': String(cur === l.id) }, h('b', null, l.name), h('small', null, l.id === 'custom' ? 'Your own settings' : `≈ ${l.elo} Elo`));
      b.title = l.desc;
      b.addEventListener('click', () => { settings.set({ engineLevel: l.id }); renderLevels(); renderDetail(); });
      levelHost.append(b);
    }
  };

  const renderDetail = () => {
    const s = settings.values;
    const lvl = resolveLevel(s);
    const rows = [
      h('div', { class: 'notice info' }, h('b', null, lvl.name), ` — ${lvl.desc}.`, h('div', { class: 'hint', style: { marginTop: '.3rem' } },
        `Skill level ${lvl.skill}${lvl.limit ? ` · limited to ~${lvl.uciElo} Elo` : ' · no Elo limit'} · search depth ≤ ${lvl.depth} · thinking time ≤ ${lvl.movetime} ms`)),
    ];
    if (s.engineLevel === 'custom') {
      rows.push(
        slider({ min: 0, max: 20, value: s.engineSkill, label: 'Skill level (0 – 20)', onInput: (v) => { settings.set({ engineSkill: v }); updateNote(); } }),
        h('label', { class: 'checkrow' }, (() => { const c = h('input', { type: 'checkbox', class: 'check', checked: s.engineLimit }); c.addEventListener('change', () => { settings.set({ engineLimit: c.checked }); renderDetail(); }); return c; })(), 'Limit playing strength to an Elo rating'),
        s.engineLimit ? slider({ min: 1320, max: 3190, step: 10, value: s.engineElo, label: 'Target Elo (UCI_Elo)', onInput: (v) => { settings.set({ engineElo: v }); updateNote(); } }) : '',
        slider({ min: 1, max: 30, value: s.engineDepth, label: 'Maximum search depth', fmt: (v) => `${v} ply`, onInput: (v) => { settings.set({ engineDepth: v }); updateNote(); } }),
        slider({ min: 50, max: 10000, step: 50, value: s.engineMoveTime, label: 'Thinking time per move', fmt: (v) => `${(v / 1000).toFixed(2)} s`, onInput: (v) => { settings.set({ engineMoveTime: v }); updateNote(); } }));
    } else rows.push(h('div', { class: 'hint' }, 'Choose “Custom” to control skill, an Elo cap, search depth and thinking time yourself.'));
    detail.replaceChildren(...rows);
  };
  const updateNote = () => { const n = detail.querySelector('.notice .hint'); if (n) { const l = resolveLevel(settings.values); n.textContent = `Skill level ${l.skill}${l.limit ? ` · limited to ~${l.uciElo} Elo` : ' · no Elo limit'} · search depth ≤ ${l.depth} · thinking time ≤ ${l.movetime} ms`; } };

  const liveEval = h('input', { type: 'checkbox', class: 'check', checked: settings.get('liveEval') });
  liveEval.addEventListener('change', () => settings.set({ liveEval: liveEval.checked }));
  const confirmMoves = h('input', { type: 'checkbox', class: 'check', checked: settings.get('confirmMoves') });
  confirmMoves.addEventListener('change', () => settings.set({ confirmMoves: confirmMoves.checked }));

  const start = h('button', { class: 'btn primary lg block', type: 'button', html: `${icon('play')}<span>Start game</span>` });
  start.addEventListener('click', () => {
    settings.set({ defaultTC: tcId, defaultColor: colorChoice });
    app.newGame(buildEngineCfg(app, { colorChoice, tcId }));
  });

  el.append(
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Play against Stockfish'), h('p', null, 'Real Stockfish 19 (WebAssembly) running in a background worker.'))),
    h('div', { class: 'setup' },
      h('div', { class: 'card' },
        h('div', { class: 'opt-group' }, h('div', { class: 'label' }, 'Play as'), colorHost),
        h('div', { class: 'opt-group' }, h('div', { class: 'label' }, 'Difficulty'), levelHost),
        h('div', { class: 'opt-group' }, h('div', { class: 'label' }, 'Time control'), tcSelect(tcId, (v) => { tcId = v; }))),
      h('div', { style: { display: 'grid', gap: '1rem' } },
        h('div', { class: 'card' }, h('h3', null, 'Engine strength'), h('div', { style: { display: 'grid', gap: '.9rem' } }, detail)),
        h('div', { class: 'card', style: { display: 'grid', gap: '.7rem' } },
          h('label', { class: 'checkrow' }, liveEval, 'Show live evaluation bar'),
          h('label', { class: 'checkrow' }, confirmMoves, 'Confirm each move before it is played'),
          h('div', { class: 'hint' }, 'Takebacks are allowed, but a game with takebacks is not rated.'),
          start))));
  root.append(el);
  renderColor(); renderLevels(); renderDetail();
  return { destroy: () => el.remove() };
}

export function mountLocalSetup(root, app) {
  let tcId = settings.get('defaultTC');
  let autoFlip = false;
  const w = h('input', { class: 'input', value: app.user.isGuest ? 'White' : app.user.name, maxlength: 20, 'aria-label': 'White player name' });
  const b = h('input', { class: 'input', value: 'Black', maxlength: 20, 'aria-label': 'Black player name' });
  const flip = h('input', { type: 'checkbox', class: 'check' });
  flip.addEventListener('change', () => { autoFlip = flip.checked; });
  const start = h('button', { class: 'btn primary lg block', type: 'button', html: `${icon('play')}<span>Start game</span>` });
  start.addEventListener('click', () => {
    settings.set({ defaultTC: tcId });
    app.newGame({
      mode: 'local', playerColor: null, timeControl: timeControlById(tcId), autoFlip,
      white: { name: w.value.trim() || 'White' }, black: { name: b.value.trim() || 'Black' },
    });
  });
  const el = h('div', null,
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Local two-player'), h('p', null, 'Two players, one device, taking turns on the same board.'))),
    h('div', { class: 'card', style: { maxWidth: '560px', display: 'grid', gap: '1rem' } },
      h('div', { class: 'two' }, h('div', { class: 'field' }, h('label', null, 'White'), w), h('div', { class: 'field' }, h('label', null, 'Black'), b)),
      h('div', { class: 'field' }, h('label', null, 'Time control'), tcSelect(tcId, (v) => { tcId = v; })),
      h('label', { class: 'checkrow' }, flip, 'Flip the board to the player to move after every move'),
      start));
  root.append(el);
  return { destroy: () => el.remove() };
}
