// Puzzle trainer. Puzzle data is engine-verified offline (tools/build-puzzles.mjs); positions are re-validated at load.
import { Chess } from '../../vendor/chess.js';
import { h, icon, toast, sleep } from '../util.js';
import { db, settings } from '../store.js';
import { Board, fenToMap } from '../board.js';
import { play, playForMove } from '../audio.js';
import { PUZZLES } from '../puzzle-data.js';

const THEMES = [['all', 'All themes'], ['mate', 'Checkmate'], ['fork', 'Forks'], ['pin', 'Pins'], ['skewer', 'Skewers'], ['discovered', 'Discovered attacks'], ['tactic', 'Tactics']];
const DIFFS = [['all', 'Any difficulty'], ['1', 'Easy'], ['2', 'Medium'], ['3', 'Hard']];
const DIFF_NAME = { 1: 'Easy', 2: 'Medium', 3: 'Hard' };

const mv = (u) => ({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });

/** A puzzle is only shown if its whole solution is a legal move sequence (and mates really mate). */
export function validatePuzzle(p) {
  try {
    const c = new Chess(p.fen);
    if (!p.moves?.length || p.moves.length % 2 === 0) return false;
    for (const u of p.moves) c.move(mv(u));
    if (p.theme === 'mate' && !c.isCheckmate()) return false;
    return true;
  } catch { return false; }
}

function kingSq(c, color) { for (const row of c.board()) for (const p of row) if (p && p.type === 'k' && p.color === color) return p.square; return null; }

export async function mountPuzzles(root, app) {
  const uid = app.user.id;
  const progress = await db.getProgress(uid);
  progress.solved ??= {}; progress.failed ??= {}; progress.streak ??= 0; progress.bestStreak ??= 0; progress.attempts ??= 0;
  const all = PUZZLES.filter((p) => { const ok = validatePuzzle(p); if (!ok) console.warn('[puzzles] skipping invalid puzzle', p.id); return ok; });
  const filter = { theme: 'all', diff: 'all' };
  let list = all, cur = null;
  let chess, idx, state, mistakes, hints, busy = false, token = 0;

  const el = h('div');
  const boardHost = h('div', { class: 'board-wrap' });
  const titleEl = h('div', { style: { display: 'grid', gap: '.15rem' } });
  const feedback = h('div', { class: 'feedback' });
  const btns = h('div', { class: 'controls' });
  const statsEl = h('div', { class: 'grid', style: { gridTemplateColumns: 'repeat(3,1fr)', gap: '.5rem' } });
  const listEl = h('div', { class: 'puzzle-list' });
  const side = h('div', { class: 'side' });

  const board = new Board(boardHost, {
    interactive: () => state === 'playing' && !busy && chess && chess.turn() === cur.side,
    targets: (sq) => { const p = chess.get(sq); if (!p || p.color !== chess.turn()) return []; const seen = new Map(); for (const m of chess.moves({ square: sq, verbose: true })) if (!seen.has(m.to)) seen.set(m.to, { to: m.to, capture: !!m.captured }); return [...seen.values()]; },
    onMove: (f, t) => attempt(f, t),
    onIllegal: () => play('illegal'),
  });

  const persist = () => db.putProgress(uid, progress).catch((e) => console.warn('progress save failed', e));
  const setFeedback = (kind, text) => { feedback.className = `feedback ${kind}`; feedback.replaceChildren(h('span', { html: icon(kind === 'good' ? 'check' : kind === 'bad' ? 'x' : 'info') }), h('span', null, text)); };

  function applyList() {
    list = all.filter((p) => (filter.theme === 'all' || p.theme === filter.theme) && (filter.diff === 'all' || String(p.difficulty) === filter.diff));
  }

  function load(p, { animate = false } = {}) {
    token++;
    cur = p; chess = new Chess(p.fen); idx = 0; state = 'playing'; mistakes = 0; hints = 0; busy = false;
    board.cancelInteraction();
    board.setOrientation(p.side);
    board.setArrows([]);
    board.render(fenToMap(p.fen), { animate: false, lastMove: null, check: chess.isCheck() ? kingSq(chess, chess.turn()) : null });
    try { localStorage.setItem(`nova.puzzle.last.${uid}`, p.id); } catch { /* ignore */ }
    renderInfo();
    setFeedback('', `${p.side === 'w' ? 'White' : 'Black'} to move — find the best move.`);
    renderButtons(); renderList();
  }

  function renderInfo() {
    const p = cur;
    const n = list.findIndex((x) => x.id === p.id) + 1;
    const solved = progress.solved[p.id];
    titleEl.replaceChildren(
      h('div', { style: { display: 'flex', gap: '.5rem', alignItems: 'center', flexWrap: 'wrap' } }, h('h2', { style: { fontSize: '1.2rem' } }, p.title), h('span', { class: 'pill accent' }, THEMES.find(([k]) => k === p.theme)?.[1] ?? p.theme), h('span', { class: 'pill' }, DIFF_NAME[p.difficulty] ?? ''), solved ? h('span', { class: 'pill good' }, 'Solved') : ''),
      h('div', { class: 'muted', style: { fontSize: '.84rem' } }, `Puzzle ${p.id.replace('P', '#')}${n ? ` · ${n} of ${list.length} in this filter` : ''}`));
  }

  function renderStats() {
    const solved = Object.keys(progress.solved).length;
    const first = Object.values(progress.solved).filter((s) => s.firstTry).length;
    const stat = (k, v, s) => h('div', { class: 'stat', style: { padding: '.7rem' } }, h('div', { class: 'k' }, k), h('div', { class: 'v', style: { fontSize: '1.3rem' } }, v), h('div', { class: 's' }, s));
    statsEl.replaceChildren(stat('Solved', `${solved}`, `of ${all.length}`), stat('First try', solved ? `${Math.round((first / solved) * 100)}%` : '—', `${first} puzzles`), stat('Streak', `${progress.streak}`, `best ${progress.bestStreak}`));
  }

  function renderList() {
    listEl.replaceChildren(...list.map((p, i) => {
      const cls = [progress.solved[p.id] ? 'solved' : progress.failed[p.id] ? 'failed' : '', cur?.id === p.id ? 'cur' : ''].filter(Boolean).join(' ');
      const b = h('button', { type: 'button', class: cls, title: `${p.title} · ${DIFF_NAME[p.difficulty]}`, 'aria-label': `Puzzle ${i + 1}: ${p.title}` }, String(i + 1));
      b.addEventListener('click', () => load(p));
      return b;
    }));
    renderStats();
  }

  function renderButtons() {
    const mk = (ic, label, fn, cls = '') => { const b = h('button', { class: `btn ${cls}`, type: 'button' }, h('span', { html: icon(ic) }), h('span', { class: 'lbl' }, label)); b.addEventListener('click', fn); return b; };
    const done = state !== 'playing';
    btns.replaceChildren(
      mk('prev', 'Prev', () => go(-1)),
      mk('bulb', 'Hint', hint, done ? 'disabled' : ''),
      mk('flag', 'Solution', showSolution, done ? 'disabled' : ''),
      mk('restart', 'Retry', () => load(cur)),
      mk('next', 'Next', () => go(1), state === 'solved' ? 'primary' : ''));
  }

  function go(dir) {
    if (!list.length) return;
    let i = list.findIndex((p) => p.id === cur?.id);
    if (dir > 0) {
      // prefer the next unsolved puzzle
      for (let k = 1; k <= list.length; k++) { const p = list[(i + k) % list.length]; if (!progress.solved[p.id]) return load(p); }
      return load(list[(i + 1) % list.length]);
    }
    load(list[(i - 1 + list.length) % list.length]);
  }

  function renderBoard(move = null) {
    board.render(fenToMap(chess.fen()), { move, animate: !!move, lastMove: move, check: chess.isCheck() ? kingSq(chess, chess.turn()) : null });
  }

  async function attempt(from, to) {
    const p = cur, my = token;
    let promotion;
    const piece = chess.get(from);
    if (piece?.type === 'p' && (to[1] === '8' || to[1] === '1')) {
      busy = true; promotion = await board.askPromotion(to, chess.turn()); busy = false;
      if (!promotion) { board.cancelInteraction(); return; }
    }
    if (my !== token) return;
    const uci = from + to + (promotion ?? '');
    const expected = p.moves[idx];
    let ok = uci === expected;
    if (!ok && idx === p.moves.length - 1) { // any mating move is as good as the stored one on the last step of a mate puzzle
      const t = new Chess(chess.fen());
      try { t.move({ from, to, promotion }); if (t.isCheckmate() && p.theme === 'mate') ok = true; } catch { /* illegal */ }
    }
    if (!ok) return wrong(uci);
    busy = true;
    const m = chess.move({ from, to, promotion });
    playForMove(m, { check: chess.isCheck(), mate: chess.isCheckmate() });
    renderBoard(m);
    idx++;
    if (idx >= p.moves.length) { busy = false; return solved(); }
    setFeedback('good', 'Correct — keep going.');
    await sleep(520);
    if (my !== token) return;
    const r = chess.move(mv(p.moves[idx]));
    playForMove(r, { check: chess.isCheck(), mate: false });
    renderBoard(r);
    idx++;
    busy = false;
    board.refreshGrabCursor();
  }

  function wrong(uci) {
    play('wrong');
    mistakes++;
    board.cancelInteraction();
    renderBoard();
    if (!progress.failed[cur.id]) { progress.failed[cur.id] = true; progress.streak = 0; progress.attempts++; persist(); renderList(); }
    setFeedback('bad', mistakes > 1 ? 'Still not it. Try the hint, or reveal the solution.' : 'Not the best move — try again.');
  }

  function solved() {
    state = 'solved';
    const first = mistakes === 0 && hints === 0 && !progress.solved[cur.id];
    if (!progress.solved[cur.id]) {
      progress.solved[cur.id] = { firstTry: mistakes === 0 && hints === 0 && !progress.failed[cur.id], at: Date.now() };
      progress.attempts++;
    }
    if (first && progress.solved[cur.id].firstTry) { progress.streak++; progress.bestStreak = Math.max(progress.bestStreak, progress.streak); }
    delete progress.failed[cur.id];
    persist();
    play('correct'); setTimeout(() => play('win'), 250);
    setFeedback('good', mistakes === 0 && hints === 0 ? 'Puzzle solved — first try!' : 'Puzzle solved!');
    renderInfo(); renderButtons(); renderList();
  }

  function hint() {
    if (state !== 'playing' || busy) return;
    hints++;
    const u = cur.moves[idx];
    if (hints === 1) { board.showSelection(u.slice(0, 2), []); setFeedback('', 'Hint: move this piece.'); }
    else { board.setArrows([{ from: u.slice(0, 2), to: u.slice(2, 4), color: '#4f9cf0', opacity: 0.8 }]); setFeedback('', 'Hint: the arrow shows the best move.'); }
    if (!progress.failed[cur.id] && !progress.solved[cur.id]) { /* hints only cost the "first try" badge */ }
  }

  async function showSolution() {
    if (state !== 'playing' || busy) return;
    const my = token;
    busy = true; state = 'revealed';
    if (!progress.solved[cur.id] && !progress.failed[cur.id]) { progress.failed[cur.id] = true; progress.streak = 0; persist(); }
    renderButtons(); renderList();
    board.cancelInteraction(); board.setArrows([]);
    setFeedback('', 'Here is the solution…');
    while (idx < cur.moves.length && my === token) {
      const m = chess.move(mv(cur.moves[idx]));
      playForMove(m, { check: chess.isCheck(), mate: chess.isCheckmate() });
      renderBoard(m);
      idx++;
      await sleep(850);
    }
    if (my === token) { busy = false; setFeedback('', 'Solution shown. Retry it, or move on to the next puzzle.'); renderButtons(); }
  }

  // ---------------------------------------------------------------- layout
  const mkSel = (opts, key) => { const s = h('select', { class: 'select', 'aria-label': key }); for (const [v, l] of opts) s.append(h('option', { value: v }, l)); s.addEventListener('change', () => { filter[key] = s.value; applyList(); if (!list.length) { listEl.replaceChildren(); setFeedback('bad', 'No puzzles match this filter.'); return; } const first = list.find((p) => !progress.solved[p.id]) ?? list[0]; load(first); }); return s; };
  const filters = h('div', { class: 'two' }, mkSel(THEMES, 'theme'), mkSel(DIFFS, 'diff'));

  side.append(
    h('div', { class: 'card', style: { display: 'grid', gap: '.8rem' } }, titleEl, feedback),
    h('div', { class: 'card', style: { display: 'grid', gap: '.7rem' } }, h('div', { class: 'card-head', style: { margin: 0 } }, h('h3', null, 'Your progress')), statsEl),
    h('div', { class: 'card', style: { display: 'grid', gap: '.7rem' } }, h('div', { class: 'card-head', style: { margin: 0 } }, h('h3', null, 'Puzzles')), filters, listEl,
      h('div', { class: 'hint' }, `${all.length} engine-verified positions. Green = solved, red = missed.`)));
  const layout = h('div', { class: 'puzzle-layout' }, h('div', { class: 'board-col' }, boardHost, btns), side);
  el.append(h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Puzzles'), h('p', null, 'Find the best move. Every solution is checked against Stockfish.'))));
  if (!all.length) el.append(h('div', { class: 'card' }, h('p', { class: 'muted' }, 'No puzzles are available.')));
  else el.append(layout);
  root.append(el);

  if (all.length) {
    let last = null; try { last = localStorage.getItem(`nova.puzzle.last.${uid}`); } catch { /* ignore */ }
    const start = all.find((p) => p.id === last && !progress.solved[p.id]) ?? all.find((p) => !progress.solved[p.id]) ?? all[0];
    load(start);
  }
  return { destroy: () => { token++; board.destroy(); el.remove(); } };
}
