// Game history: list, filter, open/replay/analyze, export and import PGN.
import { h, icon, toast, modal, confirmDialog, fmtDate, fmtDuration, download, pickFile } from '../util.js';
import { db } from '../store.js';
import { splitPgn, parseGame, importedRecord, recordFileName } from '../pgn.js';
import { REASON_TEXT } from '../game.js';
import { gameTitle, gameOutcome, resultChip } from './dashboard.js';

/** Opens the import dialog. Resolves with the id of the first imported game, or null. */
export function importPgnFlow(app) {
  return new Promise((resolve) => {
    const ta = h('textarea', { class: 'input mono', rows: 9, placeholder: '[Event "Casual game"]\n[White "Alice"]\n[Black "Bob"]\n\n1. e4 e5 2. Nf3 Nc6 …', spellcheck: 'false' });
    const err = h('div', { class: 'error-text', style: { whiteSpace: 'pre-wrap' } });
    const fileBtn = h('button', { class: 'btn', type: 'button', html: `${icon('upload')}<span>Choose a .pgn file…</span>` });
    fileBtn.addEventListener('click', async () => {
      const f = await pickFile('.pgn,.txt,text/plain,application/x-chess-pgn');
      if (!f) return;
      if (f.size > 8 * 1024 * 1024) { err.textContent = 'That file is larger than 8 MB.'; return; }
      try { ta.value = await f.text(); err.textContent = ''; } catch { err.textContent = 'Could not read that file.'; }
    });
    const body = h('div', { style: { display: 'grid', gap: '.7rem' } }, fileBtn, h('div', { class: 'label' }, 'or paste PGN text (one or many games)'), ta, err);
    let firstId = null;
    modal({
      title: 'Import PGN', body, wide: true,
      actions: [{ label: 'Cancel', value: false }, {
        label: 'Import', value: true, kind: 'primary',
        onClick: async () => {
          err.textContent = '';
          const chunks = splitPgn(ta.value);
          if (!chunks.length) { err.textContent = 'Paste some PGN text or choose a file first.'; return false; }
          const problems = []; let ok = 0;
          for (let i = 0; i < chunks.length; i++) {
            try {
              const parsed = parseGame(chunks[i]);
              const rec = importedRecord(parsed, app.user);
              const id = await db.addGame(rec);
              if (firstId == null) firstId = id;
              ok++;
            } catch (e) { problems.push(`Game ${i + 1}: ${e.message}`); }
          }
          if (!ok) { err.textContent = problems.slice(0, 4).join('\n') || 'No games could be imported.'; return false; }
          toast(`Imported ${ok} game${ok === 1 ? '' : 's'}${problems.length ? ` (${problems.length} skipped as invalid)` : ''}`, problems.length ? '' : 'good', 4500);
          return true;
        },
      }],
    }).then(() => resolve(firstId));
  });
}

export async function mountHistory(root, app) {
  const el = h('div');
  let games = await db.listGames(app.user.id);
  const f = { q: '', result: 'all', mode: 'all' };

  const search = h('input', { class: 'input', type: 'search', placeholder: 'Search opponent, player or event…', 'aria-label': 'Search games' });
  search.addEventListener('input', () => { f.q = search.value.trim().toLowerCase(); renderTable(); });
  const seg = (key, opts) => {
    const s = h('div', { class: 'seg' });
    for (const [v, label] of opts) {
      const b = h('button', { type: 'button', class: f[key] === v ? 'on' : '' }, label);
      b.addEventListener('click', () => { f[key] = v; for (const x of s.children) x.classList.toggle('on', x === b); renderTable(); });
      s.append(b);
    }
    return s;
  };
  const imp = h('button', { class: 'btn', type: 'button', html: `${icon('upload')}<span>Import PGN</span>` });
  imp.addEventListener('click', async () => { const id = await importPgnFlow(app); if (id != null) { games = await db.listGames(app.user.id); renderTable(); } });
  const expAll = h('button', { class: 'btn', type: 'button', html: `${icon('download')}<span>Export all</span>` });
  expAll.addEventListener('click', () => {
    if (!games.length) { toast('No games to export'); return; }
    download(`nova-chess-games-${new Date().toISOString().slice(0, 10)}.pgn`, games.map((g) => g.pgn).join('\n\n') + '\n', 'application/x-chess-pgn');
  });

  const tableHost = h('div');
  el.append(
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Game History'), h('p', null, 'Everything you have played or imported, saved on this device.')), h('div', { style: { display: 'flex', gap: '.5rem', flexWrap: 'wrap' } }, imp, expAll)),
    h('div', { class: 'toolbar' }, h('div', { class: 'grow' }, search), seg('result', [['all', 'All'], ['w', 'Wins'], ['l', 'Losses'], ['d', 'Draws']]), seg('mode', [['all', 'All modes'], ['engine', 'vs Stockfish'], ['local', 'Local'], ['other', 'Imported']])),
    h('div', { class: 'card', style: { padding: '.4rem' } }, tableHost));

  function matches(g) {
    if (f.q && !`${g.white} ${g.black} ${g.event ?? ''} ${g.levelName ?? ''}`.toLowerCase().includes(f.q)) return false;
    if (f.result !== 'all' && gameOutcome(g) !== f.result) return false;
    if (f.mode === 'engine' && g.mode !== 'engine') return false;
    if (f.mode === 'local' && g.mode !== 'local') return false;
    if (f.mode === 'other' && (g.mode === 'engine' || g.mode === 'local')) return false;
    return true;
  }

  function renderTable() {
    const rows = games.filter(matches);
    if (!rows.length) { tableHost.replaceChildren(h('div', { class: 'empty' }, games.length ? 'No games match these filters.' : 'No games yet. Finished games against Stockfish or on the local board are saved automatically (see Settings → Additional).')); return; }
    const table = h('table', { class: 'table' },
      h('thead', null, h('tr', null, ...['', 'Game', 'Color', 'Date', 'Duration', 'Moves', ''].map((t, i) => h('th', { class: [2, 4].includes(i) ? 'hide-m' : '' }, t)))),
      h('tbody', null, ...rows.map((g) => {
        const acts = h('div', { class: 'acts' });
        const btn = (label, ic, fn, cls = '') => { const b = h('button', { class: `btn sm ${cls}`, type: 'button', title: label, 'aria-label': label, html: `${icon(ic)}<span class="hide-m">${label}</span>` }); b.addEventListener('click', fn); acts.append(b); };
        btn('Replay', 'play', () => app.newGame({ mode: 'practice', playerColor: null, timeControl: null, replay: true, pgn: g.pgn, white: { name: g.white }, black: { name: g.black }, orientation: g.playerColor === 'b' ? 'b' : 'w' }));
        btn('Analyze', 'review', () => app.go(`/review/${g.id}`), 'primary');
        btn('PGN', 'download', () => download(recordFileName(g), g.pgn, 'application/x-chess-pgn'));
        btn('Delete', 'trash', async () => {
          if (!(await confirmDialog('Delete this game?', 'It will be removed from this device. Statistics already counted stay as they are.', 'Delete', 'danger'))) return;
          await db.deleteGame(g.id); games = games.filter((x) => x.id !== g.id); renderTable(); toast('Game deleted');
        }, 'ghost');
        const sub = g.mode === 'engine' ? (g.rated ? 'Rated' : 'Unrated') : g.mode === 'local' ? 'Local' : g.mode === 'import' ? 'Imported' : 'Analysis';
        return h('tr', null,
          h('td', null, resultChip(g)),
          h('td', null, h('div', { style: { fontWeight: 600 } }, gameTitle(g)), h('div', { class: 'muted', style: { fontSize: '.76rem' } }, `${g.result === '*' ? 'Unfinished' : `${g.result} ${REASON_TEXT[g.reason] ?? ''}`.trim()} · ${sub}${g.ratingDelta != null ? ` · ${g.ratingDelta >= 0 ? '+' : ''}${g.ratingDelta}` : ''}`)),
          h('td', { class: 'hide-m' }, g.playerColor ? (g.playerColor === 'w' ? 'White' : 'Black') : '—'),
          h('td', null, fmtDate(g.date)),
          h('td', { class: 'hide-m mono' }, g.durationMs ? fmtDuration(g.durationMs) : '—'),
          h('td', { class: 'mono' }, String(Math.ceil(g.plies / 2))),
          h('td', null, acts));
      })));
    tableHost.replaceChildren(h('div', { class: 'table-wrap' }, table));
  }
  renderTable();
  root.append(el);
  return { destroy: () => el.remove() };
}
