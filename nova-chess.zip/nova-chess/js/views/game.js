// Game screen used by every playable mode: vs Stockfish, local 2-player, practice and analysis board.
import { Chess } from '../../vendor/chess.js';
import { h, icon, toast, modal, confirmDialog, fmtClock, fmtDuration, download, debounce, sleep, avatarEl, esc } from '../util.js';
import { settings, activeGameStore, db } from '../store.js';
import { Board, fenToMap } from '../board.js';
import { GameSession, capturedUpTo, materialOf, REASON_TEXT, START_FEN } from '../game.js';
import { engines, resolveLevel, fmtScore, barPercent, uciToMove, scoreToCp } from '../engine.js';
import { play, playForMove } from '../audio.js';
import { pieceEl } from '../pieces.js';
import { recordFinished } from '../stats.js';
import { parseGame } from '../pgn.js';
import { recordFileName } from '../pgn.js';

const kingSquare = (chess, color) => {
  for (const row of chess.board()) for (const p of row) if (p && p.type === 'k' && p.color === color) return p.square;
  return null;
};

function pvToSan(fen, pv, n = 8) {
  const c = new Chess(fen);
  const out = [];
  for (const u of pv.slice(0, n)) {
    try {
      const m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
      out.push(m.san);
    } catch { break; }
  }
  return out;
}

export class GameView {
  constructor(app, session) {
    this.app = app;
    this.s = session;
    this.cfg = session.cfg;
    this.mode = this.cfg.mode;
    this.playerColor = this.cfg.playerColor ?? null;
    this.level = this.cfg.engineLevel ?? null;
    this.viewPly = session.cfg.replay ? 0 : session.ply;
    this.engineBusy = false;
    this.engineToken = 0;
    this.evalToken = 0;
    this.pending = null;
    this.promoOpen = false;
    this.destroyed = false;
    this.lines = [];
    this.score = null;
    this.engineFailed = false;
    this.lastOfferPly = -99;
    this.arrowsOn = this.mode === 'analysis';
    this.finishedHandled = false;
    this.isPlayMode = this.mode === 'engine' || this.mode === 'local';
  }

  // ===================================================================== mount
  mount(root) {
    this.root = root;
    const user = this.app.user;
    this.el = h('div', { class: 'game' });
    root.append(this.el);

    // --- board column
    this.evalEl = h('div', { class: 'evalbar', 'aria-label': 'Evaluation bar' },
      h('div', { class: 'fill' }), h('div', { class: 'mid' }), (this.evalVal = h('div', { class: 'val bottom on-white mono' }, '0.0')));
    this.topSlot = h('div'); this.bottomSlot = h('div');
    this.boardHost = h('div', { class: 'board-wrap' });
    this.confirmBar = h('div', { class: 'status-line', hidden: true, style: { justifyContent: 'space-between' } });
    this.controlsEl = h('div', { class: 'controls' });
    this.boardCol = h('div', { class: 'board-col' }, this.topSlot, this.boardHost, this.bottomSlot, this.confirmBar, this.controlsEl);
    this.el.append(h('div', { class: 'game-main' }, this.evalEl, this.boardCol));

    // --- strips
    this.strips = { w: this.makeStrip('w'), b: this.makeStrip('b') };

    // --- side panel
    this.statusEl = h('div', { class: 'status-line' });
    this.movesEl = h('div', { class: 'moves' });
    this.movesEl.addEventListener('click', (e) => {
      const c = e.target.closest('[data-ply]');
      if (c) this.goTo(Number(c.dataset.ply));
    });
    const navRow = h('div', { class: 'nav-row' },
      this.navBtn('first', 'Start', () => this.goTo(0)), this.navBtn('prev', 'Previous', () => this.goTo(this.viewPly - 1)),
      this.navBtn('next', 'Next', () => this.goTo(this.viewPly + 1)), this.navBtn('last', 'Latest', () => this.goTo(this.s.ply)));
    this.paneMoves = h('div', { class: 'tabpane' }, this.movesEl, navRow);
    this.paneEngine = h('div', { class: 'tabpane', hidden: true });
    this.paneGame = h('div', { class: 'tabpane', hidden: true });
    this.tabs = h('div', { class: 'tabs' });
    const tabDefs = [['moves', 'Moves', this.paneMoves], ['engine', 'Engine', this.paneEngine], ['game', 'Game', this.paneGame]];
    for (const [id, label, pane] of tabDefs) {
      const b = h('button', { type: 'button', 'data-tab': id }, label);
      b.addEventListener('click', () => this.selectTab(id));
      this.tabs.append(b);
    }
    this.tabPanes = Object.fromEntries(tabDefs.map(([id, , p]) => [id, p]));
    this.panel = h('div', { class: 'panel' }, this.tabs, this.paneMoves, this.paneEngine, this.paneGame);
    this.panelToggle = h('button', { class: 'btn panel-toggle', type: 'button' }, h('span', null, 'Moves, engine & game info'), h('span', { html: icon('chevdown') }));
    this.side = h('div', { class: 'side' }, this.statusEl, this.panelToggle, this.panel);
    const narrow = matchMedia('(max-width: 860px)').matches;
    if (narrow) this.side.classList.add('collapsed');
    this.panelToggle.addEventListener('click', () => this.side.classList.toggle('collapsed'));
    this.el.append(this.side);
    this.selectTab('moves');
    this.buildEngineTab();
    this.buildGameTab();
    this.buildControls();

    // --- board
    this.board = new Board(this.boardHost, {
      interactive: () => this.interactive(),
      targets: (sq) => this.targetsFor(sq),
      onMove: (f, t) => this.onBoardMove(f, t),
      onIllegal: () => { if (this.interactive()) play('illegal'); },
    });
    this.board.setOrientation(this.initialOrientation());
    this.bindSession();
    this.placeStrips();

    // --- global listeners
    this._key = (e) => this.onKey(e);
    document.addEventListener('keydown', this._key);
    this._unsubSettings = settings.on('change', (keys) => this.onSettings(keys));
    this._engStatus = (st, detail) => this.onEngineStatus(st, detail);
    engines.analysis.on('status', this._engStatus);
    engines.play.on('status', this._engStatus);

    this.applySettingsUI();
    this.render({ animate: false });
    if (this.s.timed) { this.s.resumeClock(); this.startClockTimer(); }
    if (this.mode === 'engine') engines.play.init().catch(() => this.onEngineFailure('Stockfish failed to load'));
    this.requestEval();
    if (this.s.ply === 0 && !this.s.over) play('start');
    this.maybeEngineMove();
    if (this.s.over && this.isPlayMode) this.updateAll();
  }

  initialOrientation() {
    if (this.mode === 'engine') return this.playerColor ?? 'w';
    return this.cfg.orientation ?? 'w';
  }

  bindSession() {
    this.s.on('result', (r) => this.onResult(r));
  }

  navBtn(ic, label, fn) {
    const b = h('button', { class: 'btn icon-btn ghost', type: 'button', 'aria-label': label, title: label, html: icon(ic) });
    b.addEventListener('click', fn);
    return b;
  }

  makeStrip(color) {
    const root = h('div', { class: 'strip' });
    const av = h('div', { class: 'strip-av' });
    const name = h('div', { class: 'nm' });
    const cap = h('div', { class: 'captured' });
    const think = h('span', { class: 'thinking' }, h('i'), h('i'), h('i'), ' thinking');
    const clock = h('div', { class: 'clock mono' }, '');
    root.append(av, h('div', { class: 'who' }, name, cap), think, clock);
    return { root, av, name, cap, clock, think, color };
  }

  placeStrips() {
    const bottom = this.board.orientation;
    const top = bottom === 'w' ? 'b' : 'w';
    this.topSlot.replaceChildren(this.strips[top].root);
    this.bottomSlot.replaceChildren(this.strips[bottom].root);
    this.evalEl.classList.toggle('flipped', bottom === 'b');
    this.updateEvalUI();
  }

  // ===================================================================== info
  playerInfo(color) {
    const cfg = this.cfg;
    const side = color === 'w' ? cfg.white : cfg.black;
    const isEngine = this.mode === 'engine' && color !== this.playerColor;
    if (isEngine) return { name: 'Stockfish 19', sub: `${this.level?.name ?? ''}${this.level?.elo ? ` · ~${this.level.elo}` : ''}`, engine: true };
    return { name: side?.name ?? (color === 'w' ? 'White' : 'Black'), sub: side?.rating ? String(side.rating) : '', engine: false, avatar: side?.avatar };
  }

  updateStrips() {
    const s = this.s, ply = this.viewPly;
    const cap = capturedUpTo(s.moves, ply);
    const mat = materialOf(fenToMap(s.fenAt(ply)));
    for (const color of ['w', 'b']) {
      const st = this.strips[color];
      const info = this.playerInfo(color);
      st.name.replaceChildren(info.name, info.sub ? h('small', null, info.sub) : '');
      // avatar
      if (!st._avKey || st._avKey !== `${info.engine}|${info.avatar}|${info.name}`) {
        st._avKey = `${info.engine}|${info.avatar}|${info.name}`;
        let av;
        if (info.engine) { av = h('div', { class: 'avatar sm', style: { background: 'linear-gradient(135deg,#27d3e6,#7c6cff)' }, html: icon('cpu') }); av.firstChild.style.cssText = 'width:60%;height:60%'; }
        else if (this.mode === 'local' || info.avatar == null) {
          av = h('div', { class: 'avatar sm', style: { background: color === 'w' ? '#e9e6dc' : '#2a2d35' } }); av.append(pieceEl(color, 'K', ''));
          av.firstChild.style.cssText = 'width:80%;height:80%';
        } else av = avatarEl(info.avatar, 'sm');
        st.av.replaceChildren(av);
      }
      // captured pieces + material difference
      const mine = cap[color]; // pieces this colour has captured
      const frag = [];
      const groups = {};
      for (const t of mine) (groups[t] ??= []).push(t);
      for (const t of ['q', 'r', 'b', 'n', 'p']) {
        if (!groups[t]) continue;
        const grp = h('span', { class: 'grp' });
        for (const _ of groups[t]) grp.append(pieceEl(color === 'w' ? 'b' : 'w', t));
        frag.push(grp);
      }
      const diff = mat[color] - mat[color === 'w' ? 'b' : 'w'];
      if (diff > 0) frag.push(h('span', { class: 'adv' }, `+${diff}`));
      st.cap.replaceChildren(...(settings.get('showCaptured') ? frag : []));
    }
    this.updateClocks();
  }

  updateClocks() {
    const s = this.s;
    for (const color of ['w', 'b']) {
      const st = this.strips[color];
      if (!s.timed) { st.clock.classList.add('hidden'); continue; }
      st.clock.classList.remove('hidden');
      const ms = s.remaining(color);
      const txt = fmtClock(ms);
      if (st._ct !== txt) { st.clock.textContent = txt; st._ct = txt; }
      st.clock.classList.toggle('low', ms < 10000);
      st.clock.classList.toggle('active', s.clockRunning && !s.over && s.turn === color);
    }
  }

  startClockTimer() {
    this.stopClockTimer();
    this._clockTimer = setInterval(() => {
      if (this.destroyed) return;
      if (this.s.checkFlag()) return; // result handler runs via session event
      this.updateClocks();
    }, 100);
  }
  stopClockTimer() { clearInterval(this._clockTimer); this._clockTimer = null; }

  // ================================================================ rendering
  render({ move = null, animate = true } = {}) {
    const ply = this.viewPly;
    const fen = this.s.fenAt(ply);
    let check = null;
    if (ply === this.s.ply) check = this.s.checkSquare();
    else { const c = new Chess(fen); if (c.isCheck()) check = kingSquare(c, c.turn()); }
    const last = ply > 0 ? this.s.moves[ply - 1] : null;
    this.board.cancelInteraction();
    this.board.render(fenToMap(fen), { move, animate, lastMove: last, check });
    this.updateAll();
  }

  updateAll() {
    this.updateStrips();
    this.updateMoves();
    this.updateStatus();
    this.updateButtons();
    this.updateGameTab();
  }

  updateMoves() {
    const s = this.s, el = this.movesEl;
    el.replaceChildren();
    const frag = document.createDocumentFragment();
    let num = s.startMoveNumber;
    for (let p = 0; p < s.moves.length; p++) {
      const m = s.moves[p];
      if (m.color === 'w' || p === 0) {
        frag.append(h('div', { class: 'n' }, `${num}.`));
        if (m.color === 'b') frag.append(h('div', { class: 'm' }, '…'));
      }
      frag.append(h('div', { class: `m${p + 1 === this.viewPly ? ' cur' : ''}`, 'data-ply': p + 1, role: 'button', tabindex: '-1' }, m.san));
      if (m.color === 'b') num++;
    }
    if (!s.moves.length) frag.append(h('div', { class: 'muted', style: { gridColumn: '1 / -1', padding: '.7rem' } }, 'No moves yet.'));
    el.append(frag);
    el.classList.toggle('nonotation', !settings.get('showNotation'));
    const cur = el.querySelector('.cur');
    if (cur) el.scrollTop = Math.max(0, cur.offsetTop - el.clientHeight / 2);
    else if (this.viewPly === s.ply) el.scrollTop = el.scrollHeight;
  }

  statusText() {
    const s = this.s;
    if (s.result) {
      const r = s.result;
      const why = REASON_TEXT[r.reason] ?? '';
      if (r.result === '1/2-1/2') return `Draw ${why}`;
      const winner = r.winner ?? (r.result === '1-0' ? 'w' : 'b');
      if (this.mode === 'engine') return `${winner === this.playerColor ? 'You won' : 'Stockfish won'} ${why}`;
      return `${winner === 'w' ? 'White' : 'Black'} won ${why}`;
    }
    const turn = s.turn;
    const chk = s.isCheck() ? ' — check!' : '';
    if (this.mode === 'engine') {
      if (turn === this.playerColor) return `Your move${chk}`;
      return this.engineFailed ? 'Stockfish stopped responding' : `Stockfish is thinking…`;
    }
    return `${turn === 'w' ? 'White' : 'Black'} to move${chk}`;
  }

  updateStatus() {
    const s = this.s;
    const parts = [];
    parts.push(h('span', { style: { flex: 1 } }, this.statusText()));
    if (this.viewPly !== s.ply) {
      const b = h('button', { class: 'btn sm', type: 'button' }, 'Back to live');
      b.addEventListener('click', () => this.goTo(s.ply));
      parts.push(b);
    }
    if (this.engineFailed && !s.over) {
      const b = h('button', { class: 'btn sm primary', type: 'button' }, 'Retry');
      b.addEventListener('click', () => { this.engineFailed = false; engines.play.initPromise = null; this.maybeEngineMove(); this.updateStatus(); });
      parts.push(b);
    }
    const claim = !s.over && this.isPlayMode ? s.claimable() : null;
    if (claim && s.cfg.autoClaimDraws === false && (this.mode === 'local' || s.turn === this.playerColor)) {
      const b = h('button', { class: 'btn sm primary', type: 'button' }, `Claim draw (${claim === 'repetition' ? 'repetition' : '50 moves'})`);
      b.addEventListener('click', () => { s.claimDraw(); });
      parts.push(b);
    }
    this.statusEl.classList.toggle('over', !!s.result);
    this.statusEl.replaceChildren(...parts);
    for (const color of ['w', 'b']) this.strips[color].think.classList.toggle('on', this.engineBusy && this.mode === 'engine' && color !== this.playerColor && !s.over);
  }

  // ================================================================ controls
  buildControls() {
    const mk = (id, ic, label, fn, cls = '') => {
      const b = h('button', { class: `btn ${cls}`, type: 'button', 'data-act': id, title: label, 'aria-label': label }, h('span', { html: icon(ic) }), h('span', { class: 'lbl' }, label));
      b.addEventListener('click', fn);
      return b;
    };
    const flip = mk('flip', 'flip', 'Flip', () => this.flipBoard());
    let list;
    if (this.mode === 'engine') list = [flip, mk('undo', 'undo', 'Takeback', () => this.undo()), mk('redo', 'redo', 'Redo', () => this.redo()), mk('draw', 'draw', 'Draw', () => this.offerDraw()), mk('resign', 'flag', 'Resign', () => this.resign(), 'danger'), mk('restart', 'restart', 'Restart', () => this.restart())];
    else if (this.mode === 'local') list = [flip, mk('undo', 'undo', 'Undo', () => this.undo()), mk('redo', 'redo', 'Redo', () => this.redo()), mk('draw', 'draw', 'Draw', () => this.offerDraw()), mk('resign', 'flag', 'Resign', () => this.resign(), 'danger'), mk('restart', 'restart', 'Restart', () => this.restart())];
    else {
      list = [flip, mk('undo', 'undo', 'Undo', () => this.undo()), mk('redo', 'redo', 'Redo', () => this.redo()), mk('hint', 'bulb', 'Best move', () => this.toggleArrows()), mk('setup', 'board', 'Set up', () => this.openSetup()), mk('restart', 'restart', 'Reset', () => this.restart())];
      if (this.cfg.replay) list.splice(1, 0, mk('auto', 'play', 'Auto-play', () => this.toggleAutoplay(), ''));
    }
    this.controlsEl.replaceChildren(...list);
    this.btn = Object.fromEntries(list.map((b) => [b.dataset.act, b]));
  }

  updateButtons() {
    const s = this.s, b = this.btn;
    if (!b) return;
    const live = this.viewPly === s.ply;
    const canUndo = this.mode === 'engine' ? s.ply >= (this.playerColor === 'w' ? 1 : 2) && s.canUndo() : s.canUndo();
    b.undo?.classList.toggle('disabled', !canUndo || !!this.pending);
    b.redo?.classList.toggle('disabled', !s.canRedo() || !!this.pending);
    b.resign?.classList.toggle('disabled', s.over || s.ply < 1);
    b.draw?.classList.toggle('disabled', s.over || s.ply < 2 || !live);
    b.hint?.classList.toggle('primary', this.arrowsOn);
  }

  toggleAutoplay() {
    if (this._auto) { clearInterval(this._auto); this._auto = null; this.btn.auto?.classList.remove('primary'); return; }
    if (this.viewPly >= this.s.ply) this.goTo(0);
    this.btn.auto?.classList.add('primary');
    this._auto = setInterval(() => {
      if (this.viewPly >= this.s.ply) { clearInterval(this._auto); this._auto = null; this.btn.auto?.classList.remove('primary'); return; }
      this.goTo(this.viewPly + 1);
    }, 900);
  }

  flipBoard() {
    this.board.flip();
    this.placeStrips();
    this.updateEvalUI();
    this.drawArrows();
  }

  // ==================================================================== input
  humanTurn() { return this.mode === 'engine' ? this.s.turn === this.playerColor : true; }
  interactive() {
    return !this.destroyed && !this.s.over && this.viewPly === this.s.ply && this.humanTurn() && !this.pending && !this.promoOpen;
  }
  targetsFor(sq) {
    const p = this.s.chess.get(sq);
    if (!p || p.color !== this.s.turn) return [];
    if (this.mode === 'engine' && p.color !== this.playerColor) return [];
    return this.s.legalTargets(sq);
  }

  async onBoardMove(from, to) {
    let promotion;
    if (this.s.isPromotion(from, to)) {
      if (settings.get('autoQueen')) promotion = 'q';
      else {
        this.promoOpen = true;
        promotion = await this.board.askPromotion(to, this.s.turn);
        this.promoOpen = false;
        if (!promotion) { this.board.cancelInteraction(); return; }
      }
    }
    if (settings.get('confirmMoves') && this.isPlayMode) return this.proposeMove({ from, to, promotion });
    this.applyMove({ from, to, promotion });
  }

  proposeMove(m) {
    const c = new Chess(this.s.fen);
    let mv;
    try { mv = c.move(m); } catch { return; }
    this.pending = m;
    this.board.render(fenToMap(c.fen()), { move: mv, animate: true, lastMove: mv, check: c.isCheck() ? kingSquare(c, c.turn()) : null });
    const ok = h('button', { class: 'btn sm primary', type: 'button' }, 'Confirm');
    const no = h('button', { class: 'btn sm', type: 'button' }, 'Cancel');
    ok.addEventListener('click', () => { const p = this.pending; this.pending = null; this.confirmBar.hidden = true; this.applyMove(p); });
    no.addEventListener('click', () => { this.pending = null; this.confirmBar.hidden = true; this.render({ animate: false }); });
    this.confirmBar.replaceChildren(h('span', null, `Play ${mv.san}?`), h('span', { style: { display: 'flex', gap: '.4rem' } }, no, ok));
    this.confirmBar.hidden = false;
    this.updateButtons();
  }

  applyMove(m, { engine = false } = {}) {
    const s = this.s;
    const wasLive = this.viewPly === s.ply;
    const mv = s.move(m);
    if (!mv) { play('illegal'); this.render({ animate: false }); return null; }
    const mate = s.result?.reason === 'checkmate';
    playForMove(mv, { check: s.isCheck(), mate });
    if (wasLive) this.viewPly = s.ply;
    this.render({ move: wasLive ? mv : null, animate: true });
    this.afterPositionChange();
    return mv;
  }

  afterPositionChange() {
    this.persist();
    this.drawArrows();
    this.requestEval();
    if (this.s.timed && !this._clockTimer && !this.s.over) this.startClockTimer();
    if (this.mode === 'local' && this.cfg.autoFlip && !this.s.over) { this.board.setOrientation(this.s.turn); this.placeStrips(); }
    this.maybeEngineMove();
  }

  goTo(ply) {
    const n = Math.max(0, Math.min(this.s.ply, ply));
    if (n === this.viewPly) return;
    const forward = n === this.viewPly + 1;
    const step = forward ? this.s.moves[n - 1] : null;
    this.viewPly = n;
    if (step) playForMove(step, { check: false });
    this.render({ move: step, animate: !!step });
    this.drawArrows();
    this.requestEval();
  }

  onKey(e) {
    if (e.target.closest?.('input, textarea, select, [contenteditable]')) return;
    if (document.querySelector('.modal-back')) return;
    if (e.key === 'ArrowLeft') { e.preventDefault(); this.goTo(this.viewPly - 1); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); this.goTo(this.viewPly + 1); }
    else if (e.key === 'ArrowUp' || e.key === 'Home') { e.preventDefault(); this.goTo(0); }
    else if (e.key === 'ArrowDown' || e.key === 'End') { e.preventDefault(); this.goTo(this.s.ply); }
    else if (e.key === 'f' || e.key === 'F') this.flipBoard();
    else if (e.key === 'Escape') this.board.cancelInteraction();
  }

  // ======================================================== undo / redo / etc.
  undo() {
    const s = this.s;
    if (this.pending) return;
    if (!s.canUndo()) return;
    this.stopEngine();
    if (this.mode === 'engine') {
      let n = 0;
      do { if (!s.undo(1)) break; n++; } while (s.turn !== this.playerColor && s.ply > 0);
      if (n && this.s.moves.length === 0 && this.playerColor === 'b') { /* engine will move again */ }
    } else s.undo(1);
    this.finishedHandled = false;
    this.afterHistoryEdit();
  }
  redo() {
    const s = this.s;
    if (!s.canRedo()) return;
    this.stopEngine();
    s.redo(this.mode === 'engine' ? Math.min(2, s.redoStack.length) : 1);
    this.afterHistoryEdit(true);
  }
  afterHistoryEdit(redo = false) {
    const s = this.s;
    this.viewPly = s.ply;
    if (s.timed) { s.pauseClock(); s.resumeClock(); }
    const last = s.moves[s.ply - 1];
    if (last) playForMove(last, { check: s.isCheck(), mate: s.result?.reason === 'checkmate' });
    else play('move');
    this.render({ move: redo ? last : null, animate: !!redo });
    this.afterPositionChange();
  }

  async resign() {
    const s = this.s;
    if (s.over || s.ply < 1) return;
    if (this.mode === 'engine') {
      if (!(await confirmDialog('Resign game?', 'Stockfish will be awarded the win.', 'Resign', 'danger'))) return;
      this.stopEngine();
      s.resign(this.playerColor);
    } else {
      const choice = await modal({ title: 'Who resigns?', body: 'The other side is awarded the win.', actions: [{ label: 'Cancel', value: null }, { label: 'White resigns', value: 'w', kind: 'danger' }, { label: 'Black resigns', value: 'b', kind: 'danger' }] });
      if (!choice) return;
      s.resign(choice);
    }
  }

  async offerDraw() {
    const s = this.s;
    if (s.over || s.ply < 2) return;
    if (this.mode === 'local') {
      const by = s.turn === 'w' ? 'Black' : 'White', to = s.turn === 'w' ? 'White' : 'Black';
      // The side that just moved may offer; the side to move decides.
      const ok = await confirmDialog('Draw offered', `${by} offers a draw. Does ${to} accept?`, 'Accept draw');
      if (ok) s.agreeDraw(); else toast('Draw declined');
      return;
    }
    if (this.s.ply - this.lastOfferPly < 6) { toast('Stockfish declined your recent offer — keep playing a few more moves.'); return; }
    this.lastOfferPly = this.s.ply;
    toast('Draw offered…');
    try {
      await engines.analysis.setOptions({ 'Skill Level': 20, UCI_LimitStrength: false, Hash: settings.get('hash') });
      const res = await engines.analysis.search({ fen: s.fen, depth: 12, movetime: 700 });
      if (res.stopped || this.destroyed) return;
      const engineColor = this.playerColor === 'w' ? 'b' : 'w';
      const cp = scoreToCp(res.top?.score) * (engineColor === 'w' ? 1 : -1);
      if (cp <= 30) { s.agreeDraw(); toast('Stockfish accepted the draw.', 'good'); }
      else toast('Stockfish declines the draw — it thinks it is better.', 'bad');
    } catch { toast('Engine unavailable — draw not decided.', 'bad'); }
  }

  async restart() {
    const ok = this.s.ply === 0 || this.s.over || await confirmDialog(this.isPlayMode ? 'Restart game?' : 'Reset board?', this.isPlayMode ? 'The current game will be abandoned (it will not be saved).' : 'This clears the current moves.', 'Restart', 'danger');
    if (!ok) return;
    this.stopEngine();
    this.app.newGame({ ...this.cfg, startFen: this.mode === 'engine' || this.mode === 'local' ? undefined : START_FEN, colorChoice: this.cfg.colorChoice });
  }

  // =================================================================== engine
  stopEngine() {
    this.engineToken++;
    this.engineBusy = false;
    engines.play.stop();
    this.updateStatus();
  }

  onEngineFailure(msg) {
    this.engineFailed = true;
    this.engineBusy = false;
    toast(msg, 'bad', 5000);
    this.updateStatus();
    this.updateEngineTab();
  }

  async maybeEngineMove() {
    const s = this.s;
    if (this.mode !== 'engine' || s.over || this.destroyed || s.turn === this.playerColor || this.engineBusy || this.pending) return;
    if (this.viewPly !== s.ply) { /* still compute – the move is applied to the live position */ }
    const token = ++this.engineToken;
    this.engineBusy = true;
    this.engineFailed = false;
    this.updateStatus();
    try {
      const lvl = this.level;
      await engines.play.applyStrength(lvl, { hash: settings.get('hash'), threads: settings.get('threads') });
      if (token !== this.engineToken) return;
      const fen = s.fen, ply = s.ply;
      const t0 = performance.now();
      let movetime = lvl.movetime;
      const rem = s.remaining(s.turn);
      if (rem != null) movetime = Math.min(movetime, Math.max(60, rem * 0.06));
      const res = await engines.play.search({ fen, depth: lvl.depth, movetime });
      if (token !== this.engineToken || this.destroyed || s.ply !== ply || s.over) return;
      if (!res.best) throw new Error('Engine returned no move');
      const spent = performance.now() - t0;
      if (spent < lvl.delay) await sleep(lvl.delay - spent);
      if (token !== this.engineToken || this.destroyed || s.ply !== ply || s.over) return;
      this.engineBusy = false;
      this.applyMove(uciToMove(res.best), { engine: true });
    } catch (e) {
      if (token !== this.engineToken) return;
      console.error('[engine move]', e);
      this.onEngineFailure(`Stockfish error: ${e.message ?? e}`);
    } finally {
      if (token === this.engineToken) { this.engineBusy = false; this.updateStatus(); if (this.evalDeferred) { this.evalDeferred = false; this.requestEval(); } }
    }
  }

  // ============================================================== live eval
  requestEval() {
    if (this.destroyed) return;
    (this._evalDeb ??= debounce(() => this.runEval(), 140))();
  }

  async runEval() {
    if (this.destroyed) return;
    const token = ++this.evalToken;
    const fen = this.s.fenAt(this.viewPly);
    const c = new Chess(fen);
    if (c.isCheckmate()) { this.setEval({ mate: 0, winner: c.turn() === 'w' ? 'b' : 'w' }, [], fen); return; }
    if (c.isDraw()) { this.setEval({ cp: 0 }, [], fen); return; }
    if (!settings.get('liveEval')) { this.setEval(null, [], fen); return; }
    if (this.engineBusy) { this.evalDeferred = true; return; }
    const analysisMode = this.mode === 'analysis' || this.mode === 'practice';
    try {
      await engines.analysis.setOptions({ 'Skill Level': 20, UCI_LimitStrength: false, Hash: settings.get('hash'), Threads: settings.get('threads') });
      if (token !== this.evalToken) return;
      let lastUI = 0;
      const res = await engines.analysis.search({
        fen, depth: settings.get('analysisDepth'), movetime: settings.get('analysisTime') * (analysisMode ? 4 : 1), multipv: settings.get('multiPV'),
        onInfo: (info, lines) => {
          if (token !== this.evalToken) return;
          const now = performance.now();
          if (now - lastUI < 120) return;
          lastUI = now;
          this.setEval(lines[0]?.score ?? info.score, lines, fen, info);
        },
      });
      if (token !== this.evalToken || res.stopped) return;
      this.setEval(res.top?.score ?? null, res.lines, fen, res.top);
    } catch (e) {
      if (token !== this.evalToken) return;
      console.warn('[live eval]', e);
      this.setEval(null, [], fen, null, 'Engine unavailable');
    }
  }

  setEval(score, lines, fen, info = null, err = '') {
    this.score = score; this.lines = lines; this.linesFen = fen; this.evalInfo = info; this.evalErr = err;
    this.updateEvalUI();
    this.updateEngineTab();
    this.drawArrows();
  }

  updateEvalUI() {
    if (!this.evalEl) return;
    const show = settings.get('showEvalBar');
    this.evalEl.style.display = show ? '' : 'none';
    const on = settings.get('liveEval') || this.score?.mate === 0;
    this.evalEl.classList.toggle('off', !on);
    const sc = on ? this.score : null;
    const pct = on ? barPercent(sc) : 50;
    this.evalEl.querySelector('.fill').style.setProperty('--p', `${pct}%`);
    const whiteAhead = pct >= 50;
    const flipped = this.board?.orientation === 'b';
    this.evalVal.textContent = on && sc ? fmtScore(sc, { signed: false }).replace(/^\+/, '') : '–';
    // label sits on the side that is winning
    const atBottom = whiteAhead !== flipped;
    this.evalVal.className = `val ${atBottom ? 'bottom' : 'top'} ${whiteAhead ? 'on-white' : 'on-black'} mono`;
    this.evalEl.title = sc ? `Evaluation: ${fmtScore(sc)}` : 'Evaluation off';
  }

  // ----------------------------------------------------------------- arrows
  drawArrows() {
    if (!this.board) return;
    const allow = this.mode === 'analysis' || this.mode === 'practice';
    if (!allow || !this.arrowsOn || this.linesFen !== this.s.fenAt(this.viewPly) || !this.lines?.length) { this.board.setArrows([]); return; }
    const cols = ['#6fbf4a', '#4f9cf0', '#a77bff'];
    this.board.setArrows(this.lines.slice(0, 3).map((l, i) => ({ from: l.pv[0].slice(0, 2), to: l.pv[0].slice(2, 4), color: cols[i], opacity: i ? 0.55 : 0.88 })).reverse());
  }
  toggleArrows() {
    this.arrowsOn = !this.arrowsOn;
    if (this.arrowsOn && !settings.get('liveEval')) { toast('Turn on live evaluation in Settings → Engine to see engine arrows.'); }
    this.drawArrows(); this.updateButtons(); this.updateEngineTab();
    if (this.arrowsOn && !this.lines.length) this.requestEval();
  }

  // ------------------------------------------------------------ engine tab
  buildEngineTab() {
    this.engStatus = h('div', { class: 'engine-status' }, h('i'), h('span', null, 'Stockfish'));
    this.engKv = h('div', { class: 'kv' });
    this.engLines = h('div', { class: 'lines' });
    this.engNote = h('div', { class: 'hint' });
    this.engActions = h('div', { style: { display: 'flex', gap: '.4rem', flexWrap: 'wrap' } });
    this.paneEngine.append(h('div', { class: 'engine-info' }, this.engStatus, this.engKv, this.engLines, this.engNote, this.engActions));
  }
  onEngineStatus(st, detail) {
    this.engStatusState = st; this.engStatusDetail = detail;
    this.updateEngineTab();
  }
  updateEngineTab() {
    if (!this.engStatus) return;
    const ea = engines.analysis;
    const st = this.engineBusy ? 'busy' : ea.status === 'busy' ? 'busy' : ea.status === 'error' || engines.play.status === 'error' ? 'error' : ea.status === 'ready' || engines.play.status === 'ready' ? 'ready' : ea.status;
    this.engStatus.className = `engine-status ${st}`;
    const label = engines.play.label || ea.label || 'Stockfish 19 Lite (WASM)';
    this.engStatus.querySelector('span').textContent = st === 'error' ? 'Engine error' : st === 'loading' ? 'Loading Stockfish…' : st === 'busy' ? `${label} — analysing` : st === 'idle' ? `${label} — idle` : `${label} — ready`;
    const info = this.evalInfo;
    this.engKv.replaceChildren(
      h('div', null, h('small', null, 'Eval'), h('b', null, this.score && settings.get('liveEval') ? fmtScore(this.score) : '–')),
      h('div', null, h('small', null, 'Depth'), h('b', null, info?.depth ? String(info.depth) : '–')),
      h('div', null, h('small', null, 'Nodes/s'), h('b', null, info?.nps ? `${Math.round(info.nps / 1000)}k` : '–')),
    );
    const showLines = this.mode === 'analysis' || this.mode === 'practice' || this.mode === 'local' || this.s.over;
    this.engLines.replaceChildren();
    if (!settings.get('liveEval') && !(this.score?.mate === 0)) {
      this.engNote.textContent = 'Live evaluation is turned off (Settings → Engine).';
    } else if (this.mode === 'engine' && !this.s.over) {
      this.engNote.textContent = 'Engine lines are hidden during a game against Stockfish; the evaluation bar still updates.';
    } else if (this.evalErr) this.engNote.textContent = this.evalErr;
    else this.engNote.textContent = this.lines?.length ? '' : 'Waiting for analysis…';
    if (showLines && this.linesFen === this.s.fenAt(this.viewPly) && !(this.mode === 'engine' && !this.s.over)) {
      for (const l of this.lines ?? []) {
        const san = pvToSan(this.linesFen, l.pv, 8);
        const pos = scoreToCp(l.score) >= 0;
        const row = h('div', { class: 'line', title: this.mode === 'analysis' || this.mode === 'practice' ? 'Click to play this move' : '' },
          h('span', { class: `sc ${pos ? 'pos' : 'neg'}` }, fmtScore(l.score)), h('span', { class: 'pv' }, san.join(' ')));
        if ((this.mode === 'analysis' || this.mode === 'practice') && l.pv[0]) {
          row.style.cursor = 'pointer';
          row.addEventListener('click', () => { if (this.interactive()) this.applyMove(uciToMove(l.pv[0])); });
        }
        this.engLines.append(row);
      }
    }
    const acts = [];
    if (!settings.get('liveEval')) {
      const b = h('button', { class: 'btn sm', type: 'button' }, 'Analyze this position once');
      b.addEventListener('click', () => this.analyzeOnce());
      acts.push(b);
    }
    if (this.mode === 'analysis' || this.mode === 'practice') {
      const b = h('button', { class: `btn sm ${this.arrowsOn ? 'primary' : ''}`, type: 'button' }, this.arrowsOn ? 'Hide arrows' : 'Show arrows');
      b.addEventListener('click', () => this.toggleArrows());
      acts.push(b);
    }
    this.engActions.replaceChildren(...acts);
  }

  async analyzeOnce() {
    const fen = this.s.fenAt(this.viewPly);
    this.evalErr = '';
    try {
      await engines.analysis.setOptions({ 'Skill Level': 20, UCI_LimitStrength: false, Hash: settings.get('hash') });
      const res = await engines.analysis.search({ fen, depth: settings.get('analysisDepth'), movetime: Math.max(1000, settings.get('analysisTime')), multipv: settings.get('multiPV') });
      if (res.stopped) return;
      this.score = res.top?.score ?? null; this.lines = res.lines; this.linesFen = fen; this.evalInfo = res.top;
      this.updateEngineTab(); this.drawArrows();
      const el = this.evalEl.querySelector('.fill');
      el.style.setProperty('--p', `${barPercent(this.score)}%`);
    } catch (e) { toast('Engine unavailable', 'bad'); }
  }

  // -------------------------------------------------------------- game tab
  buildGameTab() {
    this.gameInfo = h('div', { class: 'engine-info' });
    this.paneGame.append(this.gameInfo);
  }
  updateGameTab() {
    const s = this.s, cfg = this.cfg;
    const kv = (k, v) => h('div', { style: { display: 'flex', justifyContent: 'space-between', gap: '1rem', fontSize: '.86rem' } }, h('span', { class: 'muted' }, k), h('b', null, v));
    const rows = [
      kv('Mode', { engine: 'Player vs Stockfish', local: 'Local two-player', practice: 'Practice board', analysis: 'Analysis board' }[this.mode] ?? this.mode),
    ];
    if (this.mode === 'engine') rows.push(kv('Opponent', `Stockfish · ${this.level?.name}`), kv('Strength', this.level?.limit ? `Elo-limited ~${this.level.uciElo}` : `Skill ${this.level?.skill}`), kv('Search', `depth ≤ ${this.level?.depth}, ≤ ${this.level?.movetime} ms`));
    rows.push(kv('Time control', s.timed ? cfg.timeControl?.id ?? 'custom' : 'Unlimited'), kv('Moves', String(Math.ceil(s.ply / 2))));
    if (this.isPlayMode && this.mode === 'engine') rows.push(kv('Rated', s.undoUsed ? 'No (takeback used)' : 'Yes · local estimate'));
    const acts = h('div', { style: { display: 'flex', gap: '.4rem', flexWrap: 'wrap', marginTop: '.4rem' } });
    const add = (label, ic, fn, cls = '') => { const b = h('button', { class: `btn sm ${cls}`, type: 'button' }, h('span', { html: icon(ic) }), label); b.addEventListener('click', fn); acts.append(b); };
    add('Copy PGN', 'copy', () => this.copy(s.pgn(), 'PGN copied'));
    add('Download PGN', 'download', () => download(`nova-chess-${new Date().toISOString().slice(0, 10)}.pgn`, s.pgn(), 'application/x-chess-pgn'));
    add('Copy FEN', 'copy', () => this.copy(s.fenAt(this.viewPly), 'FEN copied'));
    if (!this.isPlayMode) {
      add('Import PGN / FEN', 'upload', () => this.openSetup());
      add('Save to history', 'check', () => this.saveToHistory());
    }
    if (this.s.ply > 0) add('Analyze', 'review', () => this.openReview());
    rows.push(acts);
    this.gameInfo.replaceChildren(...rows);
  }

  async copy(text, msg) {
    try { await navigator.clipboard.writeText(text); toast(msg, 'good'); }
    catch {
      const ta = h('textarea', { style: { position: 'fixed', opacity: 0 } }, text); document.body.append(ta); ta.select();
      try { document.execCommand('copy'); toast(msg, 'good'); } catch { toast('Copy failed — select the text manually', 'bad'); }
      ta.remove();
    }
  }

  selectTab(id) {
    this.tab = id;
    for (const b of this.tabs.children) b.classList.toggle('on', b.dataset.tab === id);
    for (const [k, p] of Object.entries(this.tabPanes)) p.hidden = k !== id;
    if (id === 'engine') this.updateEngineTab();
    if (id === 'game') this.updateGameTab();
  }

  // ====================================================== setup / import / save
  async openSetup() {
    const fenIn = h('input', { class: 'input mono', placeholder: 'FEN, e.g. rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', value: this.s.fenAt(this.viewPly) });
    const pgnIn = h('textarea', { class: 'input', rows: 6, placeholder: '[Event "…"]\n\n1. e4 e5 2. Nf3 …' });
    const err = h('div', { class: 'error-text' });
    const body = h('div', { style: { display: 'grid', gap: '.8rem' } },
      h('div', { class: 'field' }, h('label', null, 'Position (FEN)'), fenIn),
      h('div', { class: 'field' }, h('label', null, 'Or paste a PGN game'), pgnIn),
      h('div', { class: 'hint' }, 'A PGN replaces the board with that game so you can step through it and keep analysing.'), err);
    const ok = await modal({
      title: 'Set up position / import', body, actions: [{ label: 'Cancel', value: false }, { label: 'Load', value: true, kind: 'primary', onClick: () => {
        err.textContent = '';
        try {
          if (pgnIn.value.trim()) this.loadPgn(pgnIn.value);
          else this.loadFen(fenIn.value.trim());
        } catch (e) { err.textContent = e.message; return false; }
        return true;
      } }],
    });
    return ok;
  }

  loadFen(fen) {
    let c;
    try { c = new Chess(fen); } catch { throw new Error('That is not a valid FEN position.'); }
    const kings = fen.split(' ')[0].replace(/[^kK]/g, '');
    if (kings.length !== 2) throw new Error('A position needs exactly one king per side.');
    this.replaceSession(new GameSession({ ...this.cfg, startFen: c.fen() }), []);
  }
  loadPgn(text) {
    const parsed = parseGame(text);
    this.replaceSession(new GameSession({ ...this.cfg, startFen: parsed.startFen, white: { name: parsed.headers.White ?? 'White' }, black: { name: parsed.headers.Black ?? 'Black' } }), parsed.moves);
  }
  replaceSession(session, moves) {
    this.stopEngine();
    this.s.off?.('result');
    this.s = session;
    for (const m of moves) session.move({ from: m.from, to: m.to, promotion: m.promotion }, { silent: true });
    this.bindSession();
    this.viewPly = session.ply;
    this.lines = []; this.score = null;
    this.render({ animate: false });
    this.persist();
    this.requestEval();
    toast('Position loaded', 'good');
  }

  buildRecord() {
    const s = this.s, cfg = this.cfg;
    return {
      userId: this.app.user.id,
      date: new Date(s.startedAt - (s.elapsedBefore ?? 0)).toISOString(),
      mode: this.mode,
      white: cfg.white?.name ?? 'White', black: cfg.black?.name ?? 'Black',
      whiteElo: this.mode === 'engine' && this.playerColor === 'b' ? null : cfg.white?.rating ?? null,
      blackElo: this.mode === 'engine' && this.playerColor === 'w' ? null : cfg.black?.rating ?? null,
      playerColor: this.mode === 'engine' ? this.playerColor : null,
      result: s.result?.result ?? '*',
      reason: s.result?.reason ?? 'unfinished',
      pgn: s.pgn(),
      plies: s.ply,
      durationMs: s.elapsedMs(),
      event: this.mode === 'engine' ? 'Nova Chess – vs Stockfish' : this.mode === 'local' ? 'Nova Chess – local game' : 'Nova Chess – analysis',
      rated: this.mode === 'engine' && !s.undoUsed,
      levelId: this.level?.id ?? null, levelName: this.level?.name ?? null, levelElo: this.level?.elo ?? null,
      timeControl: cfg.timeControl?.id ?? 'none',
      startFen: s.startFen,
    };
  }

  async saveToHistory() {
    if (!this.s.ply) { toast('Nothing to save yet — make a move first.'); return; }
    const rec = this.buildRecord();
    rec.mode = 'analysis';
    rec.event = 'Nova Chess – analysis';
    rec.id = await db.addGame(rec);
    toast('Saved to Game History', 'good');
  }

  async openReview() {
    const rec = this.buildRecord();
    this.app.tempRecord = rec;
    this.app.go('/review/tmp');
  }

  // =================================================================== result
  async onResult(r) {
    if (this.destroyed) return;
    this.stopEngine();
    this.s.pauseClock();
    this.stopClockTimer();
    this.updateAll();
    this.drawArrows();
    this.requestEval();
    if (!this.isPlayMode || this.finishedHandled) return;
    this.finishedHandled = true;
    const s = this.s;
    const winnerIsPlayer = this.mode === 'engine' ? r.winner === this.playerColor : null;
    setTimeout(() => play(r.result === '1/2-1/2' ? 'end' : winnerIsPlayer === false ? 'end' : 'win'), r.reason === 'checkmate' ? 700 : 150);
    let info = null, rec = null;
    if (s.ply > 0) {
      rec = this.buildRecord();
      info = recordFinished(this.app.user, rec);
      if (settings.get('autoSave')) {
        try { rec.id = await db.addGame(rec); } catch (e) { console.error(e); toast('Could not save the game to history', 'bad'); }
      }
      this.app.tempRecord = rec;
    }
    activeGameStore.clear(this.app.user.id);
    setTimeout(() => { if (!this.destroyed) this.showResultDialog(r, rec, info); }, 900);
  }

  showResultDialog(r, rec, info) {
    const s = this.s;
    let title, sub = REASON_TEXT[r.reason] ?? '';
    if (r.result === '1/2-1/2') title = 'Draw';
    else if (this.mode === 'engine') title = r.winner === this.playerColor ? 'You won!' : 'Stockfish wins';
    else title = `${r.winner === 'w' ? 'White' : 'Black'} wins`;
    sub = `${r.result} · ${sub}`;
    const body = h('div', { style: { display: 'grid', gap: '.7rem', textAlign: 'center' } },
      h('div', { style: { fontSize: '2rem', fontFamily: 'var(--font-display)', fontWeight: 700 } }, title),
      h('div', { class: 'muted' }, sub),
      h('div', { class: 'muted', style: { fontSize: '.85rem' } }, `${Math.ceil(s.ply / 2)} moves · ${fmtDuration(s.elapsedMs())}`));
    if (info?.rated) body.append(h('div', { class: `pill ${info.delta >= 0 ? 'good' : 'bad'}`, style: { justifySelf: 'center' } }, `Estimated local rating ${info.rating} (${info.delta >= 0 ? '+' : ''}${info.delta})`));
    else if (this.mode === 'engine' && s.undoUsed) body.append(h('div', { class: 'hint' }, 'Unrated: takebacks were used.'));
    const actions = [
      { label: 'Close', value: 'close' },
      { label: 'Download PGN', value: 'pgn' },
      { label: 'New game', value: 'new' },
      { label: 'Rematch', value: 'rematch' },
      { label: 'Review game', value: 'review', kind: 'primary' },
    ];
    modal({ title: '', body, actions }).then((v) => {
      if (v === 'review') this.openReview();
      else if (v === 'rematch') this.rematch();
      else if (v === 'new') this.app.go(this.mode === 'engine' ? '/play/engine' : '/play/local');
      else if (v === 'pgn') { download(rec ? recordFileName(rec) : 'game.pgn', s.pgn(), 'application/x-chess-pgn'); }
    });
  }

  rematch() {
    const cfg = { ...this.cfg, startFen: undefined };
    if (this.mode === 'engine') {
      const pc = this.playerColor === 'w' ? 'b' : 'w';
      const me = { name: this.app.user.name, rating: this.app.stats?.rating, avatar: this.app.user.avatar };
      const eng = { name: 'Stockfish 19', rating: null };
      cfg.playerColor = pc; cfg.colorChoice = pc;
      cfg.white = pc === 'w' ? me : eng; cfg.black = pc === 'w' ? eng : me;
    } else { cfg.white = this.cfg.black; cfg.black = this.cfg.white; }
    this.app.newGame(cfg);
  }

  // ================================================================ lifecycle
  persist() {
    if (this.destroyed) return;
    try {
      if (this.s.over && this.isPlayMode) return;
      activeGameStore.save(this.app.user.id, { kind: 'game', data: this.s.serialize() });
    } catch (e) { console.warn('persist failed', e); }
  }

  onSettings(keys) {
    this.applySettingsUI();
    if (!keys || keys.some((k) => ['liveEval', 'analysisDepth', 'analysisTime', 'multiPV', 'hash'].includes(k))) this.requestEval();
    if (!keys || keys.includes('showCaptured') || keys.includes('showNotation')) this.updateAll();
  }
  applySettingsUI() {
    this.updateEvalUI();
    this.updateEngineTab();
  }

  destroy() {
    if (this.destroyed) return;
    this.s.pauseClock?.();
    this.persist();
    this.destroyed = true;
    this.stopClockTimer();
    clearInterval(this._auto);
    this.engineToken++;
    this.evalToken++;
    engines.play.stop();
    engines.analysis.stop();
    this._evalDeb?.cancel?.();
    document.removeEventListener('keydown', this._key);
    this._unsubSettings?.();
    engines.analysis.off('status', this._engStatus);
    engines.play.off('status', this._engStatus);
    this.board?.destroy();
    this.el?.remove();
  }
}
