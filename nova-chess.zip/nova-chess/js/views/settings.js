// Settings: every control is bound to a persisted setting (see store.js DEFAULT_SETTINGS).
import { h, icon, toast, confirmDialog } from '../util.js';
import { settings, DEFAULT_SETTINGS, db, activeGameStore } from '../store.js';
import { LEVELS } from '../engine.js';
import { TIME_CONTROLS } from '../game.js';
import { PIECE_SETS, previewURI } from '../pieces.js';
import { play, unlockAudio } from '../audio.js';
import { resetStats } from '../stats.js';

const BOARD_THEMES = [
  ['green', 'Classic Green', '#eeeed2', '#769656'], ['brown', 'Tournament Brown', '#efdab6', '#ad7d52'], ['blue', 'Blue', '#dfe9f3', '#6b8fb8'],
  ['purple', 'Purple', '#e9e1f5', '#8a6bb8'], ['slate', 'Slate', '#cfd5de', '#5f6e84'], ['wood', 'Wooden', '#ecc78d', '#a46c32'], ['minimal', 'Minimal Dark', '#3d424c', '#2a2e36'],
];
const ACCENTS = ['#7c6cff', '#27d3e6', '#3ecf8e', '#f5a524', '#ef5b8b', '#4f8cff', '#e879f9'];

const TABS = [['gameplay', 'Gameplay'], ['engine', 'Chess Engine'], ['board', 'Board & Pieces'], ['interface', 'Interface'], ['more', 'Additional']];

export function mountSettings(root, app, tabId) {
  let tab = TABS.some(([id]) => id === tabId) ? tabId : 'gameplay';
  const el = h('div');
  const nav = h('div', { class: 'settings-nav', role: 'tablist' });
  const body = h('div', { class: 'card' });

  const row = (label, desc, ...ctl) => h('div', { class: 'set-row' }, h('div', { class: 'lbl' }, h('b', null, label), desc ? h('span', null, desc) : ''), h('div', { class: 'ctl' }, ...ctl));
  const toggle = (key, after) => {
    const i = h('input', { type: 'checkbox', role: 'switch', checked: settings.get(key), 'aria-label': key });
    i.addEventListener('change', () => { settings.set({ [key]: i.checked }); after?.(i.checked); });
    return h('label', { class: 'switch' }, i, h('span'));
  };
  const select = (key, options, { num = false, after } = {}) => {
    const s = h('select', { class: 'select', 'aria-label': key });
    for (const [v, label] of options) s.append(h('option', { value: v, selected: String(settings.get(key)) === String(v) }, label));
    s.addEventListener('change', () => { settings.set({ [key]: num ? Number(s.value) : s.value }); after?.(); });
    return s;
  };
  const range = (key, min, max, step, fmt = (v) => v, after) => {
    const out = h('output', { class: 'mono', style: { minWidth: '3.6rem', textAlign: 'right', fontWeight: 700, fontSize: '.85rem' } }, fmt(settings.get(key)));
    const i = h('input', { type: 'range', min, max, step, value: settings.get(key), 'aria-label': key, style: { flex: 1, minWidth: '90px' } });
    i.addEventListener('input', () => { out.textContent = fmt(Number(i.value)); settings.set({ [key]: Number(i.value) }); after?.(); });
    return h('div', { style: { display: 'flex', alignItems: 'center', gap: '.7rem', width: '100%' } }, i, out);
  };
  const note = (t, cls = '') => h('div', { class: `notice ${cls}`, style: { margin: '.6rem 0' } }, t);

  const sections = {
    gameplay: () => [
      row('Default game mode', 'Highlighted on the Play screen', select('defaultMode', [['engine', 'Player vs Stockfish'], ['local', 'Local two-player'], ['practice', 'Practice board'], ['analysis', 'Analysis board']])),
      row('Default player color', 'Used when starting a game against Stockfish', select('defaultColor', [['w', 'White'], ['b', 'Black'], ['random', 'Random']])),
      row('Default time control', '', select('defaultTC', TIME_CONTROLS.map((t) => [t.id, t.base == null ? 'Unlimited' : `${t.name}${t.tag ? ` · ${t.tag}` : ''}`]))),
      row('Confirm moves', 'Preview a move and confirm it before it is played (useful on touch screens)', toggle('confirmMoves')),
      row('Auto-queen promotion', 'Skip the promotion picker and always promote to a queen', toggle('autoQueen')),
      row('Highlight legal moves', 'Dots on squares the selected piece can reach', toggle('highlightLegal')),
      row('Highlight last move', '', toggle('highlightLast')),
      row('Show captured pieces', 'Material count beside each player', toggle('showCaptured')),
      row('Piece animations', 'Slide pieces between squares', toggle('animations')),
      row('Claim draws automatically', 'Draw at threefold repetition / fifty moves without asking. When off, a “Claim draw” button appears instead.', toggle('autoClaimDraws')),
    ],
    engine: () => {
      const lvl = settings.get('engineLevel');
      const out = [
        row('Engine difficulty', 'Preset used for new games against Stockfish', select('engineLevel', [...LEVELS.map((l) => [l.id, `${l.name} (~${l.elo})`]), ['custom', 'Custom']], { after: () => renderTab() })),
      ];
      if (lvl === 'custom') {
        out.push(
          row('Skill level', '0 (weakest) to 20 (full strength)', range('engineSkill', 0, 20, 1)),
          row('Limit strength to Elo', 'Uses Stockfish’s UCI_LimitStrength', toggle('engineLimit', () => renderTab())),
          ...(settings.get('engineLimit') ? [row('Target Elo', '1320 – 3190', range('engineElo', 1320, 3190, 10))] : []),
          row('Maximum search depth', 'Plies the engine may search per move', range('engineDepth', 1, 30, 1)),
          row('Thinking time per move', 'Upper bound while playing', range('engineMoveTime', 50, 10000, 50, (v) => `${(v / 1000).toFixed(2)} s`)));
      } else out.push(note('Choose “Custom” above to set skill level, an Elo cap, depth and thinking time yourself.'));
      out.push(
        row('Live evaluation', 'Run Stockfish continuously to drive the evaluation bar', toggle('liveEval')),
        row('Maximum analysis depth', 'Used by live evaluation and Game Review', range('analysisDepth', 6, 30, 1)),
        row('Analysis time', 'Per position for live evaluation (the analysis board uses 4×)', range('analysisTime', 100, 5000, 50, (v) => `${(v / 1000).toFixed(2)} s`)),
        row('Multi-PV lines', 'Number of candidate lines shown on the analysis board', range('multiPV', 1, 5, 1)),
        row('Engine threads', 'The bundled Stockfish build is single-threaded, so this is stored but has no effect', select('threads', [[1, '1 thread'], [2, '2 threads'], [4, '4 threads']], { num: true })),
        row('Hash memory', 'Transposition-table size', select('hash', [[16, '16 MB'], [32, '32 MB'], [64, '64 MB'], [128, '128 MB'], [256, '256 MB']], { num: true })));
      return out;
    },
    board: () => {
      const themes = h('div', { class: 'theme-grid' });
      for (const [id, name, l, d] of BOARD_THEMES) {
        const mini = h('div', { class: 'mini' });
        for (let i = 0; i < 16; i++) { const light = ((i % 4) + Math.floor(i / 4)) % 2 === 1; const sq = h('i', { class: light ? 'l' : 'd' }); sq.style.background = light ? l : d; if (id === 'wood') sq.style.backgroundImage = 'repeating-linear-gradient(93deg, rgba(0,0,0,.08) 0 2px, transparent 2px 8px)'; mini.append(sq); }
        const b = h('button', { type: 'button', class: `theme-opt${settings.get('boardTheme') === id ? ' on' : ''}`, 'aria-pressed': String(settings.get('boardTheme') === id) }, mini, name);
        b.addEventListener('click', () => { settings.set({ boardTheme: id }); renderTab(); });
        themes.append(b);
      }
      const pieces = h('div', { class: 'theme-grid' });
      for (const p of PIECE_SETS) {
        const prev = h('div', { class: 'piece-prev', style: { background: 'var(--sq-light)', borderRadius: '8px' } });
        for (const [c, t] of [['w', 'N'], ['b', 'Q'], ['w', 'P']]) { const s = h('span', { class: 'pc' }); s.style.backgroundImage = previewURI(p.id, c, t); prev.append(s); }
        const darkRow = h('div', { class: 'piece-prev', style: { background: 'var(--sq-dark)', borderRadius: '8px' } });
        for (const [c, t] of [['b', 'N'], ['w', 'K'], ['b', 'P']]) { const s = h('span', { class: 'pc' }); s.style.backgroundImage = previewURI(p.id, c, t); darkRow.append(s); }
        const b = h('button', { type: 'button', class: `theme-opt${settings.get('pieceSet') === p.id ? ' on' : ''}`, 'aria-pressed': String(settings.get('pieceSet') === p.id) }, prev, darkRow, p.name);
        b.addEventListener('click', () => { settings.set({ pieceSet: p.id }); renderTab(); });
        pieces.append(b);
      }
      return [
        h('div', { class: 'set-row stack' }, h('div', { class: 'lbl' }, h('b', null, 'Board theme')), h('div', { class: 'ctl' }, themes)),
        h('div', { class: 'set-row stack' }, h('div', { class: 'lbl' }, h('b', null, 'Piece set'), h('span', null, 'All piece artwork is original to Nova Chess.')), h('div', { class: 'ctl' }, pieces)),
      ];
    },
    interface: () => {
      const sw = h('div', { class: 'swatches' });
      for (const c of ACCENTS) { const b = h('button', { type: 'button', class: `swatch${settings.get('accent').toLowerCase() === c ? ' on' : ''}`, style: { background: c }, 'aria-label': `Accent ${c}` }); b.addEventListener('click', () => { settings.set({ accent: c }); renderTab(); }); sw.append(b); }
      const color = h('input', { type: 'color', value: settings.get('accent'), 'aria-label': 'Custom accent colour' });
      color.addEventListener('change', () => { settings.set({ accent: color.value }); renderTab(); });
      sw.append(color);
      const theme = h('div', { class: 'seg' });
      for (const [v, l] of [['dark', 'Dark'], ['light', 'Light']]) { const b = h('button', { type: 'button', class: settings.get('theme') === v ? 'on' : '' }, l); b.addEventListener('click', () => { settings.set({ theme: v }); renderTab(); }); theme.append(b); }
      const testSound = h('button', { class: 'btn sm', type: 'button', html: `${icon('sound')}<span>Test</span>` });
      testSound.addEventListener('click', () => { unlockAudio(); play('capture'); });
      return [
        row('Appearance', 'Dark is the default', theme),
        row('Accent color', '', sw),
        row('Interface scaling', 'Scales text and controls', range('scale', 80, 130, 5, (v) => `${v}%`)),
        row('Sound effects', 'Master switch for all sounds', toggle('sound', () => renderTab())),
        ...(settings.get('sound') ? [
          row('Move sounds', 'Moves, captures, checks, castling and promotion', toggle('moveSounds')),
          row('Volume', '', range('volume', 0, 100, 5, (v) => `${v}%`), testSound)] : []),
        row('Animation speed', 'Piece movement', select('animSpeed', [['fast', 'Fast'], ['normal', 'Normal'], ['slow', 'Slow']])),
        row('Animations', 'Turn off all motion in the interface (independent of sound)', toggle('animations')),
      ];
    },
    more: () => {
      const reset = h('button', { class: 'btn danger sm', type: 'button' }, 'Reset settings');
      reset.addEventListener('click', async () => { if (await confirmDialog('Reset all settings?', 'Every setting returns to its default. Games and statistics are not affected.', 'Reset', 'danger')) { settings.reset(); renderTab(); toast('Settings reset', 'good'); } });
      const wipe = h('button', { class: 'btn danger sm', type: 'button' }, 'Delete my data');
      wipe.addEventListener('click', async () => {
        if (!(await confirmDialog('Delete all local data for this profile?', 'This permanently deletes saved games, puzzle progress, statistics and any game in progress for this profile.', 'Delete everything', 'danger'))) return;
        await db.deleteGamesOf(app.user.id); await db.deleteProgress(app.user.id); resetStats(app.user.id); activeGameStore.clear(app.user.id);
        app.refreshStats(); app.updateUserCard(); toast('Local data deleted', 'good');
      });
      return [
        row('Show coordinates', 'Files and ranks on the board edge', toggle('showCoords')),
        row('Show legal moves', 'Same as Gameplay → Highlight legal moves', toggle('highlightLegal')),
        row('Show evaluation bar', 'Hide the bar while keeping live evaluation running', toggle('showEvalBar')),
        row('Show move notation', 'Hide SAN in the move list to play “blindfold”', toggle('showNotation')),
        row('Save games automatically', 'Finished games go to Game History', toggle('autoSave')),
        row('Reset settings', 'Restore every setting to its default', reset),
        row('Delete my data', 'Games, puzzle progress and statistics for this profile', wipe),
      ];
    },
  };

  function renderTab() {
    for (const b of nav.children) { b.classList.toggle('on', b.dataset.id === tab); b.setAttribute('aria-selected', String(b.dataset.id === tab)); }
    body.replaceChildren(h('div', { class: 'set-section' }, ...sections[tab]()));
  }
  for (const [id, label] of TABS) {
    const b = h('button', { type: 'button', 'data-id': id, role: 'tab' }, label);
    b.addEventListener('click', () => { tab = id; history.replaceState(null, '', `#/settings/${id}`); renderTab(); });
    nav.append(b);
  }
  el.append(h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Settings'), h('p', null, 'Changes apply immediately and are remembered after you refresh.'))), h('div', { class: 'settings' }, nav, body));
  root.append(el);
  renderTab();
  return { destroy: () => el.remove() };
}
