// Persistence: IndexedDB (users, games, puzzle progress) + localStorage (settings, session, active game).
// Falls back to an in-memory store if IndexedDB is unavailable (e.g. some private-browsing modes).
import { Emitter } from './util.js';

const DB_NAME = 'nova-chess';
const DB_VERSION = 1;
let dbPromise = null;
let memoryMode = false;
const mem = { users: new Map(), games: new Map(), progress: new Map(), nextId: 1 };

export const isMemoryMode = () => memoryMode;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    if (!('indexedDB' in window)) { memoryMode = true; return resolve(null); }
    let req;
    try { req = indexedDB.open(DB_NAME, DB_VERSION); } catch { memoryMode = true; return resolve(null); }
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('users')) db.createObjectStore('users', { keyPath: 'key' });
      if (!db.objectStoreNames.contains('games')) {
        const g = db.createObjectStore('games', { keyPath: 'id', autoIncrement: true });
        g.createIndex('userId', 'userId');
      }
      if (!db.objectStoreNames.contains('progress')) db.createObjectStore('progress', { keyPath: 'key' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => { memoryMode = true; resolve(null); };
    req.onblocked = () => { memoryMode = true; resolve(null); };
  });
  return dbPromise;
}

function tx(db, store, mode, fn) {
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    let out;
    const r = fn(s);
    if (r) r.onsuccess = () => { out = r.result; };
    t.oncomplete = () => resolve(out);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}

export const db = {
  async init() { await openDB(); return !memoryMode; },

  // ---- users
  async getUser(key) {
    const d = await openDB();
    if (!d) return mem.users.get(key) ?? null;
    return (await tx(d, 'users', 'readonly', (s) => s.get(key))) ?? null;
  },
  async putUser(user) {
    const d = await openDB();
    if (!d) { mem.users.set(user.key, structuredClone(user)); return; }
    await tx(d, 'users', 'readwrite', (s) => s.put(user));
  },
  async deleteUser(key) {
    const d = await openDB();
    if (!d) { mem.users.delete(key); return; }
    await tx(d, 'users', 'readwrite', (s) => s.delete(key));
  },

  // ---- games
  async addGame(game) {
    const d = await openDB();
    if (!d) { game.id = mem.nextId++; mem.games.set(game.id, structuredClone(game)); return game.id; }
    const copy = { ...game }; delete copy.id;
    return tx(d, 'games', 'readwrite', (s) => s.add(copy));
  },
  async putGame(game) {
    const d = await openDB();
    if (!d) { mem.games.set(game.id, structuredClone(game)); return game.id; }
    return tx(d, 'games', 'readwrite', (s) => s.put(game));
  },
  async getGame(id) {
    const d = await openDB();
    if (!d) return mem.games.get(Number(id)) ?? null;
    return (await tx(d, 'games', 'readonly', (s) => s.get(Number(id)))) ?? null;
  },
  async listGames(userId) {
    const d = await openDB();
    let all;
    if (!d) all = [...mem.games.values()].filter((g) => g.userId === userId);
    else all = await tx(d, 'games', 'readonly', (s) => s.index('userId').getAll(userId));
    return (all ?? []).sort((a, b) => (a.date < b.date ? 1 : -1));
  },
  async deleteGame(id) {
    const d = await openDB();
    if (!d) { mem.games.delete(Number(id)); return; }
    await tx(d, 'games', 'readwrite', (s) => s.delete(Number(id)));
  },
  async deleteGamesOf(userId) {
    for (const g of await this.listGames(userId)) await this.deleteGame(g.id);
  },

  // ---- puzzle progress
  async getProgress(userId) {
    const d = await openDB();
    const key = `${userId}`;
    const rec = !d ? mem.progress.get(key) : await tx(d, 'progress', 'readonly', (s) => s.get(key));
    return rec?.data ?? { solved: {}, failed: {}, streak: 0, bestStreak: 0, attempts: 0 };
  },
  async putProgress(userId, data) {
    const d = await openDB();
    const rec = { key: `${userId}`, data };
    if (!d) { mem.progress.set(rec.key, structuredClone(rec)); return; }
    await tx(d, 'progress', 'readwrite', (s) => s.put(rec));
  },
  async deleteProgress(userId) {
    const d = await openDB();
    if (!d) { mem.progress.delete(`${userId}`); return; }
    await tx(d, 'progress', 'readwrite', (s) => s.delete(`${userId}`));
  },
};

// ----------------------------------------------------------- localStorage --
const ls = {
  get(k, fallback = null) {
    try { const v = localStorage.getItem(k); return v == null ? fallback : JSON.parse(v); } catch { return fallback; }
  },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } },
};
export { ls };

// ---------------------------------------------------------------- settings --
export const DEFAULT_SETTINGS = Object.freeze({
  // gameplay
  defaultMode: 'engine',        // engine | local | practice | analysis
  defaultColor: 'w',            // w | b | random
  defaultTC: 'none',            // time-control id
  confirmMoves: false,
  autoQueen: false,
  highlightLegal: true,
  highlightLast: true,
  showCaptured: true,
  animations: true,
  autoClaimDraws: true,
  // engine
  engineLevel: 'intermediate',  // preset id or 'custom'
  engineSkill: 10,
  engineLimit: false,
  engineElo: 1800,
  engineDepth: 12,
  engineMoveTime: 800,
  analysisDepth: 16,
  analysisTime: 400,
  multiPV: 1,
  liveEval: true,
  threads: 1,
  hash: 32,
  // board
  boardTheme: 'green',
  pieceSet: 'classic',
  // interface
  theme: 'dark',
  accent: '#7c6cff',
  scale: 100,
  sound: true,
  moveSounds: true,
  volume: 70,
  animSpeed: 'normal',          // fast | normal | slow
  // additional
  showCoords: true,
  showEvalBar: true,
  showNotation: true,
  autoSave: true,
});

class SettingsStore extends Emitter {
  constructor() { super(); this.userId = 'guest'; this.values = { ...DEFAULT_SETTINGS }; }
  key() { return `nova.settings.v1.${this.userId}`; }
  load(userId) {
    this.userId = userId || 'guest';
    const saved = ls.get(this.key(), {});
    // Only accept keys we know about, with the same primitive type as the default.
    const merged = { ...DEFAULT_SETTINGS };
    for (const [k, v] of Object.entries(saved ?? {})) {
      if (k in DEFAULT_SETTINGS && typeof v === typeof DEFAULT_SETTINGS[k]) merged[k] = v;
    }
    this.values = merged;
    this.apply();
    this.emit('change', null);
  }
  get(k) { return this.values[k]; }
  set(patch) {
    Object.assign(this.values, patch);
    ls.set(this.key(), this.values);
    this.apply();
    this.emit('change', Object.keys(patch));
  }
  reset() {
    this.values = { ...DEFAULT_SETTINGS };
    ls.set(this.key(), this.values);
    this.apply();
    this.emit('change', Object.keys(DEFAULT_SETTINGS));
  }
  apply() {
    const v = this.values;
    const root = document.documentElement;
    root.dataset.theme = v.theme;
    root.dataset.board = v.boardTheme;
    root.style.setProperty('--accent', v.accent);
    root.style.setProperty('--scale', String(v.scale / 100));
    const ms = { fast: 90, normal: 170, slow: 320 }[v.animSpeed] ?? 170;
    root.style.setProperty('--move-ms', `${v.animations ? ms : 0}ms`);
    root.classList.toggle('no-anim', !v.animations);
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', v.theme === 'light' ? '#eef0f5' : '#0d0f13');
  }
}
export const settings = new SettingsStore();

// ------------------------------------------------------------ active game --
export const activeGameStore = {
  key: (userId) => `nova.activeGame.v1.${userId}`,
  load(userId) { return ls.get(this.key(userId), null); },
  save(userId, data) { return ls.set(this.key(userId), data); },
  clear(userId) { ls.del(this.key(userId)); },
};
