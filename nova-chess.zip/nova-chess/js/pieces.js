// Original piece artwork for Nova Chess (drawn for this project; no third-party assets).
// One vector silhouette family is styled into five sets; "Pixel" is hand-made bitmaps and "Minimal" is geometric.
import { settings } from './store.js';

export const PIECE_SETS = [
  { id: 'classic', name: 'Classic' },
  { id: 'neo', name: 'Neo' },
  { id: 'alpha', name: 'Alpha' },
  { id: 'modern', name: 'Modern' },
  { id: 'pixel', name: 'Pixel' },
  { id: 'minimal', name: 'Minimal' },
];

const ROUND_BASE = (y1, y2, x1 = 24, x2 = 76) => `M${x1} ${y1} H${x2} V${y2 - 2} Q${x2} ${y2} ${x2 - 2} ${y2} H${x1 + 2} Q${x1} ${y2} ${x1} ${y2 - 2} Z`;

// body: closed shapes that get fill+stroke. detail: open strokes drawn on top.
const SHAPES = {
  P: {
    body: [
      '<circle cx="50" cy="28" r="12"/>',
      '<path d="M37.5 44.5 Q50 40.5 62.5 44.5 Q64 49 62 51 Q50 54.5 38 51 Q36 49 37.5 44.5 Z"/>',
      '<path d="M41.5 52 Q42.5 67 31 80 H69 Q57.5 67 58.5 52 Z"/>',
      `<path d="${ROUND_BASE(80, 88, 26, 74)}"/>`,
    ],
    detail: [],
  },
  R: {
    body: [
      '<path d="M28 14 H40 V22 H45 V14 H55 V22 H60 V14 H72 V31 L67 36 H33 L28 31 Z"/>',
      '<path d="M35.5 36 H64.5 L67.5 72 H32.5 Z"/>',
      `<path d="${ROUND_BASE(72, 88, 24, 76)}"/>`,
    ],
    detail: ['<path d="M29 31 H71"/>', '<path d="M30 72 H70"/>'],
  },
  N: {
    body: [
      '<path d="M27 80 C27 68 31 60 40 53 C43 51 45 49 44 46 C39 48 33 52 28 55 C22 58 16 54 17 48 C18 44 22 41 26 37 C28 34 29 31 30 27 L32 13 L39 21 C42 18 46 15 50 15 C66 17 78 34 79 58 C79 66 78 73 78 80 Z"/>',
      `<path d="${ROUND_BASE(80, 88, 24, 78)}"/>`,
    ],
    detail: ['<path d="M52 24 C63 30 70 42 72 60"/>', '<path d="M30 56 C34 55 38 53 41 50"/>'],
    dots: [['36', '34', '2.6'], ['21.5', '49', '1.7']],
  },
  B: {
    body: [
      '<circle cx="50" cy="13" r="5.5"/>',
      '<path d="M50 19.5 C62.5 28 70 39 64.5 49.5 C62.5 53 58.5 54.5 56.5 56.5 H43.5 C41.5 54.5 37.5 53 35.5 49.5 C30 39 37.5 28 50 19.5 Z"/>',
      '<path d="M35 56.5 H65 Q67 56.5 67 59 Q67 62 65 62 H35 Q33 62 33 59 Q33 56.5 35 56.5 Z"/>',
      '<path d="M42.5 62 H57.5 C58.5 72 63 77 70 80 H30 C37 77 41.5 72 42.5 62 Z"/>',
      `<path d="${ROUND_BASE(80, 88, 24, 76)}"/>`,
    ],
    detail: ['<path d="M44.5 42 L55.5 30.5"/>'],
  },
  Q: {
    body: [
      '<circle cx="19" cy="27" r="5.5"/><circle cx="34.5" cy="16.5" r="5.5"/><circle cx="50" cy="13.5" r="5.5"/><circle cx="65.5" cy="16.5" r="5.5"/><circle cx="81" cy="27" r="5.5"/>',
      '<path d="M20.5 32 L33 58 L36.5 29 L50 57 L63.5 29 L67 58 L79.5 32 L76 66 H24 Z"/>',
      '<path d="M26.5 66 H73.5 L72 74 H28 Z"/>',
      `<path d="${ROUND_BASE(74, 88, 23, 77)}"/>`,
    ],
    detail: ['<path d="M30 70 H70"/>'],
  },
  K: {
    body: [
      '<path d="M46.5 5 H53.5 V11 H59.5 V18 H53.5 V24.5 H46.5 V18 H40.5 V11 H46.5 Z"/>',
      '<path d="M50 24.5 C70 24.5 81 36 77 50 C75 56.5 69 60 67 66 H33 C31 60 25 56.5 23 50 C19 36 30 24.5 50 24.5 Z"/>',
      '<path d="M29.5 66 H70.5 L72.5 75 H27.5 Z"/>',
      `<path d="${ROUND_BASE(75, 88, 23, 77)}"/>`,
    ],
    detail: ['<path d="M33 70.5 H67"/>', '<path d="M36 40 C40 34 46 32 50 32"/>'],
  },
};

const PIXELS = {
  P: ['............', '....####....', '...#oooo#...', '...#oooo#...', '....####....', '....#oo#....', '...#oooo#...', '...#oooo#...', '....#oo#....', '...#oooo#...', '..#oooooo#..', '..########..'],
  R: ['.##..##..##.', '.##..##..##.', '.##########.', '..#oooooo#..', '...#oooo#...', '...#oooo#...', '...#oooo#...', '...#oooo#...', '..#oooooo#..', '.#oooooooo#.', '.#oooooooo#.', '.##########.'],
  N: ['...##.##....', '..#oo#oo#...', '.#ooooooo#..', '#ooo#ooooo#.', '#oooooooooo#', '.####oooooo#', '....#oooooo#', '...#ooooooo#', '..#oooooooo#', '..#oooooooo#', '.#oooooooo#.', '.##########.'],
  B: ['.....##.....', '....#oo#....', '...#oooo#...', '..#ooo#oo#..', '..#oo#ooo#..', '..#oooooo#..', '...#oooo#...', '....####....', '....#oo#....', '...#oooo#...', '..#oooooo#..', '..########..'],
  Q: ['#..#.##.#..#', '#o#.#oo#.#o#', '.#o#oooo#o#.', '.#oooooooo#.', '..#oooooo#..', '...#oooo#...', '..########..', '...#oooo#...', '...#oooo#...', '..#oooooo#..', '.#oooooooo#.', '.##########.'],
  K: ['.....##.....', '....####....', '.....##.....', '...#oooo#...', '..#oooooo#..', '.#oooooooo#.', '.#oooooooo#.', '..#oooooo#..', '..########..', '..#oooooo#..', '.#oooooooo#.', '.##########.'],
};

const TYPES = ['K', 'Q', 'R', 'B', 'N', 'P'];

function wrap(inner, defs = '') {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">${defs ? `<defs>${defs}</defs>` : ''}${inner}</svg>`;
}

function dotsOf(t, fill) {
  return (SHAPES[t].dots ?? []).map(([cx, cy, r]) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}"/>`).join('');
}

function vectorSVG(set, color, t) {
  const S = SHAPES[t];
  const w = color === 'w';
  const body = S.body.join('');
  const det = S.detail.join('');
  if (set === 'classic') {
    const fill = w ? 'url(#g)' : 'url(#g)';
    const defs = w
      ? '<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fffdf7"/><stop offset="1" stop-color="#e3dccb"/></linearGradient>'
      : '<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4d4a57"/><stop offset="1" stop-color="#25232b"/></linearGradient>';
    const stroke = w ? '#1d1b22' : '#0a090d';
    const dStroke = w ? '#1d1b22' : '#cfcad9';
    return wrap(
      `<g fill="${fill}" stroke="${stroke}" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round">${body}</g>` +
      `<g fill="none" stroke="${dStroke}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" opacity=".9">${det}</g>` +
      dotsOf(t, w ? '#1d1b22' : '#cfcad9'),
      defs,
    );
  }
  if (set === 'neo') {
    const f = w ? '#f7f7fa' : '#2b2f38';
    const dStroke = w ? '#9aa1b1' : '#8a91a3';
    const rim = w ? '#59607a' : '#0b0c10';
    return wrap(
      `<g fill="${rim}" stroke="${rim}" stroke-width="7.4" stroke-linejoin="round" stroke-linecap="round" filter="url(#s)">${body}</g>` +
      `<g fill="${f}" stroke="${f}" stroke-width="5.4" stroke-linejoin="round" stroke-linecap="round">${body}</g>` +
      `<g fill="none" stroke="${dStroke}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${det}</g>` +
      dotsOf(t, w ? '#5c6272' : '#d3d7e2'),
      '<filter id="s" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2.2" stdDeviation="1.6" flood-color="#000" flood-opacity=".38"/></filter>',
    );
  }
  if (set === 'alpha') {
    const main = w ? '#ffffff' : '#15151b';
    const halo = w ? '#101015' : '#ffffff';
    return wrap(
      `<g fill="none" stroke="${halo}" stroke-width="7" stroke-linejoin="round" stroke-linecap="round">${body}</g>` +
      `<g fill="${w ? 'rgba(255,255,255,.14)' : 'rgba(18,18,26,.78)'}" stroke="${main}" stroke-width="3.1" stroke-linejoin="round" stroke-linecap="round">${body}</g>` +
      `<g fill="none" stroke="${main}" stroke-width="2.2" stroke-linecap="round">${det}</g>` +
      dotsOf(t, main),
    );
  }
  if (set === 'modern') {
    const defs = w
      ? '<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".55" stop-color="#d7dbe6"/><stop offset="1" stop-color="#a7aebf"/></linearGradient>'
      : '<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#707889"/><stop offset=".5" stop-color="#363c49"/><stop offset="1" stop-color="#14171e"/></linearGradient>';
    const defs2 = defs + '<filter id="s" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2" stdDeviation="1.4" flood-color="#000" flood-opacity=".45"/></filter>';
    return wrap(
      `<g fill="url(#g)" stroke="${w ? '#5f6679' : '#05060a'}" stroke-width="1.7" stroke-linejoin="round" filter="url(#s)">${body}</g>` +
      `<g fill="none" stroke="${w ? 'rgba(60,66,84,.55)' : 'rgba(255,255,255,.4)'}" stroke-width="1.8" stroke-linecap="round">${det}</g>` +
      dotsOf(t, w ? '#3a4050' : '#e6e9f2'),
      defs2,
    );
  }
  return '';
}

function pixelSVG(color, t) {
  const w = color === 'w';
  const o = w ? '#1b1a22' : '#08080b';
  const f = w ? '#f2eee3' : '#5b586b';
  const g = PIXELS[t];
  const n = 12; const cell = 100 / n;
  let outline = ''; let fill = '';
  g.forEach((row, y) => {
    let x = 0;
    while (x < n) {
      const ch = row[x];
      if (ch === '.') { x++; continue; }
      let e = x; while (e < n && row[e] === ch) e++;
      const rect = `M${(x * cell).toFixed(2)} ${(y * cell).toFixed(2)}h${((e - x) * cell).toFixed(2)}v${cell.toFixed(2)}h-${((e - x) * cell).toFixed(2)}z`;
      if (ch === '#') outline += rect; else fill += rect;
      x = e;
    }
  });
  // subtle highlight pixel row for depth
  return wrap(`<g shape-rendering="crispEdges"><path d="${fill}" fill="${f}"/><path d="${outline}" fill="${o}"/></g>`);
}

function minimalSVG(color, t) {
  const w = color === 'w';
  const bg = w ? '#f3f1ea' : '#23262d';
  const ring = w ? '#1c1d22' : '#c9ccd6';
  const fg = w ? '#1c1d22' : '#f3f1ea';
  const letter = t === 'N' ? 'N' : t;
  return wrap(
    `<circle cx="50" cy="50" r="39" fill="${bg}" stroke="${ring}" stroke-width="3.5"/>` +
    `<text x="50" y="50" text-anchor="middle" dominant-baseline="central" font-family="Georgia, 'Times New Roman', serif" font-weight="700" font-size="${t === 'P' ? 40 : 46}" fill="${fg}">${letter}</text>`,
  );
}

export function pieceSVG(set, color, type) {
  if (set === 'pixel') return pixelSVG(color, type);
  if (set === 'minimal') return minimalSVG(color, type);
  return vectorSVG(set, color, type);
}

const cache = new Map();
export function pieceURI(set, color, type) {
  const k = set + color + type;
  if (!cache.has(k)) cache.set(k, `url("data:image/svg+xml,${encodeURIComponent(pieceSVG(set, color, type))}")`);
  return cache.get(k);
}

let styleEl = null;
let installed = null;
/** Rewrites the stylesheet that maps `.pc.wK` etc. to the chosen set. */
export function installPieceSet(set = settings.get('pieceSet')) {
  if (installed === set) return;
  if (!PIECE_SETS.some((s) => s.id === set)) set = 'classic';
  if (!styleEl) { styleEl = document.createElement('style'); styleEl.id = 'piece-style'; document.head.append(styleEl); }
  let css = '';
  for (const c of ['w', 'b']) for (const t of TYPES) css += `.${c}${t}{background-image:${pieceURI(set, c, t)}}\n`;
  styleEl.textContent = css;
  installed = set;
  document.documentElement.dataset.pieces = set;
}

export const pieceClass = (color, type) => `${color}${type.toUpperCase()}`;
export function pieceEl(color, type, extra = '') {
  const s = document.createElement('span');
  s.className = `pc ${pieceClass(color, type)} ${extra}`.trim();
  return s;
}

// Static previews (independent of the active set) for the settings screen.
export function previewURI(set, color, type) { return pieceURI(set, color, type); }
