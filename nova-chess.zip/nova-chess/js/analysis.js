// Game review: analyses every position with Stockfish and derives move classifications and accuracy
// from the *measured evaluation change* (win-probability loss), never from random assignment.
import { Chess } from '../vendor/chess.js';
import { scoreToCp, cpToWin } from './engine.js';

export const CLASSES = [
  { id: 'brilliant', name: 'Brilliant', sym: '!!', color: '#26c2b3' },
  { id: 'best', name: 'Best', sym: '★', color: '#6fbf4a' },
  { id: 'excellent', name: 'Excellent', sym: '!', color: '#8fc65b' },
  { id: 'good', name: 'Good', sym: '✓', color: '#7aa6a0' },
  { id: 'inaccuracy', name: 'Inaccuracy', sym: '?!', color: '#f1c04a' },
  { id: 'mistake', name: 'Mistake', sym: '?', color: '#ee9a3f' },
  { id: 'blunder', name: 'Blunder', sym: '??', color: '#e65555' },
];
export const CLASS_BY_ID = Object.fromEntries(CLASSES.map((c) => [c.id, c]));

// Win-probability-loss thresholds (percentage points, mover's perspective).
export const THRESHOLDS = { excellent: 2, good: 5, inaccuracy: 10, mistake: 20 };

const V = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };

/** Static exchange evaluation on one square: net material the side to capture can win. */
function see(target, attackers, defenders) {
  if (!attackers.length) return 0;
  const [a, ...rest] = attackers;
  return Math.max(0, target - see(a, defenders, rest));
}

/** Net material change for the mover after `move` if the opponent exchanges on the destination square. */
export function sacrificeValue(fenBefore, move) {
  const c = new Chess(fenBefore);
  const m = c.move({ from: move.from, to: move.to, promotion: move.promotion });
  if (!m) return 0;
  const me = m.color, opp = me === 'w' ? 'b' : 'w';
  const landed = V[m.promotion ?? m.piece];
  const vals = (color) => c.attackers(m.to, color).map((sq) => V[c.get(sq).type]).sort((a, b) => a - b);
  const lost = see(landed, vals(opp), vals(me));
  const gained = m.captured ? V[m.captured] : 0;
  return gained - lost; // negative = material given up
}

export function moverCp(score, color) {
  const cp = scoreToCp(score);
  return color === 'w' ? cp : -cp;
}

export function classifyMove({ played, best, wpBefore, wpAfter, sacrifice, onlyMove }) {
  const loss = Math.max(0, wpBefore - wpAfter);
  if (onlyMove) return { cls: 'best', loss };
  const isBest = best && played === best;
  if (sacrifice <= -2 && loss <= THRESHOLDS.excellent && wpBefore < 88 && wpAfter > 42) return { cls: 'brilliant', loss };
  if (isBest || loss <= 0.5) return { cls: 'best', loss };
  if (loss < THRESHOLDS.excellent) return { cls: 'excellent', loss };
  if (loss < THRESHOLDS.good) return { cls: 'good', loss };
  if (loss < THRESHOLDS.inaccuracy) return { cls: 'inaccuracy', loss };
  if (loss < THRESHOLDS.mistake) return { cls: 'mistake', loss };
  return { cls: 'blunder', loss };
}

/** Lichess-style per-move accuracy from win% loss. */
export function moveAccuracy(loss) {
  return Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * loss) - 3.1669 + 1));
}
export function gameAccuracy(accs) {
  if (!accs.length) return null;
  const mean = accs.reduce((a, b) => a + b, 0) / accs.length;
  const harm = accs.length / accs.reduce((a, b) => a + 1 / Math.max(b, 1), 0);
  return (mean + harm) / 2;
}

/** Builds fens + verbose moves from a start fen and a move list (uci strings or {from,to,promotion}). */
export function replay(startFen, moves) {
  const c = new Chess(startFen);
  const fens = [startFen];
  const verbose = [];
  for (const m of moves) {
    const mv = typeof m === 'string' ? { from: m.slice(0, 2), to: m.slice(2, 4), promotion: m[4] } : m;
    const r = c.move({ from: mv.from, to: mv.to, promotion: mv.promotion });
    verbose.push(r);
    fens.push(c.fen());
  }
  return { fens, verbose };
}

function terminalEval(fen) {
  const c = new Chess(fen);
  if (c.isCheckmate()) return { score: { mate: 0, winner: c.turn() === 'w' ? 'b' : 'w' }, best: null, lines: [], terminal: true, depth: 0 };
  if (c.isDraw()) return { score: { cp: 0 }, best: null, lines: [], terminal: true, depth: 0 };
  return null;
}

/**
 * Analyse each position. `cache` may contain previously computed evals (index → eval) to skip.
 * Calls onProgress(done, total, evals). Resolves with evals[] (possibly partial if cancelled).
 */
export async function analyzePositions({ fens, engine, depth, movetime, multipv, cache = [], onProgress, isCancelled }) {
  const evals = fens.map((_, i) => cache[i] ?? null);
  for (let i = 0; i < fens.length; i++) {
    if (isCancelled?.()) break;
    if (evals[i]) { onProgress?.(i + 1, fens.length, evals); continue; }
    const t = terminalEval(fens[i]);
    if (t) evals[i] = t;
    else {
      const res = await engine.search({ fen: fens[i], depth, movetime, multipv });
      if (isCancelled?.() || res.stopped) break;
      evals[i] = {
        score: res.top?.score ?? { cp: 0 },
        best: res.best,
        depth: res.depth,
        lines: res.lines.map((l) => ({ score: l.score, pv: l.pv, depth: l.depth, multipv: l.multipv })),
      };
    }
    onProgress?.(i + 1, fens.length, evals);
  }
  return evals;
}

/** Turn evals into per-move classifications + summary. Moves whose neighbours are not analysed yet are skipped. */
export function summarize(fens, verbose, evals) {
  const moves = [];
  const accs = { w: [], b: [] };
  const counts = { w: {}, b: {} };
  const cpl = { w: [], b: [] };
  for (let i = 0; i < verbose.length; i++) {
    const before = evals[i], after = evals[i + 1];
    if (!before || !after) { moves.push(null); continue; }
    const m = verbose[i];
    const color = m.color;
    const played = m.from + m.to + (m.promotion ?? '');
    const cpBefore = moverCp(before.score, color), cpAfter = moverCp(after.score, color);
    const wpBefore = cpToWin(cpBefore), wpAfter = cpToWin(cpAfter);
    const legalCount = new Chess(fens[i]).moves().length;
    const sacrifice = sacrificeValue(fens[i], m);
    const { cls, loss } = classifyMove({ played, best: before.best, wpBefore, wpAfter, sacrifice, onlyMove: legalCount === 1 });
    const acc = moveAccuracy(loss);
    accs[color].push(acc);
    cpl[color].push(Math.max(0, Math.min(1000, cpBefore - cpAfter)));
    counts[color][cls] = (counts[color][cls] ?? 0) + 1;
    moves.push({
      ply: i + 1, color, san: m.san, played, best: before.best, cls, loss, accuracy: acc,
      cpBefore, cpAfter, bestScore: before.score, afterScore: after.score,
      sacrifice: sacrifice <= -2,
    });
  }
  const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  return {
    moves,
    accuracy: { w: gameAccuracy(accs.w), b: gameAccuracy(accs.b) },
    counts,
    acpl: { w: avg(cpl.w), b: avg(cpl.b) },
  };
}

/** Eval series (centipawns from White's view, clamped) for the graph. */
export function graphSeries(evals, clamp = 800) {
  return evals.map((e) => (e ? Math.max(-clamp, Math.min(clamp, scoreToCp(e.score))) : null));
}
