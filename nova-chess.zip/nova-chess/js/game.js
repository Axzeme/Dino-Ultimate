// Game session: rules (via chess.js), move list, takebacks, clocks, results and (de)serialisation.
import { Chess } from '../vendor/chess.js';
import { Emitter } from './util.js';

export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
export const PIECE_VALUE = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

export const TIME_CONTROLS = [
  { id: 'none', name: 'Unlimited', base: null, inc: 0 },
  { id: '1+0', name: '1 min', tag: 'Bullet', base: 60, inc: 0 },
  { id: '3+0', name: '3 min', tag: 'Blitz', base: 180, inc: 0 },
  { id: '3+2', name: '3 | 2', tag: 'Blitz', base: 180, inc: 2 },
  { id: '5+0', name: '5 min', tag: 'Blitz', base: 300, inc: 0 },
  { id: '10+0', name: '10 min', tag: 'Rapid', base: 600, inc: 0 },
  { id: '10+5', name: '10 | 5', tag: 'Rapid', base: 600, inc: 5 },
  { id: '15+10', name: '15 | 10', tag: 'Rapid', base: 900, inc: 10 },
  { id: '30+0', name: '30 min', tag: 'Classical', base: 1800, inc: 0 },
];

export const REASON_TEXT = {
  checkmate: 'by checkmate', resignation: 'by resignation', timeout: 'on time', stalemate: 'by stalemate',
  insufficient: 'by insufficient material', repetition: 'by threefold repetition', fifty: 'by the fifty-move rule',
  agreement: 'by agreement', abandoned: 'abandoned',
};

export const uciOf = (m) => m.from + m.to + (m.promotion ?? '');

/** Can `color` still deliver mate in some legal sequence? (used for timeouts) */
export function hasMatingMaterial(chess, color) {
  let minors = 0, other = 0;
  for (const row of chess.board()) for (const p of row) {
    if (!p || p.color !== color) continue;
    if (p.type === 'n' || p.type === 'b') minors++;
    else if (p.type !== 'k') other++;
  }
  if (other > 0) return true;
  if (minors >= 2) return true; // KNN/KBB etc. can mate with cooperation
  return false;
}

export function materialOf(map) {
  const m = { w: 0, b: 0 };
  for (const code of Object.values(map)) m[code[0]] += PIECE_VALUE[code[1].toLowerCase()];
  return m;
}

export class GameSession extends Emitter {
  /**
   * cfg: { mode:'engine'|'local'|'practice'|'analysis'|'puzzle', playerColor:'w'|'b'|null,
   *        timeControl:{base,inc}|null, startFen?, white:{name,rating?}, black:{name,rating?},
   *        autoClaimDraws?:boolean, engineLevel?:{...} }
   */
  constructor(cfg) {
    super();
    this.cfg = cfg;
    this.startFen = cfg.startFen || START_FEN;
    this.chess = new Chess(this.startFen);
    this.moves = [];
    this.redoStack = [];
    this.result = null;
    this.startedAt = Date.now();
    this.elapsedBefore = 0;
    this.undoUsed = false;
    const base = cfg.timeControl?.base;
    this.timed = base != null;
    this.inc = (cfg.timeControl?.inc ?? 0) * 1000;
    this.clocks = { w: this.timed ? base * 1000 : null, b: this.timed ? base * 1000 : null };
    this.snapshots = [{ ...this.clocks }];
    this.lastTick = null; // performance.now() while a clock is running
    this.final = cfg.mode === 'engine' || cfg.mode === 'local';
  }

  get turn() { return this.chess.turn(); }
  get fen() { return this.chess.fen(); }
  get ply() { return this.moves.length; }
  get over() { return !!this.result; }
  get startTurn() { return this.startFen.split(' ')[1] ?? 'w'; }
  get startMoveNumber() { return Number(this.startFen.split(' ')[5] ?? 1) || 1; }
  fenAt(ply) { return ply <= 0 ? this.startFen : this.moves[ply - 1].after; }

  isCheck() { return this.chess.isCheck(); }
  kingSquare(color) {
    for (const row of this.chess.board()) for (const p of row) if (p && p.type === 'k' && p.color === color) return p.square;
    return null;
  }
  checkSquare() { return this.chess.isCheck() ? this.kingSquare(this.turn) : null; }

  legalTargets(sq) {
    const seen = new Map();
    for (const m of this.chess.moves({ square: sq, verbose: true })) {
      if (!seen.has(m.to)) seen.set(m.to, { to: m.to, capture: !!m.captured, promo: !!m.promotion });
    }
    return [...seen.values()];
  }
  isPromotion(from, to) {
    const p = this.chess.get(from);
    if (!p || p.type !== 'p') return false;
    return (p.color === 'w' && to[1] === '8') || (p.color === 'b' && to[1] === '1');
  }

  // ------------------------------------------------------------ clocks ---
  remaining(color) {
    if (!this.timed) return null;
    let v = this.clocks[color];
    if (this.lastTick != null && this.turn === color && !this.result) v -= performance.now() - this.lastTick;
    return Math.max(0, v);
  }
  get clockRunning() { return this.lastTick != null; }
  pauseClock() {
    if (this.lastTick != null && this.timed) {
      const c = this.turn;
      this.clocks[c] = Math.max(0, this.clocks[c] - (performance.now() - this.lastTick));
    }
    this.lastTick = null;
  }
  resumeClock() {
    if (this.timed && !this.result && this.moves.length >= 1 && this.lastTick == null) this.lastTick = performance.now();
  }
  /** Call regularly; flags the player whose time has run out. Returns true if the game ended. */
  checkFlag() {
    if (!this.timed || this.result || this.lastTick == null) return false;
    const c = this.turn;
    if (this.remaining(c) <= 0) { this.flag(c); return true; }
    return false;
  }
  flag(color) {
    this.pauseClock();
    this.clocks[color] = 0;
    const winner = color === 'w' ? 'b' : 'w';
    if (!hasMatingMaterial(this.chess, winner)) this.finish('1/2-1/2', 'insufficient', null);
    else this.finish(winner === 'w' ? '1-0' : '0-1', 'timeout', winner);
  }
  elapsedMs() { return this.elapsedBefore + (Date.now() - this.startedAt); }

  // -------------------------------------------------------------- moves ---
  /** Returns the verbose move or null if illegal. Does not ask about promotion – pass it in. */
  move({ from, to, promotion }, { silent = false } = {}) {
    if (this.result) return null;
    let m;
    try { m = this.chess.move({ from, to, promotion }); } catch { return null; }
    if (!m) return null;
    const mover = m.color;
    if (this.timed) {
      if (this.moves.length >= 1 && this.lastTick != null) {
        this.clocks[mover] = Math.max(0, this.clocks[mover] - (performance.now() - this.lastTick)) + this.inc;
      }
      this.lastTick = performance.now();
    }
    this.moves.push(m);
    this.redoStack = [];
    this.snapshots.length = this.moves.length;
    this.snapshots.push({ ...this.clocks });
    this.checkEnd(m);
    if (!silent) this.emit('move', m);
    return m;
  }

  checkEnd(m) {
    const c = this.chess;
    if (c.isCheckmate()) return this.finish(m.color === 'w' ? '1-0' : '0-1', 'checkmate', m.color);
    if (c.isStalemate()) return this.finish('1/2-1/2', 'stalemate', null);
    if (c.isInsufficientMaterial()) return this.finish('1/2-1/2', 'insufficient', null);
    if (this.cfg.autoClaimDraws !== false) {
      if (c.isThreefoldRepetition()) return this.finish('1/2-1/2', 'repetition', null);
      if (c.isDrawByFiftyMoves()) return this.finish('1/2-1/2', 'fifty', null);
    }
    return null;
  }

  /** 'repetition' | 'fifty' | null – draws a player could claim when auto-claim is off. */
  claimable() {
    if (this.result) return null;
    if (this.chess.isThreefoldRepetition()) return 'repetition';
    if (this.chess.isDrawByFiftyMoves()) return 'fifty';
    return null;
  }
  claimDraw() {
    const r = this.claimable();
    if (r) this.finish('1/2-1/2', r, null);
    return !!r;
  }

  finish(result, reason, winner) {
    if (this.result) return;
    this.pauseClock();
    this.result = { result, reason, winner };
    this.endedAt = Date.now();
    this.emit('result', this.result);
  }
  resign(color) { this.finish(color === 'w' ? '0-1' : '1-0', 'resignation', color === 'w' ? 'b' : 'w'); }
  agreeDraw() { this.finish('1/2-1/2', 'agreement', null); }

  canUndo(plies = 1) { return this.moves.length >= plies && (!this.result || !this.final); }
  undo(plies = 1) {
    if (!this.canUndo(plies)) return false;
    this.pauseClock();
    for (let i = 0; i < plies; i++) {
      this.chess.undo();
      this.redoStack.push(this.moves.pop());
    }
    this.undoUsed = true;
    this.result = null; // natural endings are re-derived when the position is reached again
    this.snapshots.length = this.moves.length + 1;
    this.clocks = { ...this.snapshots[this.moves.length] };
    this.emit('undo', plies);
    return true;
  }
  canRedo(plies = 1) { return this.redoStack.length >= plies && (!this.result || !this.final); }
  redo(plies = 1) {
    if (!this.canRedo(plies)) return false;
    let last = null;
    for (let i = 0; i < plies; i++) {
      const m = this.redoStack.pop();
      const real = this.chess.move({ from: m.from, to: m.to, promotion: m.promotion });
      this.moves.push(real);
      last = real;
      this.snapshots.push({ ...this.clocks });
    }
    if (this.timed) this.clocks = { ...this.snapshots[this.moves.length] };
    this.checkEnd(last);
    this.emit('redo', plies, last);
    return true;
  }

  /** Load a position / move list into a (practice / analysis) session. */
  loadFen(fen) {
    const test = new Chess(); test.load(fen); // throws on invalid
    this.startFen = fen;
    this.chess = new Chess(fen);
    this.moves = []; this.redoStack = []; this.result = null;
    this.snapshots = [{ ...this.clocks }];
    this.emit('reset');
  }

  // ------------------------------------------------------ persistence ---
  pgnHeaders(extra = {}) {
    const cfg = this.cfg;
    const d = new Date(this.startedAt);
    const pad = (n) => String(n).padStart(2, '0');
    const h = {
      Event: cfg.event ?? (cfg.mode === 'engine' ? 'Nova Chess – vs Stockfish' : cfg.mode === 'local' ? 'Nova Chess – local game' : 'Nova Chess – analysis'),
      Site: 'Nova Chess',
      Date: `${d.getFullYear()}.${pad(d.getMonth() + 1)}.${pad(d.getDate())}`,
      Round: '-',
      White: cfg.white?.name ?? 'White',
      Black: cfg.black?.name ?? 'Black',
      Result: this.result?.result ?? '*',
    };
    if (cfg.white?.rating) h.WhiteElo = String(cfg.white.rating);
    if (cfg.black?.rating) h.BlackElo = String(cfg.black.rating);
    if (cfg.timeControl?.base != null) h.TimeControl = `${cfg.timeControl.base}${cfg.timeControl.inc ? `+${cfg.timeControl.inc}` : ''}`;
    else h.TimeControl = '-';
    if (this.startFen !== START_FEN) { h.SetUp = '1'; h.FEN = this.startFen; }
    if (this.result) h.Termination = { checkmate: 'Normal', resignation: 'Normal', agreement: 'Normal', stalemate: 'Normal', insufficient: 'Normal', repetition: 'Normal', fifty: 'Normal', timeout: 'Time forfeit' }[this.result.reason] ?? 'Normal';
    return { ...h, ...extra };
  }

  pgn(extra = {}) {
    const c = new Chess(this.startFen);
    for (const m of this.moves) c.move({ from: m.from, to: m.to, promotion: m.promotion });
    for (const [k, v] of Object.entries(this.pgnHeaders(extra))) c.setHeader(k, String(v));
    return c.pgn({ maxWidth: 90, newline: '\n' });
  }

  serialize() {
    return {
      v: 1,
      cfg: this.cfg,
      startFen: this.startFen,
      uci: this.moves.map(uciOf),
      redo: this.redoStack.map(uciOf),
      clocks: this.clocks,
      snapshots: this.snapshots,
      result: this.result,
      elapsed: this.elapsedMs(),
      undoUsed: this.undoUsed,
      savedAt: Date.now(),
    };
  }

  static restore(data) {
    const s = new GameSession({ ...data.cfg, startFen: data.startFen });
    for (const u of data.uci) {
      const m = s.chess.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
      s.moves.push(m);
    }
    s.redoStack = [];
    for (const u of data.redo ?? []) {
      // redo stack is stored so that the next redo is the LAST element
      s.redoStack.push({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
    }
    s.clocks = data.clocks ?? s.clocks;
    s.snapshots = data.snapshots ?? [{ ...s.clocks }];
    s.result = data.result ?? null;
    s.elapsedBefore = data.elapsed ?? 0;
    s.startedAt = Date.now();
    s.undoUsed = !!data.undoUsed;
    return s;
  }
}

/** Material captured by each side up to `ply`, from the move list. */
export function capturedUpTo(moves, ply) {
  const out = { w: [], b: [] }; // out.w = pieces White has captured (black pieces)
  for (let i = 0; i < ply && i < moves.length; i++) {
    const m = moves[i];
    if (m.captured) out[m.color].push(m.captured);
  }
  const order = { q: 0, r: 1, b: 2, n: 3, p: 4 };
  out.w.sort((a, b) => order[a] - order[b]);
  out.b.sort((a, b) => order[a] - order[b]);
  return out;
}
