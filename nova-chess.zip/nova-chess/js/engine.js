// Stockfish 19 (WebAssembly) running in a Web Worker, spoken to over UCI.
// The npm build "stockfish-19-lite-single" needs no special HTTP headers; "asm" is a last-resort fallback.
import { Emitter } from './util.js';

const ENGINE_URLS = [
  { id: 'wasm', label: 'Stockfish 19 Lite (WASM)', url: new URL('../vendor/stockfish-19-lite-single.js', import.meta.url).href },
  { id: 'asm', label: 'Stockfish 19 (asm.js fallback)', url: new URL('../vendor/stockfish-19-asm.js', import.meta.url).href },
];

// Strength presets. `elo` is a nominal rating used for the local rating calculation only.
export const LEVELS = [
  { id: 'beginner', name: 'Beginner', elo: 600, skill: 0, limit: false, uciElo: 1320, depth: 1, movetime: 80, delay: 500, desc: 'Plays quickly and blunders a lot' },
  { id: 'easy', name: 'Easy', elo: 1000, skill: 3, limit: false, uciElo: 1320, depth: 3, movetime: 150, delay: 400, desc: 'Sees one or two moves ahead' },
  { id: 'intermediate', name: 'Intermediate', elo: 1500, skill: 8, limit: true, uciElo: 1500, depth: 8, movetime: 400, delay: 250, desc: 'Solid club-level opponent' },
  { id: 'advanced', name: 'Advanced', elo: 1900, skill: 12, limit: true, uciElo: 1900, depth: 12, movetime: 700, delay: 150, desc: 'Punishes most mistakes' },
  { id: 'expert', name: 'Expert', elo: 2300, skill: 16, limit: true, uciElo: 2300, depth: 16, movetime: 1000, delay: 0, desc: 'Master-strength tactics' },
  { id: 'master', name: 'Master', elo: 2800, skill: 19, limit: true, uciElo: 2800, depth: 20, movetime: 1500, delay: 0, desc: 'Super-grandmaster strength' },
  { id: 'max', name: 'Maximum', elo: 3300, skill: 20, limit: false, uciElo: 3190, depth: 40, movetime: 2500, delay: 0, desc: 'Full strength, no handicap' },
];

/** Resolve the effective engine parameters from saved settings (preset or custom). */
export function resolveLevel(s) {
  if (s.engineLevel !== 'custom') {
    const l = LEVELS.find((x) => x.id === s.engineLevel) ?? LEVELS[2];
    return { ...l, custom: false };
  }
  const elo = s.engineLimit ? Math.round(s.engineElo) : Math.round(800 + s.engineSkill * 125);
  return {
    id: 'custom', name: 'Custom', skill: s.engineSkill, limit: s.engineLimit, uciElo: s.engineElo,
    depth: s.engineDepth, movetime: s.engineMoveTime, delay: 0, elo, custom: true,
    desc: s.engineLimit ? `Elo-limited to ${s.engineElo}` : `Skill level ${s.engineSkill}`,
  };
}

// ------------------------------------------------------------- scoring ----
export const MATE_CP = 10000;
export function scoreToCp(sc) {
  if (!sc) return 0;
  if (sc.mate === 0) return (sc.winner === 'w' ? 1 : -1) * MATE_CP; // checkmate on the board
  if (sc.mate != null) return (sc.mate > 0 ? 1 : -1) * (MATE_CP - Math.min(Math.abs(sc.mate), 99) * 10);
  return sc.cp ?? 0;
}
/** Win probability (0-100) for the side the score is expressed for. */
export function cpToWin(cp) { return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1); }
export function fmtScore(sc, { signed = true } = {}) {
  if (!sc) return '–';
  if (sc.mate === 0) return sc.winner === 'w' ? '1-0' : '0-1';
  if (sc.mate != null) return `${sc.mate < 0 ? '-' : ''}#${Math.abs(sc.mate)}`;
  const v = (sc.cp ?? 0) / 100;
  if (Math.abs(v) < 0.005) return '0.00';
  return `${signed && v > 0 ? '+' : ''}${v.toFixed(2)}`;
}
/** Share of the bar (0-100) that belongs to White. */
export function barPercent(sc) {
  if (!sc) return 50;
  if (sc.mate === 0) return sc.winner === 'w' ? 100 : 0;
  if (sc.mate != null) return sc.mate > 0 ? 100 : 0;
  return Math.max(3, Math.min(97, cpToWin(sc.cp ?? 0)));
}

export const uciToMove = (u) => ({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });

function parseInfo(line, whiteToMove) {
  const t = line.split(' ');
  const info = { multipv: 1 };
  for (let i = 1; i < t.length; i++) {
    switch (t[i]) {
      case 'depth': info.depth = +t[++i]; break;
      case 'seldepth': info.seldepth = +t[++i]; break;
      case 'multipv': info.multipv = +t[++i]; break;
      case 'nodes': info.nodes = +t[++i]; break;
      case 'nps': info.nps = +t[++i]; break;
      case 'time': info.time = +t[++i]; break;
      case 'hashfull': info.hashfull = +t[++i]; break;
      case 'score': {
        const kind = t[++i]; const v = +t[++i];
        const sign = whiteToMove ? 1 : -1; // convert to White's perspective
        info.score = kind === 'mate' ? { mate: v * sign } : { cp: v * sign };
        if (t[i + 1] === 'lowerbound' || t[i + 1] === 'upperbound') { info.bound = t[++i]; }
        break;
      }
      case 'pv': info.pv = t.slice(i + 1); i = t.length; break;
      default: break;
    }
  }
  return info;
}

export class Engine extends Emitter {
  constructor(name = 'engine') {
    super();
    this.name = name;
    this.status = 'idle'; // idle | loading | ready | busy | error
    this.worker = null;
    this.variant = null;
    this.options = {};
    this.current = null;
    this.token = 0;
    this.listeners = new Set();
    this.initPromise = null;
    this.restarts = 0;
    this.label = '';
  }

  setStatus(s, detail = '') {
    this.status = s;
    this.emit('status', s, detail);
  }

  /** Starts the worker (idempotent). Rejects only if every engine variant failed. */
  init() {
    if (this.initPromise) return this.initPromise;
    this.initPromise = (async () => {
      this.setStatus('loading');
      let lastErr = null;
      for (const v of ENGINE_URLS) {
        try {
          await this.boot(v);
          this.variant = v.id; this.label = v.label;
          this.setStatus('ready');
          return true;
        } catch (e) {
          lastErr = e;
          console.warn(`[engine:${this.name}] ${v.id} failed:`, e);
          this.killWorker();
        }
      }
      this.setStatus('error', String(lastErr?.message ?? lastErr));
      this.initPromise = null;
      throw lastErr ?? new Error('Engine failed to start');
    })();
    return this.initPromise;
  }

  boot(v) {
    return new Promise((resolve, reject) => {
      let worker;
      try { worker = new Worker(v.url); } catch (e) { return reject(e); }
      this.worker = worker;
      const timeout = setTimeout(() => reject(new Error(`Timed out starting ${v.id}`)), v.id === 'asm' ? 40000 : 20000);
      let stage = 'uci';
      worker.onerror = (e) => { clearTimeout(timeout); reject(new Error(e.message || 'Worker error')); this.onWorkerError(e); };
      worker.onmessageerror = () => reject(new Error('Worker message error'));
      worker.onmessage = (e) => {
        const line = typeof e.data === 'string' ? e.data : String(e.data?.data ?? e.data ?? '');
        if (stage === 'uci' && line.startsWith('uciok')) { stage = 'ready'; this.options = {}; worker.postMessage('isready'); return; }
        if (stage === 'ready' && line.startsWith('readyok')) {
          stage = 'done'; clearTimeout(timeout);
          worker.onmessage = (ev) => this.onLine(typeof ev.data === 'string' ? ev.data : String(ev.data?.data ?? ev.data ?? ''));
          resolve();
        }
      };
      worker.postMessage('uci');
    });
  }

  killWorker() {
    try { this.worker?.terminate(); } catch { /* ignore */ }
    this.worker = null;
  }

  onWorkerError(e) {
    console.error(`[engine:${this.name}] worker error`, e?.message ?? e);
    if (this.status === 'loading') return; // handled by boot()
    const cur = this.current;
    this.killWorker();
    this.initPromise = null;
    this.current = null;
    this.setStatus('error', e?.message ?? 'Engine crashed');
    cur?.reject(new Error('Engine crashed'));
    this.emit('crash');
  }

  /** Ensure a live worker, restarting after a crash (max a few times). */
  async ensure() {
    if (this.worker && this.status !== 'error') return;
    if (this.restarts > 4) throw new Error('Engine keeps crashing');
    if (this.status === 'error') this.restarts++;
    this.initPromise = null;
    await this.init();
  }

  send(cmd) { this.worker?.postMessage(cmd); }

  async setOptions(opts) {
    await this.ensure();
    for (const [k, v] of Object.entries(opts)) {
      if (this.options[k] === v) continue;
      this.send(`setoption name ${k} value ${v}`);
      this.options[k] = v;
    }
  }

  newGame() {
    if (!this.worker) return;
    this.send('ucinewgame');
  }

  onLine(line) {
    if (!line) return;
    const cur = this.current;
    if (line.startsWith('info ') && cur) {
      if (!line.includes(' score ') || !line.includes(' pv ')) return;
      const info = parseInfo(line, cur.whiteToMove);
      if (info.bound) return; // ignore aspiration-window bounds
      cur.lines.set(info.multipv, info);
      cur.depth = Math.max(cur.depth, info.depth ?? 0);
      cur.onInfo?.(info, [...cur.lines.values()].sort((a, b) => a.multipv - b.multipv));
    } else if (line.startsWith('bestmove') && cur) {
      const [, best, , ponder] = line.split(' ');
      this.current = null;
      clearTimeout(cur.watchdog);
      if (this.status === 'busy') this.setStatus('ready');
      const lines = [...cur.lines.values()].sort((a, b) => a.multipv - b.multipv);
      cur.resolve({ best: best === '(none)' ? null : best, ponder, lines, top: lines[0] ?? null, depth: cur.depth, stopped: cur.stopped });
    }
  }

  /**
   * Run a search. Supersedes any search in progress (which resolves with `stopped: true`).
   * params: { fen, moves?:[uci], depth?, movetime?, multipv?, onInfo?, searchmoves? }
   */
  async search(params) {
    const my = ++this.token;
    await this.ensure();
    if (this.current) {
      this.current.stopped = true;
      this.send('stop');
      await this.current.done.catch(() => {});
    }
    if (my !== this.token) return { best: null, lines: [], top: null, depth: 0, stopped: true, superseded: true };
    await this.setOptions({ MultiPV: params.multipv ?? 1 });
    const fen = params.fen;
    // Scores come back from the side-to-move's view; work out who that is after the optional move list.
    const startWhite = (fen.split(' ')[1] ?? 'w') === 'w';
    const whiteToMove = startWhite === ((params.moves?.length ?? 0) % 2 === 0);
    const cur = { lines: new Map(), depth: 0, onInfo: params.onInfo, whiteToMove, stopped: false };
    cur.done = new Promise((resolve, reject) => { cur.resolve = resolve; cur.reject = reject; });
    cur.done.catch(() => {});
    this.current = cur;
    this.setStatus('busy');
    this.send(`position fen ${fen}${params.moves?.length ? ` moves ${params.moves.join(' ')}` : ''}`);
    const limits = [];
    if (params.depth) limits.push(`depth ${params.depth}`);
    if (params.movetime) limits.push(`movetime ${Math.round(params.movetime)}`);
    if (params.searchmoves?.length) limits.push(`searchmoves ${params.searchmoves.join(' ')}`);
    this.send(`go ${limits.join(' ') || 'depth 12'}`);
    // watchdog: if the engine never answers, restart it instead of hanging the UI
    cur.watchdog = setTimeout(() => {
      if (this.current === cur) { console.warn(`[engine:${this.name}] watchdog fired`); this.onWorkerError({ message: 'Engine stopped responding' }); }
    }, (params.movetime ?? 4000) + 20000);
    return cur.done;
  }

  /** Abort the current search (it resolves with `stopped: true`). */
  stop() {
    this.token++;
    if (this.current) { this.current.stopped = true; this.send('stop'); }
  }

  terminate() {
    this.token++;
    const cur = this.current; this.current = null;
    cur && clearTimeout(cur.watchdog);
    cur?.resolve({ best: null, lines: [], top: null, depth: 0, stopped: true });
    this.killWorker();
    this.initPromise = null;
    this.setStatus('idle');
  }

  /** Apply a resolved level to this engine's UCI options. */
  async applyStrength(level, { hash = 32, threads = 1 } = {}) {
    await this.setOptions({
      'Skill Level': level.limit ? 20 : level.skill,
      UCI_LimitStrength: !!level.limit,
      UCI_Elo: Math.max(1320, Math.min(3190, Math.round(level.uciElo ?? 1500))),
      Hash: hash,
      Threads: threads,
    });
  }
}

// Shared engine instances: one for playing, one for evaluation / review.
export const engines = {
  play: new Engine('play'),
  analysis: new Engine('analysis'),
};
