// Per-user statistics and the *estimated local rating*.
// The rating is a simple Elo update against the engine level's nominal strength. It is NOT a FIDE,
// Chess.com or Lichess rating and the UI always labels it as an estimate.
import { ls } from './store.js';

const key = (userId) => `nova.stats.v1.${userId}`;

export const START_RATING = 1200;

export function blankStats() {
  return {
    played: 0, wins: 0, losses: 0, draws: 0,
    byMode: { engine: 0, local: 0, other: 0 },
    rating: START_RATING, peak: START_RATING, ratedGames: 0, ratingHistory: [],
    streak: 0, bestStreak: 0,
    bestWin: null,      // { elo, level, date } – strongest engine level beaten
    fastestWin: null,   // { plies, date }
    longestGame: null,  // { plies, date }
    bestAccuracy: null, // { value, date }
    updatedAt: null,
  };
}

export function loadStats(userId) {
  const s = ls.get(key(userId), null);
  return { ...blankStats(), ...(s ?? {}), byMode: { ...blankStats().byMode, ...(s?.byMode ?? {}) } };
}
export function saveStats(userId, stats) { stats.updatedAt = new Date().toISOString(); ls.set(key(userId), stats); }
export function resetStats(userId) { ls.del(key(userId)); }

export function expectedScore(r, opp) { return 1 / (1 + Math.pow(10, (opp - r) / 400)); }

/**
 * Records a finished game. `rec` is the history record (mode, playerColor, result, plies, levelElo, rated…).
 * Returns { rated, delta, rating } so the UI can show it.
 */
export function recordFinished(user, rec) {
  const stats = loadStats(user.id);
  let outcome; // 1 win, .5 draw, 0 loss, null for two-player games (no "me")
  if (rec.playerColor === 'w' || rec.playerColor === 'b') {
    if (rec.result === '1/2-1/2') outcome = 0.5;
    else outcome = (rec.result === '1-0') === (rec.playerColor === 'w') ? 1 : 0;
  } else outcome = null;

  stats.played++;
  stats.byMode[rec.mode === 'engine' || rec.mode === 'local' ? rec.mode : 'other']++;
  if (outcome === 1) stats.wins++; else if (outcome === 0) stats.losses++; else if (outcome === 0.5) stats.draws++;
  else { // local two-player game: count the result without attributing it to "me"
    if (rec.result === '1/2-1/2') stats.draws++;
    else stats.wins += 0; // nothing: neither side is "the user"
  }

  if (outcome === 1) { stats.streak = Math.max(0, stats.streak) + 1; stats.bestStreak = Math.max(stats.bestStreak, stats.streak); }
  else if (outcome === 0) stats.streak = 0;

  let delta = 0;
  const rated = !!rec.rated && rec.mode === 'engine' && outcome != null;
  if (rated) {
    const k = stats.ratedGames < 10 ? 40 : 24;
    const exp = expectedScore(stats.rating, rec.levelElo ?? 1500);
    delta = Math.round(k * (outcome - exp));
    stats.rating = Math.max(100, stats.rating + delta);
    stats.peak = Math.max(stats.peak, stats.rating);
    stats.ratedGames++;
    stats.ratingHistory.push({ t: Date.now(), r: stats.rating });
    if (stats.ratingHistory.length > 60) stats.ratingHistory.shift();
  }
  if (outcome === 1 && rec.mode === 'engine' && (!stats.bestWin || (rec.levelElo ?? 0) > stats.bestWin.elo)) {
    stats.bestWin = { elo: rec.levelElo ?? 0, level: rec.levelName ?? '', date: rec.date };
  }
  if (outcome === 1 && rec.plies > 0 && (!stats.fastestWin || rec.plies < stats.fastestWin.plies)) {
    stats.fastestWin = { plies: rec.plies, date: rec.date };
  }
  if (!stats.longestGame || rec.plies > stats.longestGame.plies) stats.longestGame = { plies: rec.plies, date: rec.date };
  saveStats(user.id, stats);
  rec.ratingDelta = rated ? delta : null;
  return { rated, delta, rating: stats.rating, outcome };
}

export function recordAccuracy(userId, value, date) {
  const s = loadStats(userId);
  if (value != null && (!s.bestAccuracy || value > s.bestAccuracy.value)) { s.bestAccuracy = { value, date }; saveStats(userId, s); }
}

export const winRate = (s) => {
  const decided = s.wins + s.losses + s.draws;
  return decided ? Math.round((s.wins / decided) * 100) : null;
};

/** Favourite mode computed from counters. */
export function favoriteMode(s) {
  const e = Object.entries(s.byMode).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1])[0];
  return e ? ({ engine: 'vs Stockfish', local: 'Local 2-player', other: 'Other' }[e[0]] ?? e[0]) : null;
}
