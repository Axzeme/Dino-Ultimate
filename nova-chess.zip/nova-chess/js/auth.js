// LOCAL DEMO AUTHENTICATION.
// Accounts live only in this browser's IndexedDB. There is no server, so this is NOT real account
// security: anyone with access to this browser profile can read or delete the stored data.
// What it does do correctly: passwords are never stored in plaintext. They are salted and hashed with
// PBKDF2-HMAC-SHA256 (WebCrypto, 210,000 iterations). If WebCrypto is unavailable (plain-http pages),
// a slower pure-JS PBKDF2 with fewer iterations is used and the record says so.
import { db, ls, settings } from './store.js';
import { AVATARS } from './util.js';

const SESSION_KEY = 'nova.session.v1';
const subtle = globalThis.crypto?.subtle ?? null;

const enc = new TextEncoder();
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const randomBytes = (n) => crypto.getRandomValues(new Uint8Array(n));

// ---------------------------------------------------------------- hashing --
async function pbkdf2(password, salt, iterations, algo) {
  if (algo === 'pbkdf2-sha256-webcrypto' && subtle) {
    const key = await subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
    return new Uint8Array(await subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
  }
  return pbkdf2JS(enc.encode(password), salt, iterations);
}

export async function hashSecret(secret) {
  const salt = randomBytes(16);
  const useWeb = !!subtle;
  const algo = useWeb ? 'pbkdf2-sha256-webcrypto' : 'pbkdf2-sha256-js';
  const iterations = useWeb ? 210000 : 15000;
  const hash = await pbkdf2(secret, salt, iterations, algo);
  return { algo, iterations, salt: b64(salt), hash: b64(hash) };
}

export async function verifySecret(secret, rec) {
  if (!rec) return false;
  const algo = rec.algo === 'pbkdf2-sha256-webcrypto' && !subtle ? 'pbkdf2-sha256-js' : rec.algo;
  // A webcrypto-created hash cannot be re-derived without webcrypto at the same cost, but the JS
  // fallback computes the same PBKDF2 function, so it still verifies (just slowly).
  const hash = await pbkdf2(secret, unb64(rec.salt), rec.iterations, algo);
  const want = unb64(rec.hash);
  if (hash.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < hash.length; i++) diff |= hash[i] ^ want[i];
  return diff === 0;
}

// Minimal SHA-256 / HMAC / PBKDF2 (fallback only).
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
function sha256(data) {
  const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const len = data.length;
  const padded = new Uint8Array(((len + 9 + 63) >> 6) << 6);
  padded.set(data); padded[len] = 0x80;
  const dv = new DataView(padded.buffer);
  dv.setUint32(padded.length - 8, Math.floor((len * 8) / 4294967296)); dv.setUint32(padded.length - 4, (len * 8) >>> 0);
  const w = new Uint32Array(64);
  for (let off = 0; off < padded.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
    for (let i = 16; i < 64; i++) {
      const a = w[i - 15], b = w[i - 2];
      const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
      const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const t1 = (hh + S1 + ch + K[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += hh;
  }
  const out = new Uint8Array(32);
  const odv = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) odv.setUint32(i * 4, H[i]);
  return out;
}
function hmac(key, msg) {
  if (key.length > 64) key = sha256(key);
  const k = new Uint8Array(64); k.set(key);
  const ipad = k.map((x) => x ^ 0x36), opad = k.map((x) => x ^ 0x5c);
  const inner = new Uint8Array(64 + msg.length); inner.set(ipad); inner.set(msg, 64);
  const outer = new Uint8Array(96); outer.set(opad); outer.set(sha256(inner), 64);
  return sha256(outer);
}
function pbkdf2JS(pw, salt, iterations) {
  const s = new Uint8Array(salt.length + 4); s.set(salt); s[salt.length + 3] = 1;
  let u = hmac(pw, s);
  const t = new Uint8Array(u);
  for (let i = 1; i < iterations; i++) {
    u = hmac(pw, u);
    for (let j = 0; j < 32; j++) t[j] ^= u[j];
  }
  return t;
}

// ----------------------------------------------------------------- users ---
export const GUEST = { id: 'guest', key: 'guest', name: 'Guest', avatar: 0, isGuest: true, rating: 1200 };

const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;
export function validateUsername(u) {
  if (!USERNAME_RE.test(u ?? '')) return 'Use 3–20 letters, numbers or underscores.';
  return '';
}
export function passwordStrength(pw) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return Math.min(4, s);
}
export function validatePassword(pw) {
  if ((pw ?? '').length < 8) return 'Password must be at least 8 characters.';
  return '';
}

function publicUser(rec) {
  return { id: rec.key, key: rec.key, name: rec.name, avatar: rec.avatar ?? 0, isGuest: false, rating: rec.rating ?? 1200, createdAt: rec.createdAt };
}

function newRecoveryCode() {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(16);
  let s = '';
  for (let i = 0; i < 16; i++) s += alphabet[bytes[i] % alphabet.length];
  return s.replace(/(.{4})(?=.)/g, '$1-');
}
const normCode = (c) => String(c ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');

export async function register(username, password, confirm) {
  const e = validateUsername(username);
  if (e) throw new Error(e);
  const pe = validatePassword(password);
  if (pe) throw new Error(pe);
  if (password !== confirm) throw new Error('Passwords do not match.');
  const key = username.toLowerCase();
  if (key === 'guest') throw new Error('That username is reserved.');
  if (await db.getUser(key)) throw new Error('That username is already taken on this device.');
  const code = newRecoveryCode();
  const rec = {
    key, name: username, avatar: Math.floor(Math.random() * AVATARS.length), createdAt: new Date().toISOString(),
    rating: 1200, pw: await hashSecret(password), recovery: await hashSecret(normCode(code)),
  };
  await db.putUser(rec);
  return { user: publicUser(rec), recoveryCode: code };
}

export async function login(username, password, remember) {
  const key = (username ?? '').trim().toLowerCase();
  const rec = key ? await db.getUser(key) : null;
  // Always do the same work whether or not the user exists, to keep timing uniform.
  const ok = rec ? await verifySecret(password, rec.pw) : (await hashSecret('x'), false);
  if (!ok) throw new Error('Incorrect username or password.');
  saveSession(rec.key, remember);
  return publicUser(rec);
}

export async function recoverPassword(username, code, newPassword, confirm) {
  const pe = validatePassword(newPassword);
  if (pe) throw new Error(pe);
  if (newPassword !== confirm) throw new Error('Passwords do not match.');
  const rec = await db.getUser((username ?? '').trim().toLowerCase());
  const ok = rec ? await verifySecret(normCode(code), rec.recovery) : false;
  if (!ok) throw new Error('Username or recovery code is incorrect.');
  rec.pw = await hashSecret(newPassword);
  const newCode = newRecoveryCode();
  rec.recovery = await hashSecret(normCode(newCode));
  await db.putUser(rec);
  return newCode; // recovery codes are single-use; a fresh one is issued
}

export async function changePassword(userId, current, next, confirm) {
  const rec = await db.getUser(userId);
  if (!rec || !(await verifySecret(current, rec.pw))) throw new Error('Current password is incorrect.');
  const pe = validatePassword(next);
  if (pe) throw new Error(pe);
  if (next !== confirm) throw new Error('New passwords do not match.');
  rec.pw = await hashSecret(next);
  await db.putUser(rec);
}

export async function updateUser(userId, patch) {
  const rec = await db.getUser(userId);
  if (!rec) return null;
  Object.assign(rec, patch);
  await db.putUser(rec);
  return publicUser(rec);
}

export async function getUser(userId) {
  const rec = await db.getUser(userId);
  return rec ? publicUser(rec) : null;
}

// --------------------------------------------------------------- session ---
function saveSession(key, remember) {
  clearSession();
  if (remember) ls.set(SESSION_KEY, { key, remember: true });
  else { try { sessionStorage.setItem(SESSION_KEY, JSON.stringify({ key })); } catch { /* ignore */ } }
}
export function clearSession() {
  ls.del(SESSION_KEY);
  try { sessionStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
}
export function startGuestSession() {
  saveSession('guest', false);
  return { ...GUEST };
}
export async function restoreSession() {
  let s = null;
  try { s = JSON.parse(sessionStorage.getItem(SESSION_KEY) ?? 'null'); } catch { /* ignore */ }
  s ??= ls.get(SESSION_KEY, null);
  if (!s?.key) return null;
  if (s.key === 'guest') return { ...GUEST };
  const rec = await db.getUser(s.key);
  return rec ? publicUser(rec) : null;
}
export { settings };
