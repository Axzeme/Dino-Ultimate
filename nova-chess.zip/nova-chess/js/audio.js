// Synthesised sound effects (no audio files). Everything is generated with the Web Audio API.
import { settings } from './store.js';

let ctx = null;
let master = null;
let noiseBuf = null;

function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  try {
    ctx = new AC();
    master = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    master.connect(comp); comp.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  } catch { ctx = null; }
  return ctx;
}

// Browsers only allow audio after a user gesture.
export function unlockAudio() {
  const c = ensure();
  if (c && c.state === 'suspended') c.resume().catch(() => {});
}
['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, unlockAudio, { passive: true }));

function vol() { return Math.pow(settings.get('volume') / 100, 1.6); }

function tone({ freq, end = freq, dur = 0.12, type = 'sine', gain = 0.3, delay = 0, attack = 0.004 }) {
  const c = ctx; const t = c.currentTime + delay;
  const o = c.createOscillator(); const g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (end !== freq) o.frequency.exponentialRampToValueAtTime(Math.max(20, end), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(master);
  o.start(t); o.stop(t + dur + 0.02);
}

function noise({ dur = 0.06, gain = 0.4, freq = 1800, q = 0.9, delay = 0, type = 'bandpass' }) {
  const c = ctx; const t = c.currentTime + delay;
  const s = c.createBufferSource(); s.buffer = noiseBuf;
  const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
  const g = c.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(master);
  s.start(t, Math.random() * 0.3); s.stop(t + dur + 0.02);
}

const SOUNDS = {
  move() { noise({ dur: 0.05, gain: 0.55, freq: 1500, q: 1.1 }); tone({ freq: 190, end: 120, dur: 0.09, gain: 0.35, type: 'triangle' }); },
  capture() {
    noise({ dur: 0.09, gain: 0.85, freq: 1100, q: 0.7 }); tone({ freq: 150, end: 80, dur: 0.14, gain: 0.5, type: 'triangle' });
    noise({ dur: 0.04, gain: 0.5, freq: 2600, q: 1.2, delay: 0.045 });
  },
  castle() { SOUNDS.move(); setTimeout(() => ctx && SOUNDS.move(), 110); },
  check() { SOUNDS.move(); tone({ freq: 880, dur: 0.14, gain: 0.18, type: 'sine', delay: 0.04 }); tone({ freq: 1175, dur: 0.18, gain: 0.16, type: 'sine', delay: 0.12 }); },
  promote() { SOUNDS.move(); [660, 880, 1320].forEach((f, i) => tone({ freq: f, dur: 0.16, gain: 0.16, delay: 0.05 + i * 0.07 })); },
  start() { [392, 523, 659].forEach((f, i) => tone({ freq: f, dur: 0.2, gain: 0.16, type: 'triangle', delay: i * 0.09 })); },
  end() { [523, 440, 349].forEach((f, i) => tone({ freq: f, dur: 0.32, gain: 0.17, type: 'triangle', delay: i * 0.14 })); },
  win() { [523, 659, 784, 1047].forEach((f, i) => tone({ freq: f, dur: 0.3, gain: 0.16, type: 'triangle', delay: i * 0.1 })); },
  checkmate() { SOUNDS.capture(); [392, 330, 262, 196].forEach((f, i) => tone({ freq: f, dur: 0.4, gain: 0.2, type: 'triangle', delay: 0.1 + i * 0.16 })); },
  illegal() { tone({ freq: 130, end: 95, dur: 0.16, gain: 0.3, type: 'sawtooth' }); },
  correct() { [660, 990].forEach((f, i) => tone({ freq: f, dur: 0.16, gain: 0.16, delay: i * 0.08 })); },
  wrong() { tone({ freq: 200, end: 120, dur: 0.24, gain: 0.26, type: 'square' }); },
  tick() { tone({ freq: 1400, dur: 0.03, gain: 0.08 }); },
};
const MOVE_SOUNDS = new Set(['move', 'capture', 'castle', 'check', 'promote', 'checkmate', 'illegal']);

export function play(name) {
  if (!settings.get('sound')) return;
  if (MOVE_SOUNDS.has(name) && !settings.get('moveSounds')) return;
  const c = ensure();
  if (!c) return;
  if (c.state === 'suspended') { c.resume().catch(() => {}); }
  master.gain.value = vol();
  try { SOUNDS[name]?.(); } catch { /* audio is best-effort */ }
}

/** Pick and play the right sound for a chess.js verbose move (after it was played). */
export function playForMove(move, { check = false, mate = false } = {}) {
  if (mate) return play('checkmate');
  if (check) return play('check');
  if (move.promotion) return play('promote');
  if (move.flags.includes('k') || move.flags.includes('q')) return play('castle');
  if (move.captured) return play('capture');
  return play('move');
}
