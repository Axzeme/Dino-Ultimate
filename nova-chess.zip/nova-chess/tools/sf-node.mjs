// Tiny promise wrapper around the npm Stockfish build for Node tooling (puzzle building / verification / strength tests).
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
// Each engine is its own child process speaking UCI over stdin/stdout, so several can run side by side.
const ENGINE = fileURLToPath(new URL('../node_modules/stockfish/bin/stockfish-19-lite-single.js', import.meta.url));

export class SF {
  constructor() {
    this.cur = null; this.ready = null; this.mpv = 1; this.opts = {};
    this.proc = spawn(process.execPath, [ENGINE], { stdio: ['pipe', 'pipe', 'ignore'] });
    createInterface({ input: this.proc.stdout }).on('line', (l) => this.onLine(l));
    this.send('uci');
  }
  send(c) { this.proc.stdin.write(`${c}\n`); }
  onLine(l) {
    if (l === 'readyok' && this.ready) { const r = this.ready; this.ready = null; r(); return; }
    const c = this.cur; if (!c) return;
    if (l.startsWith('info ') && l.includes(' pv ') && l.includes(' score ')) {
      if (/ (lower|upper)bound/.test(l)) return;
      const t = l.split(' '); const o = { mpv: 1 };
      for (let i = 1; i < t.length; i++) {
        if (t[i] === 'multipv') o.mpv = +t[++i];
        else if (t[i] === 'depth') o.depth = +t[++i];
        else if (t[i] === 'score') { const k = t[++i]; const v = +t[++i]; if (k === 'cp') o.cp = v; else o.mate = v; }
        else if (t[i] === 'pv') { o.pv = t.slice(i + 1); break; }
      }
      c.lines[o.mpv] = o;
    } else if (l.startsWith('bestmove')) {
      this.cur = null;
      const lines = Object.keys(c.lines).map(Number).sort((a, b) => a - b).map((k) => c.lines[k]);
      c.resolve({ best: l.split(' ')[1], lines });
    }
  }
  isReady() { return new Promise((r) => { this.ready = r; this.send('isready'); }); }
  setOption(k, v) { if (this.opts[k] !== v) { this.send(`setoption name ${k} value ${v}`); this.opts[k] = v; } }
  newGame() { this.send('ucinewgame'); }
  /** limits: { depth?, movetime? }. Scores are from the side to move's point of view. */
  async go(fen, { depth, movetime, multipv = 1, moves } = {}) {
    this.setOption('MultiPV', multipv);
    await this.isReady();
    return new Promise((resolve) => {
      this.cur = { lines: {}, resolve };
      this.send(`position fen ${fen}${moves?.length ? ` moves ${moves.join(' ')}` : ''}`);
      this.send(`go ${depth ? `depth ${depth} ` : ''}${movetime ? `movetime ${movetime}` : ''}`.trim());
    });
  }
  quit() { try { this.proc.kill(); } catch { /* ignore */ } }
}

/** Score of a search line as a comparable number from the mover's view (mate = ±100000 - distance). */
export const lineValue = (l) => (l == null ? -Infinity : l.mate != null ? (l.mate > 0 ? 1 : -1) * (100000 - Math.abs(l.mate)) : l.cp);
