// Builds js/puzzle-data.js from engine-mined candidates (data/mined-*.jsonl) plus hand-made positions (data/handmade.json).
// Every puzzle is re-verified with Stockfish before inclusion: unique best first move, every further player move unique,
// legal move sequence, mates really end in checkmate, and the line really wins.
//   node tools/build-puzzles.mjs
import { readFileSync, readdirSync, writeFileSync, existsSync } from 'node:fs';
import { Chess } from '../vendor/chess.js';
import { SF, lineValue } from './sf-node.mjs';

const V = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
const DEPTH = Number(process.env.DEPTH ?? 16);
const mv = (u) => ({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
const sf = new SF();

// ---------------------------------------------------------------- themes ---
const DIRS = { b: [[1, 1], [1, -1], [-1, 1], [-1, -1]], r: [[1, 0], [-1, 0], [0, 1], [0, -1]] };
DIRS.q = [...DIRS.b, ...DIRS.r];
const sqAt = (f, r) => (f < 0 || f > 7 || r < 0 || r > 7 ? null : 'abcdefgh'[f] + (r + 1));

function rayPairs(chess, from) {
  const p = chess.get(from);
  if (!p || !DIRS[p.type]) return [];
  const out = [];
  const f0 = from.charCodeAt(0) - 97, r0 = Number(from[1]) - 1;
  for (const [df, dr] of DIRS[p.type]) {
    let f = f0 + df, r = r0 + dr, first = null;
    while (sqAt(f, r)) {
      const s = sqAt(f, r); const q = chess.get(s);
      if (q) {
        if (q.color === p.color) break;
        if (!first) first = { sq: s, type: q.type };
        else { out.push({ a: first, b: { sq: s, type: q.type } }); break; }
      }
      f += df; r += dr;
    }
  }
  return out;
}

function attackedTargets(chess, from, color) {
  // enemy pieces attacked by the piece on `from` (geometric attacks)
  const out = [];
  for (const row of chess.board()) for (const q of row) {
    if (!q || q.color === color) continue;
    if (chess.attackers(q.square, color).includes(from)) out.push(q);
  }
  return out;
}

function detectThemes(fen, line) {
  const tags = [];
  const c0 = new Chess(fen);
  const mover = c0.turn();
  const first = mv(line[0]);
  const m1 = c0.move(first);
  const later = [];
  const c = new Chess(c0.fen());
  for (let i = 1; i < line.length; i++) { const m = c.move(mv(line[i])); if (i % 2 === 0) later.push(m); }
  const laterCaps = later.filter((m) => m.captured);

  // fork
  const tg = attackedTargets(c0, m1.to, mover).filter((q) => {
    if (q.type === 'k') return true;
    const defended = c0.attackers(q.square, q.color).length > 0;
    return V[q.type] >= 3 && (!defended || V[q.type] > V[m1.piece]);
  });
  if (tg.length >= 2 && laterCaps.some((m) => tg.some((q) => q.type === m.captured))) tags.push('fork');

  // pin / skewer by the moved slider
  for (const { a, b } of rayPairs(c0, m1.to)) {
    if (a.type !== 'k' && V[b.type] > V[a.type] && laterCaps.some((m) => m.to === a.sq)) tags.push('pin');
    if (V[a.type] > V[b.type] && V[b.type] >= 3 && laterCaps.some((m) => m.to === b.sq)) tags.push('skewer');
  }

  // discovered attack: a different own slider newly attacks a valuable piece through m1.from
  const before = new Chess(fen);
  const hits = (ch, sq) => rayPairs(ch, sq).length >= 0 ? (() => {
    const p = ch.get(sq); const res = new Set();
    if (!p || !DIRS[p.type]) return res;
    const f0 = sq.charCodeAt(0) - 97, r0 = Number(sq[1]) - 1;
    for (const [df, dr] of DIRS[p.type]) {
      let f = f0 + df, r = r0 + dr;
      while (sqAt(f, r)) { const s = sqAt(f, r); const q = ch.get(s); if (q) { if (q.color !== p.color && (q.type === 'k' || V[q.type] >= 3)) res.add(s); break; } f += df; r += dr; }
    }
    return res;
  })() : new Set();
  for (const row of c0.board()) for (const p of row) {
    if (!p || p.color !== mover || p.square === m1.to || !DIRS[p.type]) continue;
    const prev = hits(before, p.square), now = hits(c0, p.square);
    for (const t of now) if (!prev.has(t) && between(p.square, t, m1.from)) { if (m1.san.includes('+') || m1.captured || laterCaps.length || line.length >= 3) { tags.push('discovered'); } }
  }
  return [...new Set(tags)];
}

function between(a, b, x) {
  const ax = a.charCodeAt(0) - 97, ay = +a[1], bx = b.charCodeAt(0) - 97, by = +b[1], xx = x.charCodeAt(0) - 97, xy = +x[1];
  const dx = Math.sign(bx - ax), dy = Math.sign(by - ay);
  let cx = ax + dx, cy = ay + dy;
  while (cx !== bx || cy !== by) { if (cx === xx && cy === xy) return true; cx += dx; cy += dy; }
  return false;
}

function mateTags(fen, line) {
  const c = new Chess(fen);
  for (const u of line.slice(0, -1)) c.move(mv(u));
  const last = c.move(mv(line[line.length - 1]));
  const tags = [];
  const loser = c.turn();
  let ksq; for (const row of c.board()) for (const p of row) if (p && p.type === 'k' && p.color === loser) ksq = p.square;
  const f = ksq.charCodeAt(0) - 97, r = +ksq[1] - 1;
  const neigh = []; for (const df of [-1, 0, 1]) for (const dr of [-1, 0, 1]) { if (!df && !dr) continue; const s = sqAt(f + df, r + dr); if (s) neigh.push(s); }
  const own = neigh.filter((s) => c.get(s)?.color === loser);
  if (last.piece === 'n' && own.length === neigh.length) tags.push('smothered');
  if ((ksq[1] === '1' || ksq[1] === '8') && (last.piece === 'r' || last.piece === 'q') && last.to[1] === ksq[1]) tags.push('backrank');
  return tags;
}

// --------------------------------------------------------------- building ---
async function unique(fen, minGap = 150) {
  const r = await sf.go(fen, { depth: DEPTH, multipv: 2 });
  const [a, b] = r.lines;
  if (!a) return null;
  const gap = b ? lineValue(a) - lineValue(b) : Infinity;
  return { best: r.best, a, b, ok: !b || gap >= minGap, gap };
}

async function buildFromCandidate(cand) {
  const fen = cand.fen;
  const chess = new Chess(fen);
  const mover = chess.turn();
  // root verification at higher depth
  const root = await unique(fen, cand.kind === 'mate' ? 1 : 200);
  if (!root) return { reject: 'no root' };
  if (cand.kind === 'mate') {
    if (root.a.mate == null || root.a.mate <= 0 || root.a.mate > 3) return { reject: 'not forced mate at depth' };
    if (root.b && root.b.mate != null && root.b.mate > 0) return { reject: 'multiple mating first moves' };
    const n = root.a.mate;
    const line = root.a.pv.slice(0, 2 * n - 1);
    const c = new Chess(fen);
    try { for (const u of line) c.move(mv(u)); } catch { return { reject: 'illegal pv' }; }
    if (!c.isCheckmate()) return { reject: 'pv does not end in mate' };
    if (line.length < 2 * n - 1) return { reject: 'short pv' };
    // non-trivial: avoid positions where all kings moves are trivial? keep.
    return { fen, line, kind: 'mate', mate: n, eval: null, tags: mateTags(fen, line) };
  }
  // tactic
  if (!(root.ok && lineValue(root.a) >= 250)) return { reject: 'tactic not unique/winning at depth' };
  let line = [root.a.pv[0]];
  const pv = root.a.pv;
  const c = new Chess(fen);
  c.move(mv(pv[0]));
  for (let k = 1; k + 1 < pv.length && line.length < 5; k += 2) {
    c.move(mv(pv[k]));
    const next = c.fen();
    if (new Chess(next).isGameOver()) break;
    const u = await unique(next, 150);
    if (!u || !u.ok || u.best !== pv[k + 1]) break;
    c.move(mv(pv[k + 1]));
    line.push(pv[k], pv[k + 1]);
  }
  // final sanity: after the line the mover must still be clearly better
  const end = new Chess(fen); for (const u of line) end.move(mv(u));
  if (end.isGameOver()) { if (!end.isCheckmate()) return { reject: 'ended in draw' }; }
  else {
    const e = await sf.go(end.fen(), { depth: DEPTH });
    const v = -lineValue(e.lines[0]); // from the mover's side
    if (v < 200) return { reject: `line does not keep an advantage (${v})` };
  }
  const tags = detectThemes(fen, line);
  return { fen, line, kind: 'tactic', mate: null, eval: Math.round(lineValue(root.a)), gap: Math.min(1500, Math.round(root.gap)), tags };
}

const THEME_ORDER = ['discovered', 'skewer', 'pin', 'fork'];
function finalize(b, idx) {
  const mover = new Chess(b.fen).turn();
  let theme, difficulty, title;
  if (b.kind === 'mate') {
    theme = 'mate'; difficulty = b.mate; title = `Mate in ${b.mate}`;
    if (b.tags.includes('smothered')) title += ' · smothered';
    else if (b.tags.includes('backrank')) title += ' · back rank';
  } else {
    theme = THEME_ORDER.find((t) => b.tags.includes(t)) ?? 'tactic';
    const steps = Math.ceil(b.line.length / 2);
    difficulty = steps >= 3 ? 3 : steps === 2 ? 2 : (b.gap ?? 300) >= 600 ? 1 : 2;
    title = { fork: 'Fork', pin: 'Pin', skewer: 'Skewer', discovered: 'Discovered attack', tactic: 'Winning tactic' }[theme];
  }
  return { id: `P${String(idx).padStart(3, '0')}`, fen: b.fen, moves: b.line, theme, difficulty, title, mate: b.mate ?? null, side: mover };
}

async function main() {
  const cands = [];
  for (const f of readdirSync('data').filter((x) => /^mined-\d+\.jsonl$/.test(x))) {
    for (const l of readFileSync(`data/${f}`, 'utf8').split('\n').filter(Boolean)) cands.push(JSON.parse(l));
  }
  // hand-made positions (verified by the same pipeline): { fen, kind:'mate'|'tactic' }
  if (existsSync('data/handmade.json')) for (const h of JSON.parse(readFileSync('data/handmade.json', 'utf8'))) cands.push({ ...h, hand: true });
  console.error(`${cands.length} candidates`);
  const built = []; const rejects = {};
  for (const [i, cand] of cands.entries()) {
    try {
      new Chess(cand.fen);
      const b = await buildFromCandidate(cand);
      if (b.reject) { rejects[b.reject] = (rejects[b.reject] ?? 0) + 1; console.error(`  #${i} rejected: ${b.reject}`); continue; }
      built.push(b);
      console.error(`  #${i} ok ${b.kind} ${b.mate ?? ''} len ${b.line.length} tags [${b.tags}]`);
    } catch (e) { console.error(`  #${i} error ${e.message}`); }
  }
  // order: easy -> hard, grouped for variety
  const order = { mate: 0, fork: 1, pin: 2, skewer: 3, discovered: 4, tactic: 5 };
  const puzzles = built.map((b, i) => finalize(b, i + 1));
  puzzles.sort((a, b) => a.difficulty - b.difficulty || order[a.theme] - order[b.theme]);
  puzzles.forEach((p, i) => { p.id = `P${String(i + 1).padStart(3, '0')}`; });
  const counts = {}; for (const p of puzzles) counts[p.theme] = (counts[p.theme] ?? 0) + 1;
  console.error('themes:', counts, 'rejects:', rejects);
  const out = `// GENERATED by tools/build-puzzles.mjs — do not edit by hand.\n// Each puzzle: the side to move plays moves[0], the opponent replies moves[1], and so on.\n// Every position was verified with Stockfish (unique best first move; mates end in checkmate).\nexport const PUZZLES = ${JSON.stringify(puzzles, null, 1).replace(/\n\s+/g, ' ').replace(/\[ /g, '[').replace(/ \]/g, ']').replace(/\{ /g, '{\n ').replace(/ \}/g, '\n}')};\n`;
  writeFileSync('js/puzzle-data.js', out);
  sf.quit();
  console.error(`wrote js/puzzle-data.js (${puzzles.length} puzzles)`);
  process.exit(0);
}
main();
