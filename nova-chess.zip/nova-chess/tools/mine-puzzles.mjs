// Mines tactical positions with a real Stockfish: plays noisy self-play games and records positions where
// the side to move has ONE clearly best move (forced mate, or a large material/eval swing that no other move keeps).
// Every candidate is later re-verified at a higher depth by tools/verify-puzzles.mjs.
//
//   SEED=1 BUDGET_MS=600000 OUT=data/mined-1.jsonl node tools/mine-puzzles.mjs
import { createRequire } from 'node:module';
import { appendFileSync } from 'node:fs';
import { Chess } from '../vendor/chess.js';

const require = createRequire(import.meta.url);
const SEED = Number(process.env.SEED ?? 1);
const BUDGET = Number(process.env.BUDGET_MS ?? 300000);
const OUT = process.env.OUT ?? `data/mined-${SEED}.jsonl`;
const DEPTH = Number(process.env.DEPTH ?? 12);

function rng(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const rand = rng(SEED * 7919);

class SF {
  constructor() {
    this.cur = null; this.ready = null; this.mpv = 1;
    this.sf = require('stockfish')('lite-single', (l) => this.onLine(l));
    this.sf.processCommand('uci');
  }
  onLine(l) {
    if (l === 'readyok' && this.ready) { const r = this.ready; this.ready = null; r(); return; }
    const c = this.cur; if (!c) return;
    if (l.startsWith('info ') && l.includes(' pv ') && l.includes(' score ')) {
      if (/ (lower|upper)bound/.test(l)) return;
      const t = l.split(' '); const o = { mpv: 1 };
      for (let i = 1; i < t.length; i++) {
        if (t[i] === 'multipv') o.mpv = +t[++i];
        else if (t[i] === 'depth') o.depth = +t[++i];
        else if (t[i] === 'score') { const k = t[++i]; const v = +t[++i]; if (k === 'cp') o.cp = v; else o.mate = v; }
        else if (t[i] === 'pv') { o.pv = t.slice(i + 1); break; }
      }
      c.lines[o.mpv] = o;
    } else if (l.startsWith('bestmove')) {
      this.cur = null;
      c.resolve(Object.keys(c.lines).map(Number).sort((a, b) => a - b).map((k) => c.lines[k]));
    }
  }
  isReady() { return new Promise((r) => { this.ready = r; this.sf.processCommand('isready'); }); }
  async go(fen, depth, multipv = 1) {
    if (this.mpv !== multipv) { this.sf.processCommand(`setoption name MultiPV value ${multipv}`); this.mpv = multipv; }
    await this.isReady();
    return new Promise((resolve) => {
      this.cur = { lines: {}, resolve };
      this.sf.processCommand(`position fen ${fen}`);
      this.sf.processCommand(`go depth ${depth}`);
    });
  }
  quit() { try { this.sf.terminate(); } catch { /* ignore */ } }
}

const V = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

function isFreeCapture(fen, uci) {
  const c = new Chess(fen);
  const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
  if (!m.captured) return false;
  // capture of a piece that cannot be recaptured, by a piece worth no more than what it takes or equal => "free"
  const defended = c.attackers(m.to, c.turn()).length > 0;
  return !defended || V[m.captured] > V[m.piece] + 0;
}

const stm = (fen) => fen.split(' ')[1];

async function main() {
  const sf = new SF();
  const t0 = Date.now();
  const seen = new Set();
  let games = 0, found = 0;
  while (Date.now() - t0 < BUDGET) {
    games++;
    const chess = new Chess();
    const randomPlies = 4 + Math.floor(rand() * 5);
    for (let ply = 0; ply < 140 && Date.now() - t0 < BUDGET; ply++) {
      if (chess.isGameOver()) break;
      const fen = chess.fen();
      const legal = chess.moves({ verbose: true });
      if (ply < randomPlies) { const m = legal[Math.floor(rand() * legal.length)]; chess.move(m); continue; }
      const lines = await sf.go(fen, DEPTH, 3);
      const key = fen.split(' ').slice(0, 4).join(' ');
      if (lines.length >= 2 && !seen.has(key) && ply >= 8) {
        const top = lines[0], second = lines[1];
        const pieces = fen.split(' ')[0].replace(/[^a-zA-Z]/g, '').length;
        let kind = null, mate = null;
        if (top.mate > 0 && top.mate <= 3 && second.mate == null && (second.cp ?? 0) < 600) { kind = 'mate'; mate = top.mate; }
        else if (top.mate == null && top.cp >= 300 && top.cp - second.cp >= 250 && (second.cp ?? 0) <= 150 && pieces >= 6) kind = 'tactic';
        if (kind) {
          const best = top.pv[0];
          if (kind === 'tactic' && isFreeCapture(fen, best)) { /* skip trivial hanging-piece grabs */ }
          else if (kind === 'tactic' && chess.isCheck() === false && top.pv.length < 3) { /* need a line */ }
          else {
            seen.add(key); found++;
            appendFileSync(OUT, JSON.stringify({ fen, kind, mate, cp: top.cp ?? null, second: second.cp ?? (second.mate != null ? `M${second.mate}` : null), pv: top.pv.slice(0, 7), depth: top.depth, ply }) + '\n');
          }
        }
      }
      // choose a move: mostly best, sometimes a worse candidate, sometimes random -> tactics appear
      let pick;
      const r = rand();
      if (r < 0.1) pick = legal[Math.floor(rand() * legal.length)];
      else {
        const usable = lines.filter((l) => l.mate == null || l.mate > 0).slice(0, 3);
        const w = [0.62, 0.24, 0.14];
        let x = rand(), i = 0;
        for (; i < usable.length - 1; i++) { x -= w[i]; if (x < 0) break; }
        const u = (usable[i] ?? lines[0]).pv[0];
        pick = { from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] };
      }
      try { chess.move(pick); } catch { break; }
    }
    if (games % 5 === 0) console.error(`[seed ${SEED}] games ${games}, candidates ${found}, ${(Date.now() - t0) / 1000 | 0}s`);
  }
  sf.quit();
  console.error(`[seed ${SEED}] done: ${games} games, ${found} candidates`);
  process.exit(0);
}
main();
