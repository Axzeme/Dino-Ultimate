// Engine-vs-engine check that the difficulty presets differ in real playing strength.
//   node tests/strength.mjs
import { Chess } from '../vendor/chess.js';
import { SF } from '../tools/sf-node.mjs';
import { LEVELS } from '../js/engine.js';

const lvl = (id) => LEVELS.find((l) => l.id === id);
async function setup(sf, l) {
  sf.setOption('Skill Level', l.limit ? 20 : l.skill);
  sf.setOption('UCI_LimitStrength', !!l.limit);
  sf.setOption('UCI_Elo', Math.max(1320, Math.min(3190, l.uciElo)));
  sf.setOption('Hash', 32);
}
function rng(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

async function game(white, black, seed) {
  const r = rng(seed), c = new Chess();
  for (let i = 0; i < 4; i++) { const m = c.moves(); c.move(m[Math.floor(r() * m.length)]); } // random opening for variety
  const eng = { w: white, b: black };
  while (!c.isGameOver() && c.history().length < 220) {
    const side = eng[c.turn()];
    await setup(side.sf, side.l);
    const res = await side.sf.go(c.fen(), { depth: side.l.depth, movetime: side.l.movetime });
    if (!res.best || res.best === '(none)') break;
    c.move({ from: res.best.slice(0, 2), to: res.best.slice(2, 4), promotion: res.best[4] });
  }
  if (c.isCheckmate()) return c.turn() === 'w' ? 0 : 1; // 1 = white won
  return 0.5;
}

async function match(a, b, games) {
  const A = { sf: new SF(), l: lvl(a) }, B = { sf: new SF(), l: lvl(b) };
  let sa = 0;
  for (let g = 0; g < games; g++) {
    const aWhite = g % 2 === 0;
    A.sf.newGame(); B.sf.newGame();
    const res = await game(aWhite ? A : B, aWhite ? B : A, 100 + g * 7);
    sa += aWhite ? res : 1 - res;
  }
  A.sf.quit(); B.sf.quit();
  console.log(`${a.padEnd(12)} vs ${b.padEnd(12)}: ${a} scored ${sa}/${games}`);
  return sa;
}
const pairs = [['beginner', 'intermediate', 4], ['easy', 'advanced', 4], ['intermediate', 'master', 2]];
let monotonic = true;
for (const [a, b, n] of pairs) { const s = await match(a, b, n); if (s > n / 2) monotonic = false; }
console.log(monotonic ? 'PASS: stronger presets beat weaker ones' : 'FAIL: a weaker preset out-scored a stronger one');
process.exit(monotonic ? 0 : 1);
