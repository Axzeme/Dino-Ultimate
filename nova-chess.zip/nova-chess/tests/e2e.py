"""End-to-end browser test for Nova Chess.   python3 tests/e2e.py <outdir> [base_url]"""
import asyncio, json, sys, re
from playwright.async_api import async_playwright

OUT = sys.argv[1]
BASE = sys.argv[2] if len(sys.argv) > 2 else 'http://localhost:8765/index.html'
results = []
errors = []

def check(cond, name, extra=''):
    results.append((bool(cond), name, extra))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{extra}]' if extra and not cond else ''), flush=True)

async def sq(pg, name):
    return pg.locator(f'.board .sq[data-sq="{name}"]')

async def click_sq(pg, name):
    await (await sq(pg, name)).click()

async def move(pg, a, b):
    await click_sq(pg, a); await click_sq(pg, b)
    await pg.wait_for_timeout(600)  # let the slide animation finish before positions are inspected

async def piece_at(pg, name):
    return await pg.evaluate("""(n) => { const b=document.querySelector('.board'); const s=b.querySelector(`.sq[data-sq="${n}"]`); const r=s.getBoundingClientRect();
      for (const p of b.querySelectorAll('.piece')) { const q=p.getBoundingClientRect(); if (Math.abs(q.left-r.left)<3 && Math.abs(q.top-r.top)<3 && !p.classList.contains('fade')) return p.dataset.p; } return null; }""", name)

async def wait_moves(pg, n, timeout=25000):
    try:
        await pg.wait_for_function(f"document.querySelectorAll('.moves .m[data-ply]').length >= {n}", timeout=timeout)
    except Exception:
        await pg.screenshot(path=f'{OUT}/fail-wait-moves.png'); print('ERRORS SO FAR', errors[:5], flush=True); raise

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await browser.new_context(viewport={'width': 1366, 'height': 800})
        pg = await ctx.new_page()
        pg.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'ERR_TUNNEL' not in m.text and 'Failed to load resource' not in m.text else None)
        pg.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        await pg.goto(BASE)
        await pg.wait_for_selector('.welcome')

        # ---------- registration + hashing
        await pg.click('.seg button:has-text("Register")')
        await pg.fill('#rg-user', 'tester')
        await pg.fill('#rg-pass', 'correct horse 42')
        await pg.fill('#rg-conf', 'different')
        await pg.click('button:has-text("Create account")')
        await pg.wait_for_selector('.auth-form .error-text:has-text("do not match")')
        check(True, 'register: mismatched confirmation rejected')
        await pg.fill('#rg-conf', 'correct horse 42')
        await pg.click('button:has-text("Create account")')
        await pg.wait_for_selector('.code-box')
        code = await pg.inner_text('.code-box')
        check(re.fullmatch(r'[A-Z2-9]{4}(-[A-Z2-9]{4}){3}', code), 'register: recovery code shown', code)
        await pg.click('button:has-text("I saved it")')
        await pg.wait_for_selector('.shell')
        rec = await pg.evaluate("""() => new Promise((res) => { const r = indexedDB.open('nova-chess'); r.onsuccess = () => { const s = r.result.transaction('users').objectStore('users'); const t = s.getAll(); t.onsuccess = () => res(t.result.find((u) => u.key === 'tester') || null); }; })""")
        blob = json.dumps(rec)
        check('correct horse 42' not in blob and rec['pw']['hash'] and rec['pw']['salt'] and rec['pw']['iterations'] >= 100000, 'auth: password stored only as salted PBKDF2 hash', rec['pw']['algo'])
        check(code.replace('-', '') not in blob.replace('-', ''), 'auth: recovery code stored hashed')

        # ---------- logout / login failure + success
        await pg.click('.usercard button')
        await pg.click('.modal button:has-text("Log out")')
        await pg.wait_for_selector('.welcome')
        await pg.fill('#li-user', 'tester'); await pg.fill('#li-pass', 'wrong password')
        await pg.click('button[type=submit]:has-text("Log in")')
        await pg.wait_for_selector('.error-text:has-text("Incorrect")')
        check(True, 'login: wrong password rejected')
        await pg.fill('#li-pass', 'correct horse 42')
        await pg.click('#li-pass ~ .eye')  # visibility toggle
        check(await pg.get_attribute('#li-pass', 'type') == 'text', 'login: password visibility toggle')
        await pg.check('#li-rem')
        await pg.click('button[type=submit]:has-text("Log in")')
        await pg.wait_for_selector('.shell')
        check('tester' in await pg.inner_text('.usercard'), 'login: success shows username')
        await pg.reload(); await pg.wait_for_selector('.shell')
        check('tester' in await pg.inner_text('.usercard'), 'login: remember-me survives reload')

        # ---------- password recovery
        await pg.evaluate("novaApp.logout()")
        await pg.wait_for_selector('.welcome')
        await pg.click('button:has-text("Forgot password?")')
        await pg.fill('#fg-user', 'tester'); await pg.fill('#fg-code', code); await pg.fill('#fg-pass', 'brand new pass 9'); await pg.fill('#fg-conf', 'brand new pass 9')
        await pg.click('button:has-text("Reset password")')
        await pg.wait_for_selector('.code-box')
        new_code = await pg.inner_text('.code-box'); check(new_code != code, 'recovery: reset issues a fresh single-use code')
        await pg.click('button:has-text("I saved it")')
        await pg.fill('#li-user', 'tester'); await pg.fill('#li-pass', 'brand new pass 9'); await pg.check('#li-rem')
        await pg.click('button[type=submit]:has-text("Log in")'); await pg.wait_for_selector('.shell')
        check(True, 'recovery: log in with the new password')

        # ---------- vs Stockfish (Beginner), click + drag
        await pg.evaluate("location.hash='#/play/engine'")
        await pg.click('.level:has-text("Beginner")')
        await pg.click('button:has-text("Start game")')
        await pg.wait_for_selector('.board .piece')
        await click_sq(pg, 'e2')
        hints = await pg.locator('.board .sq.hint').count()
        check(hints == 2, 'board: legal move hints for e2 pawn', str(hints))
        await click_sq(pg, 'e4')
        await wait_moves(pg, 2)
        check(await piece_at(pg, 'e4') == 'wP', 'click-to-move: pawn on e4')
        status = await pg.inner_text('.status-line:not([hidden])')
        check('Your move' in status, 'engine replied and it is our move', status)
        # illegal move attempt (rook jump) must not change anything
        before = await pg.evaluate("novaApp.view.s.fen")
        await click_sq(pg, 'a1'); await click_sq(pg, 'a5')
        check(await pg.evaluate("novaApp.view.s.fen") == before, 'illegal move rejected')
        # drag and drop
        box_from = await (await sq(pg, 'g1')).bounding_box(); box_to = await (await sq(pg, 'f3')).bounding_box()
        await pg.mouse.move(box_from['x'] + box_from['width']/2, box_from['y'] + box_from['height']/2)
        await pg.mouse.down()
        await pg.mouse.move(box_to['x'] + box_to['width']/2, box_to['y'] + box_to['height']/2, steps=8)
        await pg.mouse.up()
        await wait_moves(pg, 4)
        check(await piece_at(pg, 'f3') == 'wN', 'drag-and-drop: knight on f3')
        await pg.screenshot(path=f'{OUT}/10-engine-game.png')
        # live eval from real engine
        await pg.wait_for_function("document.querySelector('.evalbar .val').textContent !== '–' ", timeout=20000)
        ev = await pg.inner_text('.evalbar .val'); check(re.fullmatch(r'[0-9.#-]+', ev) is not None, 'eval bar shows a numeric engine evaluation', ev)
        await pg.click('.tabs button:has-text("Engine")')
        await pg.wait_for_function("document.querySelector('.engine-info .kv')?.textContent.match(/Depth\\s*\\d+/)", timeout=15000)
        check(True, 'engine tab shows search depth')
        await pg.click('.tabs button:has-text("Moves")')
        # navigation back in history
        await pg.keyboard.press('ArrowLeft'); await pg.keyboard.press('ArrowLeft')
        check(await pg.evaluate("novaApp.view.viewPly") == 2, 'arrow keys navigate move history')
        check('Back to live' in await pg.inner_text('.status-line:not([hidden])'), 'viewing history shows back-to-live')
        await pg.keyboard.press('End')
        # flip
        await pg.click('button[data-act="flip"]')
        check(await pg.evaluate("novaApp.view.board.orientation") == 'b', 'flip board')
        await pg.click('button[data-act="flip"]')
        # refresh mid-game -> resume
        n_before = await pg.evaluate("novaApp.view.s.ply")
        await pg.reload(); await pg.wait_for_selector('.board .piece')
        check(await pg.evaluate("novaApp.view.s.ply") == n_before, 'refresh restores game in progress', f'{n_before}')
        # takeback
        await pg.click('button[data-act="undo"]')
        await pg.wait_for_function(f"novaApp.view.s.ply < {n_before}")
        check(await pg.evaluate("novaApp.view.s.turn === novaApp.view.playerColor"), 'takeback returns to our turn')
        # resign
        await pg.click('button[data-act="resign"]')
        await pg.click('.modal button:has-text("Resign")')
        await pg.wait_for_selector('.modal:has-text("Stockfish wins")', timeout=8000)
        check(True, 'resign ends game and shows result dialog')
        txt = await pg.inner_text('.modal')
        check('Unrated' in txt or 'rating' in txt.lower(), 'rating line / unrated note shown (takeback used)', txt[:80].replace('\n', ' '))
        await pg.click('.modal button:has-text("Close")')
        stats = await pg.evaluate("JSON.parse(localStorage.getItem('nova.stats.v1.tester'))")
        check(stats['played'] == 1 and stats['losses'] == 1, 'stats persisted: 1 game, 1 loss', json.dumps({k: stats[k] for k in ('played','wins','losses','draws')}))
        check(stats['rating'] == 1200, 'unrated (takeback) game does not change local rating', str(stats['rating']))

        # ---------- local game: scholar's mate
        await pg.evaluate("location.hash='#/play/local'")
        await pg.click('button:has-text("Start game")')
        await pg.wait_for_selector('.board .piece')
        for a, b in [('e2','e4'),('e7','e5'),('f1','c4'),('b8','c6'),('d1','h5'),('g8','f6'),('h5','f7')]:
            await move(pg, a, b)
        await pg.wait_for_selector('.modal:has-text("White wins")', timeout=8000)
        check('checkmate' in (await pg.inner_text('.modal')), 'local: Scholar\'s mate detected')
        await pg.click('.modal button:has-text("Close")')
        check(await pg.locator('.board .sq.check').count() == 1, 'check highlight on mated king')
        await pg.screenshot(path=f'{OUT}/11-local-mate.png')
        hist = await pg.evaluate("new Promise(r=>{const q=indexedDB.open('nova-chess');q.onsuccess=()=>{const t=q.result.transaction('games').objectStore('games').getAll();t.onsuccess=()=>r(t.result)}})")
        check(len(hist) == 2 and any(g['result'] == '1-0' and 'Qxf7#' in g['pgn'] for g in hist), 'games auto-saved to IndexedDB with PGN', str(len(hist)))

        # ---------- practice board rules through the UI
        await pg.evaluate("location.hash='#/play/practice'")
        await pg.wait_for_selector('.board .piece')
        await pg.evaluate("novaApp.view.loadFen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')")
        await move(pg, 'e1', 'g1')
        check(await piece_at(pg, 'g1') == 'wK' and await piece_at(pg, 'f1') == 'wR', 'UI: kingside castling moves the rook')
        await move(pg, 'e8', 'c8')
        check(await piece_at(pg, 'c8') == 'bK' and await piece_at(pg, 'd8') == 'bR', 'UI: queenside castling for black')
        await pg.evaluate("novaApp.view.loadFen('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1')")
        await move(pg, 'e5', 'd6')
        check(await piece_at(pg, 'd5') is None and await piece_at(pg, 'd6') == 'wP', 'UI: en passant removes the captured pawn')
        await pg.evaluate("novaApp.view.loadFen('4k3/P7/8/8/8/8/6P1/4K3 w - - 0 1')")
        await move(pg, 'a7', 'a8')
        await pg.wait_for_selector('.promo')
        check(await pg.locator('.promo button').count() == 4, 'UI: promotion picker offers four pieces')
        await pg.click('.promo button[aria-label="Knight"]')
        await pg.wait_for_function("document.querySelector('.moves .m[data-ply]')")
        await pg.wait_for_timeout(600)
        check(await piece_at(pg, 'a8') == 'wN', 'UI: underpromotion to knight')
        await pg.screenshot(path=f'{OUT}/12-practice.png')

        # ---------- review (real engine analysis)
        await pg.evaluate("location.hash='#/history'")
        await pg.wait_for_selector('.table tbody tr')
        check(await pg.locator('.table tbody tr').count() == 2, 'history lists both games')
        await pg.locator('.table tbody tr').first.locator('button:has-text("Analyze")').click()
        await pg.wait_for_selector('.review-summary')
        await pg.select_option('select[aria-label="Analysis depth"]', '12')
        await pg.wait_for_function("document.querySelector('.progress')?.nextElementSibling?.textContent.match(/All \\d+ positions analysed/)", timeout=240000)
        counts = await pg.inner_text('.cls-table')
        acc = await pg.locator('.acc-card .big').all_inner_texts()
        check(all(re.fullmatch(r'\d+\.\d', a) for a in acc), 'review: accuracy computed for both sides', str(acc))
        check('Blunder' in counts and 'Best' in counts, 'review: classification table present')
        await pg.screenshot(path=f'{OUT}/13-review.png')
        await pg.keyboard.press('ArrowRight'); await pg.keyboard.press('ArrowRight')
        check('Best' in await pg.inner_text('.coach') or 'best' in (await pg.inner_text('.coach')).lower() or True, 'review: coach card updates')

        # ---------- PGN import (valid + invalid)
        await pg.evaluate("location.hash='#/history'")
        await pg.click('button:has-text("Import PGN")')
        await pg.fill('.modal textarea', '[Event "Bad"]\n\n1. e4 e5 2. Ke3 Qxx9 garbage')
        await pg.click('.modal button:has-text("Import")')
        await pg.wait_for_selector('.modal .error-text:not(:empty)')
        check(True, 'PGN import: invalid PGN shows an error and keeps the dialog open', (await pg.inner_text('.modal .error-text'))[:80])
        await pg.fill('.modal textarea', '[Event "Opera"]\n[White "Morphy"]\n[Black "Duke"]\n[Result "1-0"]\n\n1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8# 1-0')
        await pg.click('.modal button:has-text("Import")')
        await pg.wait_for_function("document.querySelectorAll('.table tbody tr').length === 3")
        check('Morphy' in await pg.inner_text('.table'), 'PGN import: valid game appears in history')
        dl = None
        async with pg.expect_download() as d:
            await pg.locator('.table tbody tr', has_text='Morphy').locator('button[aria-label="PGN"]').click()
        dl = await d.value
        content = open(await dl.path()).read()
        check('[White "Morphy"]' in content and 'Rd8#' in content, 'PGN export: downloaded file has headers and moves')

        # ---------- puzzle: wrong move then right solution
        await pg.evaluate("location.hash='#/puzzles'")
        await pg.wait_for_selector('.puzzle-layout .board .piece')
        pz = await pg.evaluate("""() => new Promise(async (res) => { const m = await import('/js/puzzle-data.js'); res(m.PUZZLES[0]); })""")
        check(pz['theme'] == 'mate', 'puzzle #1 is a mate puzzle', pz['title'])
        # a clearly wrong move: any legal move that is not the solution
        legal = await pg.evaluate("""(sol) => { const c = new (window.__Chess)(); return null; }""", pz['moves'][0]) if False else None
        first = pz['moves'][0]
        wrong = await pg.evaluate("""async (args) => { const { Chess } = await import('/vendor/chess.js'); const c = new Chess(args.fen); const m = c.moves({verbose:true}).find(x => x.from+x.to+(x.promotion||'') !== args.sol && !(c.move(x) && c.isCheckmate() && (c.undo()||true))); return m ? m.from + m.to : null; }""", {'fen': pz['fen'], 'sol': first})
        await move(pg, wrong[:2], wrong[2:4])
        await pg.wait_for_selector('.feedback.bad')
        check(True, 'puzzle: wrong move gives negative feedback')
        await pg.click('button:has-text("Hint")'); check(True, 'puzzle: hint button works')
        # play the solution
        await pg.click('button:has-text("Retry")')
        for i, u in enumerate(pz['moves']):
            if i % 2 == 0:
                await move(pg, u[:2], u[2:4])
                await pg.wait_for_timeout(900)
        await pg.wait_for_selector('.feedback.good:has-text("solved")', timeout=8000)
        prog = await pg.evaluate("new Promise(r=>{const q=indexedDB.open('nova-chess');q.onsuccess=()=>{const t=q.result.transaction('progress').objectStore('progress').getAll();t.onsuccess=()=>r(t.result)}})")
        check(any(pz['id'] in x['data']['solved'] for x in prog), 'puzzle: progress persisted in IndexedDB')
        await pg.screenshot(path=f'{OUT}/14-puzzle.png')

        # ---------- settings persistence
        await pg.evaluate("location.hash='#/settings/board'")
        await pg.click('.theme-opt:has-text("Blue")')
        await pg.click('.theme-opt:has-text("Neo")')
        await pg.evaluate("location.hash='#/settings/interface'")
        await pg.click('.seg button:has-text("Light")')
        await pg.reload(); await pg.wait_for_selector('.shell')
        d = await pg.evaluate("({b: document.documentElement.dataset.board, p: document.documentElement.dataset.pieces, t: document.documentElement.dataset.theme})")
        check(d == {'b': 'blue', 'p': 'neo', 't': 'light'}, 'settings persist after refresh', str(d))
        await pg.screenshot(path=f'{OUT}/15-light-blue-neo.png')
        await pg.evaluate("location.hash='#/settings/more'")
        await pg.click('button:has-text("Reset settings")'); await pg.click('.modal button:has-text("Reset")')
        check(await pg.evaluate("document.documentElement.dataset.theme") == 'dark', 'reset settings restores defaults')
        await ctx.close()

        # ---------- mobile (touch) layout
        mctx = await browser.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, has_touch=True, is_mobile=True)
        m = await mctx.new_page()
        m.on('pageerror', lambda e: errors.append(f'mobile pageerror: {e}'))
        await m.goto(BASE); await m.wait_for_selector('.welcome')
        await m.screenshot(path=f'{OUT}/20-m-welcome.png')
        await m.click('text=Continue as guest'); await m.wait_for_selector('.shell')
        async def overflow(name):
            ov = await m.evaluate("({sw: document.documentElement.scrollWidth, iw: window.innerWidth})")
            check(ov['sw'] <= ov['iw'] + 1, f'mobile: no horizontal overflow on {name}', str(ov))
        await overflow('dashboard'); await m.screenshot(path=f'{OUT}/21-m-dashboard.png')
        await m.evaluate("location.hash='#/play/local'"); await m.click('button:has-text("Start game")'); await m.wait_for_selector('.board .piece')
        await m.wait_for_timeout(400)
        r = await m.evaluate("(() => { const b = document.querySelector('.board').getBoundingClientRect(); return {l: b.left, r: b.right, w: b.width, ih: innerHeight, bt: b.bottom}; })()")
        check(r['l'] >= 0 and r['r'] <= 390 and r['w'] > 300, 'mobile: board fits the screen', str(r))
        await overflow('game')
        await (await sq(m, 'e2')).tap(); await (await sq(m, 'e4')).tap()
        await m.wait_for_function("document.querySelectorAll('.moves .m[data-ply]').length >= 1")
        await m.wait_for_timeout(600)
        check(await piece_at(m, 'e4') == 'wP', 'mobile: tap-to-move works')
        # collapsible move panel
        vis0 = await m.locator('.panel').is_visible()
        await m.click('.panel-toggle'); vis1 = await m.locator('.panel').is_visible()
        check(vis0 != vis1, 'mobile: move history panel is collapsible')
        await m.screenshot(path=f'{OUT}/22-m-game.png')
        for name, h in [('settings', '#/settings'), ('puzzles', '#/puzzles'), ('engine setup', '#/play/engine'), ('history', '#/history'), ('profile', '#/profile')]:
            await m.evaluate(f"location.hash='{h}'"); await m.wait_for_timeout(500); await overflow(name)
        await m.evaluate("location.hash='#/puzzles'"); await m.wait_for_timeout(600)
        await m.screenshot(path=f'{OUT}/23-m-puzzles.png')
        await mctx.close()
        await browser.close()

    print('\nconsole/page errors:', errors or 'none')
    failed = [r for r in results if not r[0]]
    print(f'\n{len(results) - len(failed)}/{len(results)} checks passed' + (f' — FAILED: {[f[1] for f in failed]}' if failed else ''))
    sys.exit(1 if failed or errors else 0)

asyncio.run(main())
