// Rules + session tests (run: node tests/rules.test.mjs)
import { Chess } from '../vendor/chess.js';
import { GameSession, START_FEN, hasMatingMaterial } from '../js/game.js';
import { parseGame, splitPgn, importedRecord } from '../js/pgn.js';
import { classifyMove, moveAccuracy, sacrificeValue, replay, summarize } from '../js/analysis.js';
import { cpToWin, fmtScore, barPercent, scoreToCp } from '../js/engine.js';
import { expectedScore } from '../js/stats.js';

let pass = 0, fail = 0;
const ok = (c, name) => { if (c) pass++; else { fail++; console.log('FAIL:', name); } };
const eq = (a, b, name) => ok(JSON.stringify(a) === JSON.stringify(b), `${name} (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`);

function perft(c, d) { if (d === 0) return 1; let n = 0; for (const m of c.moves({ verbose: true })) { c.move(m); n += perft(c, d - 1); c.undo(); } return n; }
// --- move generation (known perft values)
eq([1, 2, 3, 4].map((d) => perft(new Chess(), d)), [20, 400, 8902, 197281], 'perft startpos 1-4');
const kiwi = 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1';
eq([1, 2, 3].map((d) => perft(new Chess(kiwi), d)), [48, 2039, 97862], 'perft kiwipete 1-3');
eq([1, 2, 3, 4].map((d) => perft(new Chess('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'), d)), [14, 191, 2812, 43238], 'perft position 3 (en passant / pins)');
eq([1, 2, 3].map((d) => perft(new Chess('r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1'), d)), [6, 264, 9467], 'perft position 4 (promotions / castling)');

const S = (fen, cfg = {}) => new GameSession({ mode: 'local', white: { name: 'W' }, black: { name: 'B' }, timeControl: null, startFen: fen, ...cfg });
const play = (s, ...sans) => { for (const san of sans) { const m = s.chess.moves({ verbose: true }).find((x) => x.san === san); if (!m) throw new Error(`illegal in test: ${san}`); s.move({ from: m.from, to: m.to, promotion: m.promotion }); } };

// --- all piece movements implicitly covered by perft; targeted rule checks:
{ // castling both sides + through-check refusal
  const s = S('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
  const legal = s.chess.moves();
  ok(legal.includes('O-O') && legal.includes('O-O-O'), 'castling both sides available');
  play(s, 'O-O'); eq([s.chess.get('g1')?.type, s.chess.get('f1')?.type], ['k', 'r'], 'kingside castle places K g1, R f1');
  play(s, 'O-O-O'); eq([s.chess.get('c8')?.type, s.chess.get('d8')?.type], ['k', 'r'], 'queenside castle for black');
  const t = S('4k3/8/8/8/8/5r2/8/R3K2R w KQ - 0 1'); // f-file attacked: no O-O (passes through f1)
  ok(!t.chess.moves().includes('O-O') && t.chess.moves().includes('O-O-O'), 'cannot castle through an attacked square');
  const u = S('4k3/8/8/8/8/8/4r3/R3K2R w KQ - 0 1'); // in check: no castling
  ok(!u.chess.moves().includes('O-O') && !u.chess.moves().includes('O-O-O'), 'cannot castle out of check');
}
{ // en passant
  const s = S('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1');
  const m = s.move({ from: 'e5', to: 'd6' });
  ok(m && m.flags.includes('e') && !s.chess.get('d5'), 'en passant captures the pawn');
  const s2 = S(START_FEN); play(s2, 'e4', 'a6', 'e5', 'd5'); ok(s2.chess.moves().includes('exd6'), 'en passant offered right after double step');
  play(s2, 'Nf3', 'a5'); ok(!s2.chess.moves().includes('exd6'), 'en passant expires');
}
{ // promotion to all four pieces, auto ordering
  const s = S('4k3/P7/8/8/8/8/6P1/4K3 w - - 0 1');
  eq(s.chess.moves({ square: 'a7', verbose: true }).map((m) => m.promotion).sort(), ['b', 'n', 'q', 'r'], 'promotion options q r b n');
  ok(s.isPromotion('a7', 'a8'), 'isPromotion detects');
  const m = s.move({ from: 'a7', to: 'a8', promotion: 'n' }); ok(m && s.chess.get('a8').type === 'n', 'underpromotion to knight works');
  ok(s.move({ from: 'e8', to: 'e7' }) !== null, 'game continues after promotion');
}
{ // illegal moves are rejected (pinned piece, moving into check, wrong turn, nonsense)
  const s = S('4k3/4r3/8/8/8/8/4B3/4K3 w - - 0 1');
  eq(s.move({ from: 'e2', to: 'd3' }), null, 'pinned bishop cannot move off the pin line');
  eq(s.move({ from: 'e1', to: 'd1' }) !== null, true, 'king can step out of file');
  const t = S(START_FEN);
  eq([t.move({ from: 'e2', to: 'e5' }), t.move({ from: 'e7', to: 'e5' }), t.move({ from: 'a1', to: 'a3' }), t.move({ from: 'e4', to: 'e5' })], [null, null, null, null], 'illegal moves return null');
  ok(t.ply === 0, 'no ply recorded for illegal moves');
}
{ // checkmate / stalemate / insufficient / repetition / fifty
  const s = S(START_FEN); play(s, 'f3', 'e5', 'g4', 'Qh4#'); eq([s.result?.result, s.result?.reason], ['0-1', 'checkmate'], 'fool\'s mate');
  eq(s.move({ from: 'a2', to: 'a3' }), null, 'no moves after the game ends');
}
{
  const st = S('7k/8/5K2/6Q1/8/8/8/8 w - - 0 1'); play(st, 'Qg6'); eq([st.result?.result, st.result?.reason], ['1/2-1/2', 'stalemate'], 'stalemate detected');
  const im = S('4k3/8/8/8/8/8/8/4K2B w - - 0 1'); eq([im.result, im.chess.isInsufficientMaterial()], [null, true], 'K+B vs K is insufficient material');
  const kk = S('4k3/8/8/8/8/8/3p4/4K3 w - - 0 1'); play(kk, 'Kxd2'); eq([kk.result?.reason], ['insufficient'], 'game ends when the last pawn falls (K v K)');
  const r = S(START_FEN); play(r, 'Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8'); eq([r.result?.result, r.result?.reason], ['1/2-1/2', 'repetition'], 'threefold repetition');
  const f = S('4k3/8/8/8/8/8/R7/4K3 w - - 99 80'); play(f, 'Ra3'); eq([f.result?.result, f.result?.reason], ['1/2-1/2', 'fifty'], 'fifty-move rule');
  const f2 = S('4k3/8/8/8/8/8/R7/4K3 w - - 99 80', { autoClaimDraws: false }); play(f2, 'Ra3'); eq([f2.result, f2.claimable()], [null, 'fifty'], 'auto-claim off: draw is claimable, not automatic'); ok(f2.claimDraw() && f2.result.reason === 'fifty', 'claimDraw ends the game');
  ok(hasMatingMaterial(new Chess('4k3/8/8/8/8/8/8/3QK3 w - - 0 1'), 'w') && !hasMatingMaterial(new Chess('4k3/8/8/8/8/8/8/2B1K3 w - - 0 1'), 'w'), 'mating material helper (for flag)');
}
{ // resign / draw agreement / flag
  const s = S(START_FEN); play(s, 'e4'); s.resign('b'); eq([s.result.result, s.result.reason], ['1-0', 'resignation'], 'resignation');
  const d = S(START_FEN); play(d, 'e4', 'e5'); d.agreeDraw(); eq([d.result.result, d.result.reason], ['1/2-1/2', 'agreement'], 'draw by agreement');
  const c = S(START_FEN, { timeControl: { base: 60, inc: 0 } }); play(c, 'e4', 'e5'); c.flag('w'); eq([c.result.result, c.result.reason], ['0-1', 'timeout'], 'timeout loses');
  const c2 = S('4k3/8/8/8/8/8/8/2B1K3 w - - 0 1', { timeControl: { base: 60, inc: 0 } }); play(c2, 'Bd2'); c2.flag('b'); eq([c2.result.result], ['1/2-1/2'], 'timeout vs insufficient material is a draw');
}
{ // clocks: increment, snapshots, undo restores clocks
  const s = S(START_FEN, { timeControl: { base: 300, inc: 5 } });
  play(s, 'e4'); const w1 = s.clocks.w; ok(w1 === 300000, 'no increment for the first move');
  play(s, 'e5'); ok(s.clocks.b >= 300000 && s.clocks.b <= 305000, 'increment added after black moved');
  const snap = { ...s.snapshots[1] }; s.undo(1); eq(s.clocks, snap, 'undo restores clock snapshot');
}
{ // undo / redo
  const s = S(START_FEN, { mode: 'practice' }); play(s, 'e4', 'e5', 'Nf3');
  ok(s.undo(2) && s.ply === 1 && s.fen.startsWith('rnbqkbnr/pppppppp/8/8/4P3'), 'undo 2 plies');
  ok(s.canRedo(2) && s.redo(2) && s.ply === 3 && s.chess.get('f3')?.type === 'n', 'redo 2 plies');
  s.undo(1); play(s, 'Nc3'); ok(!s.canRedo(), 'new move clears redo stack');
  const f = S(START_FEN, { mode: 'engine' }); play(f, 'f3', 'e5', 'g4', 'Qh4#'); ok(!f.canUndo(), 'finished engine game cannot be undone');
  const p = S(START_FEN, { mode: 'practice' }); play(p, 'f3', 'e5', 'g4', 'Qh4#'); ok(p.canUndo() && p.undo(1) && !p.over, 'practice game can undo checkmate');
}
{ // serialize / restore
  const s = S(START_FEN, { timeControl: { base: 600, inc: 0 } }); play(s, 'e4', 'c5', 'Nf3'); s.undo(1);
  const r = GameSession.restore(JSON.parse(JSON.stringify(s.serialize())));
  eq([r.fen, r.ply, r.redoStack.length], [s.fen, s.ply, s.redoStack.length], 'restore keeps position and redo stack');
  ok(r.canRedo() && r.redo(1) && r.chess.get('f3')?.type === 'n', 'restored redo works');
}
{ // PGN export -> import round trip, with metadata and custom FEN
  const s = S(START_FEN, { white: { name: 'Alice', rating: 1500 }, black: { name: 'Bob' } }); play(s, 'e4', 'e5', 'Qh5', 'Nc6', 'Bc4', 'Nf6', 'Qxf7#');
  const pgn = s.pgn(); ok(/\[White "Alice"\]/.test(pgn) && /\[Result "1-0"\]/.test(pgn) && /\[WhiteElo "1500"\]/.test(pgn), 'PGN headers');
  const p = parseGame(pgn); eq([p.moves.length, p.result, p.headers.White], [7, '1-0', 'Alice'], 'PGN re-import');
  const rec = importedRecord(p, { id: 'u', name: 'Alice' }); eq([rec.playerColor, rec.reason, rec.plies], ['w', 'checkmate', 7], 'imported record metadata');
  const fenS = S('4k3/P7/8/8/8/8/6P1/4K3 w - - 0 1'); play(fenS, 'a8=Q+'); const q = parseGame(fenS.pgn()); eq([q.startFen, q.moves.length], ['4k3/P7/8/8/8/8/6P1/4K3 w - - 0 1', 1], 'FEN-start PGN round trip');
  let threw = false; try { parseGame('1. e4 e5 2. Ke3 Qxx9'); } catch { threw = true; } ok(threw, 'invalid PGN throws a readable error');
  try { parseGame('garbage text'); ok(false, 'garbage PGN should throw'); } catch (e) { ok(/PGN/.test(e.message), 'garbage PGN message'); }
  eq(splitPgn(`[Event "a"]\n\n1. e4 *\n\n[Event "b"]\n\n1. d4 *`).length, 2, 'multi-game PGN splitting');
  const commented = parseGame('[Event "x"]\n\n1. e4 {best by test} e5 (1... c5) 2. Nf3 $1 Nc6 1/2-1/2'); eq([commented.moves.length, commented.result], [4, '1/2-1/2'], 'PGN with comments, variations and NAGs');
}
{ // engine score helpers + classification maths
  eq([fmtScore({ cp: 125 }), fmtScore({ cp: -80 }), fmtScore({ cp: 0 }), fmtScore({ mate: 3 }), fmtScore({ mate: -2 })], ['+1.25', '-0.80', '0.00', '#3', '-#2'], 'score formatting');
  ok(barPercent({ mate: 2 }) === 100 && barPercent({ mate: -2 }) === 0 && barPercent({ cp: 0 }) === 50, 'eval bar extremes');
  ok(Math.abs(cpToWin(0) - 50) < 1e-9 && cpToWin(300) > 70 && cpToWin(-300) < 30, 'win-probability curve');
  const c = (b, a, extra = {}) => classifyMove({ played: 'e2e4', best: 'd2d4', wpBefore: b, wpAfter: a, sacrifice: 0, onlyMove: false, ...extra }).cls;
  eq([c(50, 49.9), c(50, 49), c(50, 46), c(50, 41), c(50, 32), c(50, 20)], ['best', 'excellent', 'good', 'inaccuracy', 'mistake', 'blunder'], 'thresholds map loss to class');
  eq(classifyMove({ played: 'd2d4', best: 'd2d4', wpBefore: 50, wpAfter: 49, sacrifice: 0 }).cls, 'best', 'engine move is Best');
  eq(c(50, 49.5, { sacrifice: -3 }), 'brilliant', 'near-best sacrifice is Brilliant');
  eq(c(95, 95, { sacrifice: -3 }), 'best', 'no brilliancy when already winning');
  ok(moveAccuracy(0) > 99 && moveAccuracy(30) < 30 && moveAccuracy(5) > moveAccuracy(10), 'accuracy decreases with loss');
  ok(sacrificeValue('4k3/8/8/2p5/8/8/3Q4/4K3 w - - 0 1', { from: 'd2', to: 'd4' }) < -3, 'SEE: queen hanging to a pawn is a big sacrifice'); // Qxd4 is not: p defended? d5 pawn is captured
  ok(sacrificeValue('4k3/8/8/8/8/8/3Q4/4K3 w - - 0 1', { from: 'd2', to: 'd4' }) === 0, 'SEE: safe square is not a sacrifice');
  ok(Math.abs(expectedScore(1500, 1500) - 0.5) < 1e-9 && expectedScore(1200, 1800) < 0.1, 'Elo expectation');
}
console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
